// CANDIDATE 1.996: objective entry intelligence only. NOT HOMOLOGATED.
// Canonical original: 1995, SHA256 2479ed8e5c9189438d787be1e804abbd95f9e1c06e01042e560251e64ef67fc5.
// Financial identity, journals and recovery remain S1995 for historical compatibility.
// COMPILACAO_NATIVA_NAO_VERIFICADA; see AUDITORIA_PREVIA.md and REGRESSION_FINANCE.md.
#property copyright "Remora Scalper Research"
#property version "1.996" // Scalper 1995; experimental; native compilation pending.
#property description "Remora objective matrix - experimental candidate; NOT HOMOLOGATED"

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>

//=====================================================================
// ENUMS
//=====================================================================
enum EXIT_MODE { ORIGINAL_FIXED_TP=0, PROGRESSIVE_NO_TP=1 };
enum FAR_MODE { FAR_OFF=0, FAR_OBSERVAR=1, FAR_APLICAR=2 };


enum SIZING_MODE
{
   SIZING_FIXED = 0, // Lote fixo
   SIZING_RISK_PERCENT = 1 // % risco por trade
};









//=====================================================================
// CONSTANTS
//=====================================================================
#define MAX_TRADE_RECORDS 200

//=====================================================================
// INPUTS
//=====================================================================
//--- Identidade
input int Inp_Magic_WIN = 60001;
input int Inp_Magic_WDO = 60002;
input string CSVFileName = "Scalper1995"; // explicit Scalper1995 namespace is enforced
input datetime BacktestStart = D'2025.01.01';

//--- Timeframes
input ENUM_TIMEFRAMES Inp_ContextTF = PERIOD_M5; // editable context timeframe
input ENUM_TIMEFRAMES Inp_SignalTF = PERIOD_M1; // TF Sinal (M1)

//--- Sessão
input int Inp_StartHHMM = 900; // Início entradas
input int Inp_StopEntryHHMM = 1530; // Fim entradas
input int Inp_EOD_CloseHHMM = 1750; // EOD (RESEARCH)
//--- Sizing
input SIZING_MODE Inp_SizingMode              = SIZING_FIXED; // Modo sizing
input double Inp_FixedLots = 1.0; // Lote fixo
input double Inp_RiskPerTradePct = 0.15;       // % risco (RISK_PERCENT)
input double Inp_MaxLots = 2.0; // Lote máximo

//--- SL/TP fixos (pts) — hipóteses V0.1, não declarar ótimos
input double Inp_SL_Pts_WIN = 400.0; // SL WIN (pts)
input double Inp_TP_Pts_WIN = 2000.0; // TP WIN (pts)
input double Inp_SL_Pts_WDO = 10.0; // SL WDO (pts)
input double Inp_TP_Pts_WDO = 25.0; // TP WDO (pts)

//--- Spread
input double Inp_SpreadMaxPts_WIN = 30.0; // Spread máx WIN (pts)
input double Inp_SpreadMaxPts_WDO = 2.0; // Spread máx WDO (pts)

//--- Gestão RESEARCH (padrão OFF — medir entrada/saída fixa)
input bool Inp_EnableBreakEven = true; // +1R real confirmado -> SL no preço de entrada

//--- Proteção diária RESEARCH (padrão OFF)
input bool Inp_EnableDailyRiskStop = true; // Stop perda diária
input double Inp_MaxDailyLossR = 3.0; // Máx perda (em R)
input bool Inp_EnableConsecutiveLossStop = true; // Stop perdas seguidas
input int Inp_MaxConsecutiveLosses = 3; // Nº perdas seguidas

//--- Limites (LIMITE, não meta)
input int Inp_MaxTradesDay = 10; // Máx trades/dia

//--- Cooldown (segundos desde fechamento confirmado)
input int Inp_CooldownSec = 0; // Cooldown geral (s)
input int Inp_LossCooldownSec = 0; // Cooldown após perda (s)

//--- Armed
input int Inp_ArmedTimeoutSec = 300; // Timeout armed (s)

//--- Referencia ABS (CONT usa sempre o fechamento do sinal)

//--- Região / Rompimento
input double Inp_BreakoutMargin_WIN = 175.0; // Margem rompimento WIN (pts)
input double Inp_BreakoutMargin_WDO = 3.5; // Margem rompimento WDO (pts)
input double Inp_MaxOvershoot_WIN = 100.0; // Overshoot máx WIN (pts)
input double Inp_MaxOvershoot_WDO           = 2.5; // Overshoot máx WDO (pts)

//--- Weis Wave M1
input double Inp_ABS_Effort = 1.50; // Effort of the original attempted wave, relative to previous closed waves
input double Inp_CONT_Effort = 1.50; // Effort of the progressing wave, relative to previous closed waves

//--- ABS thresholds (pts — hipóteses, não declarar ótimos)
input double Inp_ABS_MinPriceMovePts_WIN = 60.0; // ABS displ min WIN (pts)
input double Inp_ABS_MinPriceMovePts_WDO = 2.0; // ABS displ min WDO (pts)

//--- CONT thresholds (pts — hipóteses)
input double Inp_CONT_MinPriceMovePts_WIN = 50.0; // CONT displ min WIN (pts)
input double Inp_CONT_MinPriceMovePts_WDO = 1.5; // CONT displ min WDO (pts)

//--- Geometria VWAP (herdada da 2.44)
input double Inp_BandMultiplier_WIN = 0.80;
input double Inp_BandMultiplier_WDO = 1.50;



//--- Execução
input int Inp_MaxDeviationPts_WIN = 100;
input int Inp_MaxDeviationPts_WDO = 2;

//--- Rotas habilitadas
input bool Inp_EnableAbsorption = true;
input bool Inp_EnableContinuation = true;

// Scalper 1995: only the five additions authorized besides split VWAP Bands.
input EXIT_MODE Inp_ExitMode = PROGRESSIVE_NO_TP;
input int Inp_MaxProtectedR = 5;
input FAR_MODE Inp_AggressionFilterMode = FAR_APLICAR;
input double Inp_AggressionThresholdPct = 60.0;

int gInstanceLock=INVALID_HANDLE; // exclusive file handle, released by terminal on exit
double gBandMultiplier=0.0; // resolved once from the recognized symbol family

//=====================================================================
// STRUCTS
//=====================================================================






// ENTRY_TYPES_BEGIN
enum ENTRY_PHASE
{
   ENTRY_DISABLED=0, ENTRY_WAIT_CONFIRMATION=2, ENTRY_READY=3
};
struct EntryTriggerState
{
   bool enabled,triggerReady,dispatchAttempted;
   int dir;
   ENTRY_PHASE phase;
   long thesisMsc,lastTradeMsc,confirmationMsc;
   double signalReferencePrice,margin,trigger,confirmationPrice;
};

// ENTRY_TYPES_END

struct ArmedSignal
{
  bool active;
  int dir;
  double regionHigh, regionLow;
  double activeSL_Pts, activeTP_Pts;
  datetime regionEndTime;
  string mode;
  double lots;
  string route;
  datetime armedAt;
    // Snapshot para auditoria
    double posRel, distD1, effort, vwapVig;
    // FAR identity/evidence only: no financial journal fields.
    ulong farArmedMsc,farSignalSequence,farSignalBarMsc;
    ulong farContextStartMsc,farContextEndExclusiveMsc;
    double farArmPrice;
    bool farArmPriceValid;
    EntryTriggerState entry;
    string signalID,entryReason;
    long dispatchQuoteMsc;
    double dispatchAsk,dispatchBid,requestPrice;
};

// RC1.2 execution and accounting state.
// RC1.2: exact order identity survives disappearance from OrdersTotal.
enum PendingOrderNature
{
   PENDING_ORDER_UNKNOWN=0,
   PENDING_ORDER_ENTRY,
   PENDING_ORDER_EXIT
};

struct UnresolvedOrderContext
{
   bool active, classificationPending;
   bool persistencePending;
   ulong orderTicket, positionID, positionByID;
   datetime firstSeen, setupTime, doneTime;
   PendingOrderNature nature;
   ENUM_ORDER_STATE lastState;
   long orderType, orderReason;
   double initialVolume, remainingVolume;
   string comment, route, mode;
   string persistenceSnapshot;
};

UnresolvedOrderContext gUnresolvedOrders[];
bool gMultipleOwnOrdersActive=false;
bool gOrderRegistryUnavailable=false;
ulong gOrderRegistryFallback[MAX_TRADE_RECORDS];
int gOrderRegistryFallbackCount=0;
bool gOrderRegistryOverflow=false;
bool gOrderObligationScanUnresolved=false;
bool gOrderObligationRestoring=false;
datetime gNextOrderReconcile=0;


// Separate BE evidence; no field below replaces the original SL/risk.
enum BE_STAGE
{
   BE_NONE=0, BE_TRIGGERED, BE_REQUEST_PENDING, BE_ACKNOWLEDGED,
   BE_CONFIRMED, BE_UNRESOLVED
};
struct BreakEvenState
{
   int stage, direction;
   // PR2: one protection state; frozen initial proof plus highest confirmed lock.
   int exitMode, targetLevel, confirmedLevel;
   double confirmedPrice;
   long confirmedAt;
   ulong ticket;
   double entryPrice, initialSL, price, tp;
   long triggerMSC, confirmedMSC;
   uint requestID, retcode;
   bool durable, successLogged, exitLogged;
   datetime nextTry, lastFailureLog;
};

struct TradeRecord
{
  ulong positionID;
  int direction;
  string route, mode;
  bool quotaCounted;
  double requestPrice, breakoutPrice;
  bool requestPriceAvailable, breakoutPriceAvailable;
    ulong entryOrderTicket;
    double expectedEntryVolume;
    datetime entryTime;
    double entryPrice, weightedEntryPrice, totalVolumeIn, entrySlippage;
    double slPrice, tpPrice;
    datetime exitTime;
    long exitTimeMSC;
    ulong lastExitDealTicket;
    double exitPrice, weightedExitPrice, totalVolumeOut, volume;
    double grossProfit, commission, fee, swap, netProfit;
    string exitReason;
    double MAE, MFE;
    long holdSeconds;
    double initialRiskMoney, PnL_R;
    bool closed, maeMfePartialAfterRestart, volumeClosedComplete;
    bool finalizationWritten, dailyApplied;
    bool accountingResolved, riskValid, pnlRValid;
    bool initialStopsProven, economicMarkerPending;
    bool economicMarkerCleanupPending; // Maintenance only after fresh durable proof.
    int economicMarkerDeleteError;
    bool historyRefreshPending;
    // Rebuilt from authoritative deals; never ownership of the live residual.
    bool residualForeignDetected, ownCycleEconomicallyClosed;
    bool volumeOwnershipResolved, inoutCostsUnresolved;
   BreakEvenState be;
   bool breakEvenExit; // Derived only from all confirmed own exit components.
   bool breakEvenClassificationPending; // Do not publish a loss before BE proof resolves.
};

// Zero/default and legacy journals must always retain dispatch uncertainty.
enum ENUM_REQUEST_DISPATCH_PHASE
{
  REQUEST_MAY_HAVE_DISPATCHED=0,
  REQUEST_PREPARED=1
};

struct PendingExecContext
{
  bool active;
  ENUM_REQUEST_DISPATCH_PHASE dispatchPhase;
  int direction;
  string route, mode;
  double requestPrice, requestedLots, slPrice, tpPrice;
  datetime sentAt;
  ulong orderTicket, resultDeal;
  uint requestID;
  bool accepted, requestPriceAvailable;
  double breakoutPrice;
  bool breakoutPriceAvailable;
};

struct PendingExitIntent
{
  bool active;
  ENUM_REQUEST_DISPATCH_PHASE dispatchPhase;
  ulong positionID, positionTicket;
  string reason;
  datetime sentAt;
  ulong orderTicket, resultDeal;
  uint requestID;
  bool accepted, uncertain;
  MqlTradeRequest requestSnapshot;
};




struct OpenPositionInfo
{
  bool active;
  ulong positionID;
  int direction;
  double entryPrice;
  double MAE, MFE;
  datetime entryTime;
  string route, mode;
  double lots;
  double initialRiskMoney;
     int tradeRecordIdx;
};



//=====================================================================
// GLOBAL VARIABLES
//=====================================================================
CTrade trade;
CPositionInfo posInfo;

// Família e conta
bool gIsIndexFamily = false;
bool gIsDollarFamily = false;
// Retain the exact platform mode; consolidated-position modes are not hedging.
ENUM_ACCOUNT_MARGIN_MODE gAccountMarginMode=(ENUM_ACCOUNT_MARGIN_MODE)-1;
bool gNetting = false; // Consolidated positions: RETAIL_NETTING and EXCHANGE, as in 1.122
bool gExchange = false; // EXCHANGE-specific diagnosis
double gTickSize = 1.0;
int gDayKey      = -1;

// Parâmetros resolvidos no OnInit (família-específicos)
int gMagicCore = 0;
int gMaxDeviationPts = 0;
double gSpreadMaxPts = 5.0;
double gBreakoutMargin = 5.0;
double gMaxOvershoot = 25.0;
double gSL_Pts      = 150.0;
double gTP_Pts      = 300.0;
double gABS_MinDisplPts = 60.0;
double gCONT_MinDisplPts= 50.0;

// Temporal
datetime gLastMatrixEvalBar = 0; // anti-duplo

// Armed
ArmedSignal armed;
// Open position tracker (MAE/MFE)
OpenPositionInfo gOpenPos;

// Trade records
TradeRecord gTradeRecords[];
int gTradeRecordCount = 0;

// Contadores diários
// Accounting globals. Existing daily counters and gTradeRecords remain.
PendingExecContext gPendingExec;
PendingExitIntent gPendingExit;
int requestsAcceptedToday = 0;
double dailyPnLR = 0.0;
bool gDailyPnLRValid = true;
bool gDailyEconomicsValid = true;
bool gQuotaHistoryValid = true;
bool gAccountingUnresolved = false;
enum DailyEconomicsRecoveryState
{
   DAILY_ECONOMICS_VALID=0,
   TEMPORARY_HISTORY_UNAVAILABLE,
   ECONOMIC_ALLOCATION_IMPOSSIBLE,
   DAILY_ECONOMICS_UNRESOLVED
};
DailyEconomicsRecoveryState gDailyEconomicsState=DAILY_ECONOMICS_VALID;
bool gLiveOwnershipUnresolved=false;
bool gAccountingCapacityUnresolved=false;
bool gDailyRiskLimitLatched=false;
bool gDailyHistoryRetryRequired=false;
datetime gLastAccountingRecoveryTime=0;
ulong gDeferredAccountingPIDs[];
bool gDeferredRegistryUnavailable=false;
ulong gDeferredFallback[MAX_TRADE_RECORDS];
int gDeferredFallbackCount=0;
bool gDeferredRegistryOverflow=false;
ulong gDeferredDeals[];
ulong gDeferredDealFallback[MAX_TRADE_RECORDS];
int gDeferredDealFallbackCount=0;
bool gDeferredDealOverflow=false;
bool gEconomicMarkerScanUnresolved=false;
bool gEMRMaintenanceNeeded=false;
string gEMRMaintenanceCursor="";
bool gIdentityLossUnresolved=false;
bool gIdentityLossPersistPending=false;
bool gRequestJournalUnresolved=false;
bool gRequestJournalWritePending=false;
bool gEntryJournalCleanupPending=false;
bool gExitJournalCleanupPending=false;
bool gEntryJournalInvalid=false, gExitJournalInvalid=false;
bool gEntryJournalWritePending=false, gExitJournalWritePending=false;
bool gRequestJournalRestoring=false;
datetime gNextRequestJournalRecovery=0;
// Independent guard: a history retry cannot erase an unclassified own order.
bool gPendingOrderClassificationUnresolved = false;
bool gNeedsAccountingSync = false;
datetime gLastPendingReconcileTime = 0;
ulong gConfirmedPositionsToday[];

int ordersEnteredToday = 0;
int consecutiveLosses = 0;
double dailyNetPnL = 0.0;
datetime lastCloseConfirmedTime = 0;
bool dailyRiskBlocked = false;
bool lastTradeWasLoss      = false;

// EOD
bool eodDone = false;
bool eodStuckLogged = false;
datetime eodNextTry = 0;

// The financial CSV handle/schema and exact accounting state remain original.
int csvTradeHandle = INVALID_HANDLE;
// Closed-bar clocks are analytical only; no historical bar may arm on attach.
double gLastBreakoutPrice=0;
// Retired analytical counters kept at zero for the unchanged financial CSV schema.
int hardFlipsPerDay=0,armedCancelHard=0,oppositeRearmAfterHard=0;
// FAR identity is the current signal-bar clock; never a directional filter.
datetime gCachedMicroBar=0;
// Flush periódico (evitar por tick)
datetime gLastFlushTime = 0;

//=====================================================================
// RC1 telemetry. No decision gates, CopyTicks, Print or tick flushing here.
ulong gTradeCsvWrittenPIDs[];
bool gTradeCsvIndexLoaded = false;
bool gTradeCsvAppendSafe = false;
string gTradeCsvFileName="";
datetime gNextTradeCsvRecovery=0;
// HELPER FUNCTIONS
//=====================================================================
//=====================================================================
#include "include/ObjectiveMatrix.mqh"
OMThesis gObjectiveArmed;
datetime gObjectiveAttachBar=0;
datetime gFinancialTimerDue=0;
datetime gObjectiveObservedBar=0;

// SCALPER 1995 FAR — the protection predicates below are retained.
// A successful tick-history read is evidence from this feed only, not proof
// of market-wide completeness or perfect aggressor classification.
// All intervals are [start,endExclusive); COPY_TICKS_TRADE ends at end-1.
//=====================================================================
enum FAR_STATE
{
   FAR_FAVORAVEL=0,FAR_NEUTRO,FAR_CONTRADICAO,FAR_INDETERMINADO
};
struct FARWindow
{
   bool valid,realVolume;
   ulong startMsc,endExclusiveMsc,firstMsc,lastMsc;
   int records,knownFirstHalf,knownSecondHalf;
   double buy,sell,unknown,first,last,high,low;
   double firstBuy,firstSell,firstUnknown,secondBuy,secondSell,secondUnknown;
};
FARWindow gFARContext,gFARCurrent;
MqlTick gFARRollingTicks[];
ulong gFARSequence=0,gFARCacheSequence=0,gFARLastDecisionMsc=0,gFARCacheEndMsc=0;
FAR_STATE gFARState=FAR_INDETERMINADO;
string gFARReason="NOT_EVALUATED",gFARLastEvent="";
bool gFAREvidence=false,gFARWouldCancel=false,gFARCancelled=false;
ulong gFARCalls=0,gFARSumUs=0,gFARMaxUs=0,gFARLastUs=0;

void FARClearEvidence()
{
   gFAREvidence=false; gFARWouldCancel=false; gFARCancelled=false;
   gFARLastDecisionMsc=0; gFARCacheEndMsc=0; gFARLastEvent="";
   gFARCacheSequence=0; ArrayResize(gFARRollingTicks,0);
   ZeroMemory(gFARContext); ZeroMemory(gFARCurrent);
   gFARState=FAR_INDETERMINADO; gFARReason="NOT_EVALUATED";
}
bool FARPriceValid(double price)
{
   return MathIsValidNumber(price) && price>0 && gTickSize>0 &&
      MathAbs(price/gTickSize-MathRound(price/gTickSize))<=0.000001;
}
// Full snapshots are used for a closed context. Rolling updates replace the
// whole last millisecond before appending, retaining legitimate same-ms trades.
// There is no deduplication by timestamp and no mixture of real/integer volume.
bool FARRollingRead(ulong start,ulong endExclusive)
{
   if(start>=endExclusive) return false;
   ulong queryStart=start;
   int retained=0,n=ArraySize(gFARRollingTicks);
   if(gFARCacheSequence==armed.farSignalSequence && gFARCacheEndMsc<=endExclusive && n>0)
   {
      ulong boundary=(ulong)gFARRollingTicks[n-1].time_msc;
      if(boundary>=start && boundary<endExclusive)
      {
         queryStart=boundary;
         for(int i=0;i<n;i++)
            if((ulong)gFARRollingTicks[i].time_msc>=start &&
               (ulong)gFARRollingTicks[i].time_msc<boundary)
               retained++;
      }
   }
   MqlTick update[];
   int copied=CopyTradeTicksStrict(queryStart,endExclusive-1,update);
   bool trustworthy=copied>=0 && retained+copied<=1000000;
   for(int i=0;trustworthy && i<copied;i++)
      if(update[i].time_msc<=0 || (ulong)update[i].time_msc<queryStart ||
         (ulong)update[i].time_msc>=endExclusive ||
         (i>0 && update[i].time_msc<update[i-1].time_msc)) trustworthy=false;
   // Repeated boundary reads may append trades at the same millisecond, but
   // may not silently remove/reorder/revise any previously observed record.
   // Compare the entire old boundary prefix, including duplicate multiplicity.
   if(trustworthy && gFARCacheSequence==armed.farSignalSequence &&
      gFARCacheEndMsc<=endExclusive && n>0 &&
      (ulong)gFARRollingTicks[n-1].time_msc==queryStart)
   {
      int offset=0;
      for(int i=0;i<n;i++)
      {
         if((ulong)gFARRollingTicks[i].time_msc!=queryStart) continue;
         if(offset>=copied || update[offset].time_msc!=gFARRollingTicks[i].time_msc ||
            update[offset].last!=gFARRollingTicks[i].last ||
            update[offset].volume!=gFARRollingTicks[i].volume ||
            update[offset].volume_real!=gFARRollingTicks[i].volume_real ||
            update[offset].flags!=gFARRollingTicks[i].flags)
         { trustworthy=false; break; }
         offset++;
      }
   }
   if(!trustworthy) { ArrayResize(gFARRollingTicks,0); gFARCacheEndMsc=0; return false; }
   int kept=0;
   for(int i=0;i<n && kept<retained;i++)
      if((ulong)gFARRollingTicks[i].time_msc>=start &&
         (ulong)gFARRollingTicks[i].time_msc<queryStart)
         gFARRollingTicks[kept++]=gFARRollingTicks[i];
   if(ArrayResize(gFARRollingTicks,retained+copied)!=retained+copied)
   { ArrayResize(gFARRollingTicks,0); gFARCacheEndMsc=0; return false; }
   for(int i=0;i<copied;i++) gFARRollingTicks[retained+i]=update[i];
   gFARCacheEndMsc=endExclusive; gFARCacheSequence=armed.farSignalSequence;
   return true;
}
bool FARBuildWindow(MqlTick &ticks[],ulong start,ulong endExclusive,FARWindow &w)
{
   ZeroMemory(w); w.startMsc=start; w.endExclusiveMsc=endExclusive;
   if(start>=endExclusive) return false;
   int n=ArraySize(ticks);
   if(n==0 || n>1000000) return false; // bounded collector; unavailable => no veto
   bool anyReal=false,anyIntegerOnly=false;
   ulong previous=0;
   for(int i=0;i<n;i++)
   {
      if(ticks[i].time_msc<=0 || (ulong)ticks[i].time_msc<start ||
         (ulong)ticks[i].time_msc>=endExclusive ||
         (i>0 && (ulong)ticks[i].time_msc<previous) ||
         !FARPriceValid(ticks[i].last) || !MathIsValidNumber(ticks[i].volume_real) ||
         ticks[i].volume_real<0) return false;
      previous=(ulong)ticks[i].time_msc;
      if(ticks[i].volume_real>0) anyReal=true;
      else if(ticks[i].volume>0) anyIntegerOnly=true;
      else return false;
   }
   if(anyReal && anyIntegerOnly) return false; // source ambiguity: no veto
   w.realVolume=anyReal;
   ulong midMsc=start+(endExclusive-start)/2;
   w.high=-DBL_MAX; w.low=DBL_MAX;
   for(int i=0;i<n;i++)
   {
      double v=w.realVolume?ticks[i].volume_real:(double)ticks[i].volume;
      bool buy=((ticks[i].flags&TICK_FLAG_BUY)!=0),sell=((ticks[i].flags&TICK_FLAG_SELL)!=0);
      bool firstHalf=((ulong)ticks[i].time_msc<midMsc);
      if(buy && !sell)
      {
         w.buy+=v;
         if(firstHalf) { w.firstBuy+=v; w.knownFirstHalf++; }
         else { w.secondBuy+=v; w.knownSecondHalf++; }
      }
      else if(sell && !buy)
      {
         w.sell+=v;
         if(firstHalf) { w.firstSell+=v; w.knownFirstHalf++; }
         else { w.secondSell+=v; w.knownSecondHalf++; }
      }
      else
      {
         w.unknown+=v;
         if(firstHalf) w.firstUnknown+=v; else w.secondUnknown+=v;
      }
      if(i==0) { w.first=ticks[i].last; w.firstMsc=(ulong)ticks[i].time_msc; }
      w.last=ticks[i].last; w.lastMsc=(ulong)ticks[i].time_msc;
      w.high=MathMax(w.high,ticks[i].last); w.low=MathMin(w.low,ticks[i].last);
      w.records++;
   }
   double total=w.buy+w.sell+w.unknown;
   w.valid=MathIsValidNumber(total) && total>0;
   return w.valid;
}
bool FARReadContext()
{
   MqlTick contextTicks[];
   if(armed.farContextStartMsc==0 || armed.farContextEndExclusiveMsc<=armed.farContextStartMsc ||
      armed.farContextEndExclusiveMsc>armed.farArmedMsc) return false;
   if(CopyTradeTicksStrict(armed.farContextStartMsc,armed.farContextEndExclusiveMsc-1,contextTicks)<0)
      return false;
   return FARBuildWindow(contextTicks,armed.farContextStartMsc,armed.farContextEndExclusiveMsc,gFARContext);
}
void FARCaptureArm()
{
   FARClearEvidence();
   if(Inp_AggressionFilterMode==FAR_OFF) return;
   MqlTick tick;
   if(!SymbolInfoTick(Symbol(),tick) || tick.time_msc<=0) return;
   gFARSequence++;
   armed.farSignalSequence=gFARSequence;
   armed.farSignalBarMsc=(ulong)gCachedMicroBar*1000;
   armed.farArmedMsc=(ulong)tick.time_msc;
   // Require a verifiable executed-trade event at capture; a quote-only last
   // price cannot establish the arm-time trade identity and disables FAR veto.
   bool tradeEvent=((tick.flags&(TICK_FLAG_LAST|TICK_FLAG_VOLUME|TICK_FLAG_BUY|TICK_FLAG_SELL))!=0);
   armed.farArmPriceValid=tradeEvent && FARPriceValid(tick.last) &&
      ((MathIsValidNumber(tick.volume_real) && tick.volume_real>0) || tick.volume>0);
   armed.farArmPrice=armed.farArmPriceValid?tick.last:0;
   datetime closed=iTime(Symbol(),Inp_ContextTF,1);
   armed.farContextStartMsc=(ulong)closed*1000;
   armed.farContextEndExclusiveMsc=armed.farContextStartMsc+(ulong)PeriodSeconds(Inp_ContextTF)*1000;
   FARReadContext(); // frozen once per arm; failure is unavailable, never fabricated
}
double FARPct(double part,double total)
{ return total>0?100.0*part/total:0.0; }
double FAROppositePct(const FARWindow &w,int half)
{
   if(half==1) return FARPct(armed.dir==1?w.firstSell:w.firstBuy,w.firstBuy+w.firstSell+w.firstUnknown);
   if(half==2) return FARPct(armed.dir==1?w.secondSell:w.secondBuy,w.secondBuy+w.secondSell+w.secondUnknown);
   return FARPct(armed.dir==1?w.sell:w.buy,w.buy+w.sell+w.unknown);
}
void FAREvaluate(ulong endExclusive)
{
   gFAREvidence=true; gFARWouldCancel=false; gFARCancelled=false;
   ZeroMemory(gFARCurrent); // invalid evaluations must not retain an older window
   gFARState=FAR_INDETERMINADO; gFARReason="IDENTITY_OR_CLOCK_UNAVAILABLE";
   if(!armed.active || !armed.farArmPriceValid || armed.farSignalSequence==0 ||
      armed.farArmedMsc==0 || endExclusive<=armed.farArmedMsc ||
      armed.farSignalBarMsc==0 || (armed.dir!=1 && armed.dir!=-1) ||
      (armed.route!="ABS" && armed.route!="CONT")) return;
   if(!armed.entry.enabled || !armed.entry.triggerReady ||
      !FARPriceValid(armed.regionHigh) || !FARPriceValid(armed.regionLow) ||
      armed.regionHigh<armed.regionLow)
   { gFARReason="FAR_STRUCTURE_UNAVAILABLE"; return; }
   ulong span=(ulong)PeriodSeconds(Inp_SignalTF)*1000;
   if(span==0 || endExclusive<=span) return;
   ulong start=endExclusive-span;
   gFARReason="TICK_HISTORY_UNAVAILABLE";
   if(!FARRollingRead(start,endExclusive) ||
      !FARBuildWindow(gFARRollingTicks,start,endExclusive,gFARCurrent)) return;
   double threshold=armed.route=="ABS"?gABS_MinDisplPts:gCONT_MinDisplPts;
   double adverseFromArm=-armed.dir*(gFARCurrent.last-armed.farArmPrice);
   double adverseInWindow=-armed.dir*(gFARCurrent.last-gFARCurrent.first);
   bool structure=armed.dir==1?gFARCurrent.last<=armed.regionLow-gTickSize:
      gFARCurrent.last>=armed.regionHigh+gTickSize;
   // Strictly after arm: an event at the arm millisecond is not evidence
   // of a later contradiction; both temporal halves must sustain pressure.
   bool posterior=(start>armed.farArmedMsc && gFARCurrent.firstMsc>armed.farArmedMsc);
   bool sustained=(gFARCurrent.knownFirstHalf>0 && gFARCurrent.knownSecondHalf>0 &&
      FAROppositePct(gFARCurrent,0)>=Inp_AggressionThresholdPct &&
      FAROppositePct(gFARCurrent,1)>=Inp_AggressionThresholdPct &&
      FAROppositePct(gFARCurrent,2)>=Inp_AggressionThresholdPct);
   if(posterior && sustained && adverseFromArm>=threshold && adverseInWindow>=threshold && structure)
   {
      gFARState=FAR_CONTRADICAO; gFARReason="POST_ARM_FULL_HALVES_PRESSURE_DISPLACEMENT_STRUCTURE";
      gFARWouldCancel=true; return;
   }
   gFARState=FAR_NEUTRO;
   gFARReason=posterior?"VETO_PREDICATES_NOT_ALL_PROVEN":"NO_COMPLETE_POST_ARM_WINDOW";
   double directional=armed.dir*(gFARCurrent.last-gFARCurrent.first);
   double supportPct=FARPct(armed.dir==1?gFARCurrent.buy:gFARCurrent.sell,
      gFARCurrent.buy+gFARCurrent.sell+gFARCurrent.unknown);
   double trigger=armed.entry.trigger;
   bool originalBreakout=armed.dir==1?gFARCurrent.last>=trigger:gFARCurrent.last<=trigger;
   if(armed.route=="CONT" && supportPct>=Inp_AggressionThresholdPct &&
      directional>=gCONT_MinDisplPts && originalBreakout)
   {
      gFARState=FAR_FAVORAVEL; gFARReason="CONT_PRESSURE_PROGRESS_ORIGINAL_BREAKOUT";
   }
   if(armed.route=="ABS" && gFARContext.valid && posterior &&
      gFARContext.endExclusiveMsc<=armed.farArmedMsc &&
      FAROppositePct(gFARContext,0)>=Inp_AggressionThresholdPct)
   {
      double testExcursion=armed.dir==1?gFARContext.first-gFARContext.low:
         gFARContext.high-gFARContext.first;
      double reaction=armed.dir*(gFARCurrent.last-armed.farArmPrice);
      if(testExcursion<gABS_MinDisplPts && directional>=gABS_MinDisplPts && reaction>=gABS_MinDisplPts)
      {
         gFARState=FAR_FAVORAVEL; gFARReason="ABS_CONTEXT_STALL_SEPARATE_POST_ARM_REACTION";
      }
   }
}
bool FARBeforeDecision()
{
   if(Inp_AggressionFilterMode==FAR_OFF || !armed.active) return false;
   // No experimental cancellation while any preparation/dispatch/proof is
   // unresolved. The original financial protocol retains exclusive ownership.
   if(gAccountingUnresolved || HasExecutionInFlight() || HasOpenPosition()) return false;
   MqlTick tick;
   if(!SymbolInfoTick(Symbol(),tick) || tick.time_msc<=0) return false;
   ulong now=(ulong)tick.time_msc;
   if(now!=gFARLastDecisionMsc)
   {
      ulong begin=GetMicrosecondCount();
      FAREvaluate(now); gFARLastDecisionMsc=now;
      gFARLastUs=GetMicrosecondCount()-begin; gFARCalls++;
      gFARSumUs+=gFARLastUs; if(gFARLastUs>gFARMaxUs) gFARMaxUs=gFARLastUs;
   }
   bool cancel=Inp_AggressionFilterMode==FAR_APLICAR && gFARState==FAR_CONTRADICAO;
   gFARCancelled=cancel;
   string eventKey=(string)gFARState+"|"+gFARReason;
   if(eventKey!=gFARLastEvent || cancel)
   {
      gFARLastEvent=eventKey;
      WriteAuditRow(cancel?"FAR_CANCEL":(gFARWouldCancel?"FAR_WOULD_CANCEL":"FAR_STATE"),
         DirStr(armed.dir),armed.mode,gFARCurrent.last,armed.posRel,armed.distD1,armed.effort,
         ArmedTriggerPrice());
   }
   if(cancel) { ResetArmedSignal(); return true; }
   return false;
}
void FARHeader(string &line)
{
   string names="FAR_SCHEMA,FAR_MODE,FAR_THRESHOLD_PCT,FAR_STATE,FAR_REASON,FAR_SIGNAL_SEQUENCE,FAR_SIGNAL_BAR_MSC,FAR_ARM_MSC,FAR_EVAL_MSC,FAR_AGE_MSC,FAR_ARM_PRICE,FAR_CONTEXT_START,FAR_CONTEXT_END_EXCLUSIVE,FAR_CURRENT_START,FAR_CURRENT_END_EXCLUSIVE,FAR_CONTEXT_BUY_PCT,FAR_CONTEXT_SELL_PCT,FAR_CONTEXT_UNKNOWN,FAR_BUY_PCT,FAR_SELL_PCT,FAR_UNKNOWN,FAR_VOLUME_SOURCE,FAR_FIRST,FAR_LAST,FAR_HIGH,FAR_LOW,FAR_NET,FAR_ADVERSE_EXCURSION,FAR_FAVORABLE_EXCURSION,FAR_ADVERSE_FROM_ARM,FAR_ADVERSE_IN_WINDOW,FAR_OPPOSITE_PCT_HALF1,FAR_OPPOSITE_PCT_HALF2,FAR_KNOWN_HALF1,FAR_KNOWN_HALF2,FAR_WOULD_CANCEL,FAR_CANCELLED,FAR_LAST_US,FAR_CALLS,FAR_TOTAL_US,FAR_MAX_US";
   string columns[]; int count=StringSplit(names,',',columns);
   for(int i=0;i<count;i++) CsvAdd(line,columns[i]);
}
void FARRow(string &line)
{
   CsvAdd(line,"FAR1995_1"); CsvAdd(line,EnumToString(Inp_AggressionFilterMode));
   CsvAdd(line,CsvD(Inp_AggressionThresholdPct));
   CsvAdd(line,gFAREvidence?EnumToString(gFARState):"");
   CsvAdd(line,gFAREvidence?gFARReason:"");
   CsvAdd(line,(string)armed.farSignalSequence); CsvAdd(line,(string)armed.farSignalBarMsc);
   CsvAdd(line,(string)armed.farArmedMsc); CsvAdd(line,(string)gFARLastDecisionMsc);
   CsvAdd(line,gFARLastDecisionMsc>=armed.farArmedMsc?(string)(gFARLastDecisionMsc-armed.farArmedMsc):"");
   CsvAdd(line,armed.farArmPriceValid?CsvD(armed.farArmPrice):"");
   CsvAdd(line,(string)armed.farContextStartMsc); CsvAdd(line,(string)armed.farContextEndExclusiveMsc);
   CsvAdd(line,(string)gFARCurrent.startMsc); CsvAdd(line,(string)gFARCurrent.endExclusiveMsc);
   double ct=gFARContext.buy+gFARContext.sell+gFARContext.unknown;
   double nt=gFARCurrent.buy+gFARCurrent.sell+gFARCurrent.unknown;
   CsvAdd(line,gFARContext.valid?CsvD(FARPct(gFARContext.buy,ct)):"");
   CsvAdd(line,gFARContext.valid?CsvD(FARPct(gFARContext.sell,ct)):"");
   CsvAdd(line,gFARContext.valid?CsvD(gFARContext.unknown):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(FARPct(gFARCurrent.buy,nt)):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(FARPct(gFARCurrent.sell,nt)):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(gFARCurrent.unknown):"");
   CsvAdd(line,gFARCurrent.valid?(gFARCurrent.realVolume?"VOLUME_REAL":"VOLUME_INTEGER"):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(gFARCurrent.first):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(gFARCurrent.last):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(gFARCurrent.high):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(gFARCurrent.low):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(gFARCurrent.last-gFARCurrent.first):"");
   double adverse=armed.dir==1?gFARCurrent.first-gFARCurrent.low:gFARCurrent.high-gFARCurrent.first;
   double favorable=armed.dir==1?gFARCurrent.high-gFARCurrent.first:gFARCurrent.first-gFARCurrent.low;
   CsvAdd(line,gFARCurrent.valid?CsvD(adverse):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(favorable):"");
   CsvAdd(line,gFARCurrent.valid && armed.farArmPriceValid?CsvD(-armed.dir*(gFARCurrent.last-armed.farArmPrice)):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(-armed.dir*(gFARCurrent.last-gFARCurrent.first)):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(FAROppositePct(gFARCurrent,1)):"");
   CsvAdd(line,gFARCurrent.valid?CsvD(FAROppositePct(gFARCurrent,2)):"");
   CsvAdd(line,(string)gFARCurrent.knownFirstHalf); CsvAdd(line,(string)gFARCurrent.knownSecondHalf);
   CsvAdd(line,BStr(gFARWouldCancel)); CsvAdd(line,BStr(gFARCancelled));
   CsvAdd(line,(string)gFARLastUs); CsvAdd(line,(string)gFARCalls);
   CsvAdd(line,(string)gFARSumUs); CsvAdd(line,(string)gFARMaxUs);
}



// ENTRY_DIAGNOSTICS_BEGIN
// Separate experimental diagnostic stream. Never reads/writes a financial
// journal and never decides whether an order may be sent. Live correlation
// below is intentionally not restored after terminal/EA restart; the original
// financial recovery protocol remains authoritative and unchanged.
int gEntryDiagnosticHandle=INVALID_HANDLE;
string gEntryInstanceID="",gEntryDiagnosticFile="";
ulong gEntrySignalSequence=0;
struct EntryDispatchDiagnostic
{
   ArmedSignal signal;
   ulong orderTicket,resultDeal;
   uint requestID;
};
EntryDispatchDiagnostic gEntryDispatchDiagnostics[];
ulong gEntryObservedDeals[];
ulong gEntryCandidateDeals[]; // Covers DEAL_ADD arriving before result identity binding.

string NewEntrySignalID()
{
   gEntrySignalSequence++;
   return gEntryInstanceID+"_S"+(string)gEntrySignalSequence;
}

void EntryDiagnosticHeader()
{
   string line="ENTRY_SCHEMA,EVENT,SIGNAL_ID,SYMBOL,MAGIC,ROUTE,DIRECTION,MODE,THESIS_MSC,SIGNAL_CLOSE,TRIGGER,CONFIRMATION_MSC,CONFIRMATION_LAST,DISPATCH_MSC,ASK,BID,REQUEST_PRICE,ORDER_ID,DEAL_ID,FILL_PRICE,FILL_VOLUME,FILL_MSC,REASON,ARMED_AT,TIMEOUT_SEC,DISPATCH_ATTEMPTED,REQUEST_ID,RETCODE,TRIGGER_DELAY_MSC,QUOTE_DELAY_MSC,QUOTE_TO_FILL_MSC,OBSERVATION_CLOCK";
   FARHeader(line);
   FileWriteString(gEntryDiagnosticHandle,line+"\r\n");
}

bool EntryDiagnosticsInit()
{
   // Account + symbol + magic + chart + wall-clock + monotonic component;
   // filesystem collision check also protects a pre-existing diagnostic file.
   gEntryInstanceID=StringFormat("%I64d_%s_%d_%I64d_%I64d_%I64u",
      AccountInfoInteger(ACCOUNT_LOGIN),Symbol(),gMagicCore,ChartID(),
      (long)TimeLocal(),GetMicrosecondCount());
   gEntrySignalSequence=0;
   ArrayResize(gEntryDispatchDiagnostics,0); ArrayResize(gEntryObservedDeals,0);
   ArrayResize(gEntryCandidateDeals,0);
   string base="RemoraObjective_EntryDiag_v1_"+gEntryInstanceID;
   int collision=0;
   gEntryDiagnosticFile=base+".csv";
   while(FileIsExist(gEntryDiagnosticFile))
   {
      collision++;
      gEntryDiagnosticFile=base+"_"+(string)collision+".csv";
   }
   if(collision>0) gEntryInstanceID+="_"+(string)collision;
   gEntryDiagnosticHandle=FileOpen(gEntryDiagnosticFile,
      FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
   if(gEntryDiagnosticHandle==INVALID_HANDLE)
   {
      Print("[Scalper 1995][ENTRY_DIAGNOSTICS_UNAVAILABLE] Separate diagnostic file could not be opened; financial journals are unchanged.");
      return false;
   }
   EntryDiagnosticHeader(); FileFlush(gEntryDiagnosticHandle);
   return true;
}

void EntryDiagnosticsClose()
{
   if(gEntryDiagnosticHandle!=INVALID_HANDLE)
   {
      FileFlush(gEntryDiagnosticHandle); FileClose(gEntryDiagnosticHandle);
      gEntryDiagnosticHandle=INVALID_HANDLE;
   }
}

void WriteEntryDiagnostic(const ArmedSignal &s,string event,ulong deal=0,
                         double fillPrice=0,double fillVolume=0,long fillMsc=0,
                         ulong order=0)
{
   if(gEntryDiagnosticHandle==INVALID_HANDLE) return;
   bool fill=deal>0 && MathIsValidNumber(fillPrice) && fillPrice>0 &&
      MathIsValidNumber(fillVolume) && fillVolume>0 && fillMsc>0;
   string clock="TRANSITION";
   if(event=="DISPATCH_RESULT_BOUND") clock="OBSERVED_AFTER_API_AND_FINANCIAL_COMPLETION";
   if(event=="FILL_CONFIRMED" && fill) event="DEAL_CONFIRMED";
   string line="";
   CsvAdd(line,"OBJECTIVE_ENTRY_1"); CsvAdd(line,event);
   CsvAdd(line,s.signalID); CsvAdd(line,Symbol()); CsvAdd(line,(string)gMagicCore);
   CsvAdd(line,s.route); CsvAdd(line,DirStr(s.dir)); CsvAdd(line,s.mode);
   CsvAdd(line,(string)s.entry.thesisMsc); CsvAdd(line,CsvD(s.entry.signalReferencePrice));
   CsvAdd(line,CsvD(s.entry.trigger)); CsvAdd(line,(string)s.entry.confirmationMsc);
   CsvAdd(line,CsvD(s.entry.confirmationPrice)); CsvAdd(line,(string)s.dispatchQuoteMsc);
   CsvAdd(line,CsvD(s.dispatchAsk)); CsvAdd(line,CsvD(s.dispatchBid));
   CsvAdd(line,CsvD(s.requestPrice)); CsvAdd(line,order>0?(string)order:"");
   CsvAdd(line,fill?(string)deal:""); CsvAdd(line,fill?CsvD(fillPrice):"");
   CsvAdd(line,fill?CsvD(fillVolume):""); CsvAdd(line,fill?(string)fillMsc:"");
   CsvAdd(line,s.entryReason); CsvAdd(line,CsvTime(s.armedAt));
   CsvAdd(line,(string)Inp_ArmedTimeoutSec); CsvAdd(line,BStr(s.entry.dispatchAttempted));
   uint requestID=0;
   for(int i=0;i<ArraySize(gEntryDispatchDiagnostics);i++)
      if(gEntryDispatchDiagnostics[i].signal.signalID==s.signalID)
      { requestID=gEntryDispatchDiagnostics[i].requestID; break; }
   CsvAdd(line,requestID>0?(string)requestID:"");
   bool apiResult=event=="DISPATCH_RESULT_BOUND" || event=="REQUEST_ACCEPTED" || event=="ORDER_FAILED";
   CsvAdd(line,apiResult?(string)trade.ResultRetcode():
      (StringFind(event,"REQUEST_RESULT_")==0?StringSubstr(event,15):""));
   CsvAdd(line,s.entry.confirmationMsc>s.entry.thesisMsc?
      (string)(s.entry.confirmationMsc-s.entry.thesisMsc):"");
   CsvAdd(line,s.dispatchQuoteMsc>=s.entry.confirmationMsc && s.entry.confirmationMsc>0?
      (string)(s.dispatchQuoteMsc-s.entry.confirmationMsc):"");
   CsvAdd(line,fill && fillMsc>=s.dispatchQuoteMsc && s.dispatchQuoteMsc>0?
      (string)(fillMsc-s.dispatchQuoteMsc):"");
   CsvAdd(line,clock);
   if(armed.active && armed.signalID==s.signalID) FARRow(line);
   else
   {
      string header="",columns[]; FARHeader(header);
      int count=StringSplit(header,',',columns);
      for(int i=0;i<count;i++) CsvAdd(line,"");
   }
   if(event=="DISPATCH_RESULT_BOUND")
   {
      // PositionOpen was actually invoked before this original callback. This
      // retrospective record adds no IO between the durable barrier and send.
      string attempt=line;
      StringReplace(attempt,",DISPATCH_RESULT_BOUND,",",SEND_ATTEMPT,");
      FileWriteString(gEntryDiagnosticHandle,attempt+"\r\n");
   }
   FileWriteString(gEntryDiagnosticHandle,line+"\r\n");
   // Bounded timer flush; no flush per trade or tick.
}

int RememberEntryDispatch()
{
   int n=ArraySize(gEntryDispatchDiagnostics);
   if(ArrayResize(gEntryDispatchDiagnostics,n+1)!=n+1)
   {
      Print("[Scalper 1995][ENTRY_DISPATCH_DIAGNOSTIC_UNAVAILABLE] Could not retain diagnostic correlation; financial request state is unchanged.");
      return -1;
   }
   gEntryDispatchDiagnostics[n].signal=armed;
   gEntryDispatchDiagnostics[n].orderTicket=0;
   gEntryDispatchDiagnostics[n].resultDeal=0;
   gEntryDispatchDiagnostics[n].requestID=0;
   return n;
}

bool EntryDealAlreadyObserved(ulong deal)
{
   for(int i=0;i<ArraySize(gEntryObservedDeals);i++)
      if(gEntryObservedDeals[i]==deal) return true;
   return false;
}

void EntryObserveDeal(ulong deal)
{
   if(deal==0 || EntryDealAlreadyObserved(deal) || !HistoryDealSelect(deal)) return;
   ResetLastError();
   string symbol=HistoryDealGetString(deal,DEAL_SYMBOL);
   long magic=HistoryDealGetInteger(deal,DEAL_MAGIC);
   long entry=HistoryDealGetInteger(deal,DEAL_ENTRY);
   long type=HistoryDealGetInteger(deal,DEAL_TYPE);
   ulong order=(ulong)HistoryDealGetInteger(deal,DEAL_ORDER);
   double price=HistoryDealGetDouble(deal,DEAL_PRICE);
   double volume=HistoryDealGetDouble(deal,DEAL_VOLUME);
   long timeMsc=HistoryDealGetInteger(deal,DEAL_TIME_MSC);
   if(GetLastError()!=0 || symbol!=Symbol() || magic!=(long)gMagicCore || order==0 ||
      (entry!=DEAL_ENTRY_IN && entry!=DEAL_ENTRY_INOUT) ||
      !MathIsValidNumber(price) || price<=0 || !MathIsValidNumber(volume) || volume<=0 || timeMsc<=0)
      return;
   int match=-1;
   for(int i=0;i<ArraySize(gEntryDispatchDiagnostics);i++)
   {
      bool exactOrder=gEntryDispatchDiagnostics[i].orderTicket>0 &&
         gEntryDispatchDiagnostics[i].orderTicket==order;
      bool exactDeal=gEntryDispatchDiagnostics[i].resultDeal>0 &&
         gEntryDispatchDiagnostics[i].resultDeal==deal;
      if(!exactOrder && !exactDeal) continue;
      int dir=gEntryDispatchDiagnostics[i].signal.dir;
      if((dir==1 && type!=DEAL_TYPE_BUY) || (dir==-1 && type!=DEAL_TYPE_SELL)) continue;
      if(match>=0) return; // ambiguous correlation is never guessed
      match=i;
   }
   if(match<0) return; // Pre-restart/unbound history is not fabricated into this run.
   int count=ArraySize(gEntryObservedDeals);
   if(ArrayResize(gEntryObservedDeals,count+1)!=count+1) return;
   gEntryObservedDeals[count]=deal;
   ArmedSignal snapshot=gEntryDispatchDiagnostics[match].signal;
   string event=entry==DEAL_ENTRY_IN?"FILL_CONFIRMED":"FILL_INOUT_UNEXPECTED";
   WriteEntryDiagnostic(snapshot,event,deal,price,volume,timeMsc,order);
}

void BindEntryDispatch(int idx,ulong order,ulong deal,uint requestID)
{
   if(idx<0 || idx>=ArraySize(gEntryDispatchDiagnostics)) return;
   gEntryDispatchDiagnostics[idx].orderTicket=order;
   gEntryDispatchDiagnostics[idx].resultDeal=deal;
   gEntryDispatchDiagnostics[idx].requestID=requestID;
   WriteEntryDiagnostic(gEntryDispatchDiagnostics[idx].signal,"DISPATCH_RESULT_BOUND",0,0,0,0,order);
   // Synchronous results can expose a fill before its queued transaction event.
   // History unavailability here is retried by the real DEAL_ADD event.
   if(deal>0) EntryObserveDeal(deal);
   for(int i=0;i<ArraySize(gEntryCandidateDeals);i++)
      EntryObserveDeal(gEntryCandidateDeals[i]);
}

void EntryObserveFill(const MqlTradeTransaction &trans)
{
   if(trans.type==TRADE_TRANSACTION_DEAL_ADD && trans.deal>0)
   {
      // Transaction order is not guaranteed. Buffer only observed own entry
      // deal IDs, and still require exact order/deal identity before logging.
      if(HistoryDealSelect(trans.deal))
      {
         ResetLastError();
         string symbol=HistoryDealGetString(trans.deal,DEAL_SYMBOL);
         long magic=HistoryDealGetInteger(trans.deal,DEAL_MAGIC);
         long entry=HistoryDealGetInteger(trans.deal,DEAL_ENTRY);
         if(GetLastError()==0 && symbol==Symbol() && magic==(long)gMagicCore &&
            (entry==DEAL_ENTRY_IN || entry==DEAL_ENTRY_INOUT))
         {
            bool known=false;
            int n=ArraySize(gEntryCandidateDeals);
            for(int i=0;i<n;i++)
               if(gEntryCandidateDeals[i]==trans.deal) { known=true; break; }
            if(!known && ArrayResize(gEntryCandidateDeals,n+1)==n+1)
               gEntryCandidateDeals[n]=trans.deal;
         }
      }
      EntryObserveDeal(trans.deal);
   }
}

// Call only for TRADE_TRANSACTION_REQUEST, after the original financial
// transaction processing. A later result may supply the exact order/deal that
// the synchronous response did not expose. Never infer identity from Magic or
// a similar price alone, and never bind a request whose ID was unavailable.
void EntryObserveRequest(const MqlTradeRequest &request,const MqlTradeResult &result)
{
   if(result.request_id==0 || request.symbol!=Symbol() ||
      request.magic!=(ulong)gMagicCore || request.action!=TRADE_ACTION_DEAL ||
      request.position!=0 || request.position_by!=0) return;
   int match=-1;
   for(int i=0;i<ArraySize(gEntryDispatchDiagnostics);i++)
   {
      if(gEntryDispatchDiagnostics[i].requestID==0 ||
         gEntryDispatchDiagnostics[i].requestID!=result.request_id) continue;
      if(match>=0) return;
      match=i;
   }
   if(match<0) return;
   ArmedSignal snapshot=gEntryDispatchDiagnostics[match].signal;
   if(request.comment!="S1995|"+snapshot.route+"|"+snapshot.mode ||
      (snapshot.dir==1 && request.type!=ORDER_TYPE_BUY) ||
      (snapshot.dir==-1 && request.type!=ORDER_TYPE_SELL) ||
      !MathIsValidNumber(request.price) || request.price<=0 ||
      MathAbs(request.price-snapshot.requestPrice)>gTickSize*0.000001 ||
      !MathIsValidNumber(request.volume) || request.volume<=0 ||
      MathAbs(request.volume-snapshot.lots)>AccountingVolumeTolerance()) return;
   if((result.order>0 && gEntryDispatchDiagnostics[match].orderTicket>0 &&
       result.order!=gEntryDispatchDiagnostics[match].orderTicket) ||
      (result.deal>0 && gEntryDispatchDiagnostics[match].resultDeal>0 &&
       result.deal!=gEntryDispatchDiagnostics[match].resultDeal))
   {
      WriteEntryDiagnostic(snapshot,"REQUEST_RESULT_IDENTITY_CONFLICT");
      return;
   }
   if(result.order>0) gEntryDispatchDiagnostics[match].orderTicket=result.order;
   if(result.deal>0) gEntryDispatchDiagnostics[match].resultDeal=result.deal;
   WriteEntryDiagnostic(snapshot,"REQUEST_RESULT_"+(string)result.retcode,0,0,0,0,
      gEntryDispatchDiagnostics[match].orderTicket);
   if(gEntryDispatchDiagnostics[match].resultDeal>0)
      EntryObserveDeal(gEntryDispatchDiagnostics[match].resultDeal);
   for(int i=0;i<ArraySize(gEntryCandidateDeals);i++)
      EntryObserveDeal(gEntryCandidateDeals[i]);
}
// ENTRY_DIAGNOSTICS_END

string DirStr(int d) { return d==1 ? "BUY" : (d==-1 ? "SELL" : "NONE"); }
string BStr(bool b) { return b ? "1" : "0"; }







double NormPriceDigits(double p)
{
  return NormalizeDouble(p, (int)SymbolInfoInteger(Symbol(), SYMBOL_DIGITS));
}

double RoundUpTick(double p)
{
  double r = p / gTickSize;
  double n = MathRound(r);
  if(MathAbs(r - n) < 1e-6) return NormPriceDigits(n * gTickSize);
  return NormPriceDigits(MathCeil(r) * gTickSize);
}

double RoundDownTick(double p)
{
  double r = p / gTickSize;
    double n = MathRound(r);
    if(MathAbs(r - n) < 1e-6) return NormPriceDigits(n * gTickSize);
    return NormPriceDigits(MathFloor(r) * gTickSize);
}

// ENTRY_CORE_BEGIN
bool EntryGridValid(double price)
{
   return MathIsValidNumber(gTickSize) && gTickSize>0 &&
      MathIsValidNumber(price) && price>0 &&
      MathAbs(price/gTickSize-MathRound(price/gTickSize))<=1e-6;
}
bool EntryTimeoutExpired(datetime armedAt,datetime now,int timeout)
{
   return armedAt>0 && now>=armedAt && now-armedAt>=(datetime)timeout;
}
bool InitSignalCloseTrigger(EntryTriggerState &e,int dir,double signalClose,
                           double margin,long thesisMsc,string &reason)
{
   ZeroMemory(e); reason="SIGNAL_CLOSE_INVALID";
   if((dir!=1 && dir!=-1) || !EntryGridValid(signalClose) ||
      !MathIsValidNumber(margin) || margin<=0 || thesisMsc<=0) return false;
   e.dir=dir; e.signalReferencePrice=signalClose; e.margin=margin;
   e.trigger=dir==1?RoundUpTick(signalClose+margin):RoundDownTick(signalClose-margin);
   if(!EntryGridValid(e.trigger)) return false;
   e.enabled=true; e.triggerReady=true; e.thesisMsc=thesisMsc;
   e.phase=ENTRY_WAIT_CONFIRMATION; reason="SIGNAL_CLOSE_FROZEN";
   return true;
}
bool EntryRealTrade(const MqlTick &tk)
{
   uint tradeFlags=TICK_FLAG_LAST|TICK_FLAG_VOLUME|TICK_FLAG_BUY|TICK_FLAG_SELL;
   return tk.time_msc>0 && tk.time>0 && (long)tk.time==tk.time_msc/1000 &&
      (tk.flags&tradeFlags)!=0 && EntryGridValid(tk.last) &&
      MathIsValidNumber(tk.volume_real) && tk.volume_real>=0 &&
      (tk.volume_real>0 || tk.volume>0);
}
// 0 waiting, 1 current verified confirmation. Same-ms events
// cannot prove sequence here and never serve as a second trade.
int ObserveEntryTrade(EntryTriggerState &e,const MqlTick &tk,string &reason)
{
   reason="WAIT_REAL_POST_THESIS_TRADE";
   if(!e.enabled || e.phase==ENTRY_DISABLED || e.dispatchAttempted || !EntryRealTrade(tk) ||
      tk.time_msc<=e.thesisMsc || tk.time_msc<e.lastTradeMsc) return 0;
   if(tk.time_msc==e.lastTradeMsc) return 0;
   e.lastTradeMsc=tk.time_msc; e.confirmationMsc=0; e.confirmationPrice=0;
   e.phase=ENTRY_WAIT_CONFIRMATION; reason="WAIT_CONFIRMATION";
   if(!e.triggerReady || (e.dir==1?tk.last<e.trigger:tk.last>e.trigger)) return 0;
   e.confirmationMsc=tk.time_msc; e.confirmationPrice=tk.last;
   e.phase=ENTRY_READY; reason="REAL_TRADE_CONFIRMED"; return 1;
}
bool ValidateEntryDispatch(EntryTriggerState &e,const MqlTick &tk,string &reason)
{
   reason="CONFIRMATION_UNAVAILABLE";
   if(!e.enabled || e.dispatchAttempted) return false;
   if(tk.time_msc<=0 || tk.time<=0 || (long)tk.time!=tk.time_msc/1000)
   { reason="DISPATCH_CLOCK_INVALID"; return false; }
   uint tradeFlags=TICK_FLAG_LAST|TICK_FLAG_VOLUME|TICK_FLAG_BUY|TICK_FLAG_SELL;
   if((tk.flags&tradeFlags)!=0 && !EntryRealTrade(tk))
   { reason="DISPATCH_TRADE_INVALID"; return false; }
   // A new trade arriving during FAR/sizing must be evaluated before dispatch.
   // A quote-only update may retain independently verified Last evidence.
   if(EntryRealTrade(tk) && tk.time_msc>e.lastTradeMsc)
   {
      int result=ObserveEntryTrade(e,tk,reason);
      if(result<0) return false;
   }
   if(e.phase!=ENTRY_READY || e.confirmationMsc<=e.thesisMsc ||
      tk.time_msc<e.lastTradeMsc || tk.time_msc<e.confirmationMsc ||
      !EntryGridValid(tk.last) || tk.last!=e.confirmationPrice) return false;
   if(!EntryGridValid(tk.ask) || !EntryGridValid(tk.bid) || tk.ask<tk.bid)
   { reason="DISPATCH_QUOTE_INVALID"; return false; }
   double exec=e.dir==1?tk.ask:tk.bid;
   if(e.dir==1?exec<e.trigger:exec>e.trigger)
   { reason="DISPATCH_TRIGGER_LOST"; return false; }
   reason="DISPATCH_GUARD_OK"; return true;
}
bool ClaimEntryDispatch(EntryTriggerState &e)
{
   if(!e.enabled || e.dispatchAttempted || e.phase!=ENTRY_READY) return false;
   e.dispatchAttempted=true; return true;
}
// ENTRY_CORE_END

double NormEntrySL(int dir, double sl)
{ return (dir == 1) ? RoundDownTick(sl) : RoundUpTick(sl); }

double NormEntryTP(int dir, double tp)
{ return (dir == 1) ? RoundUpTick(tp) : RoundDownTick(tp); }





bool ArmedTriggerReady()
{ return armed.active && armed.entry.enabled && armed.entry.triggerReady; }
double ArmedTriggerPrice()
{ return ArmedTriggerReady()?armed.entry.trigger:0; }


// The new modes revalidate the original live filters on the final quote too.
// No new threshold, timer or interpretation of FAR is introduced here.
bool ObjectiveContInsideB3(int dir,double price,const OMBands &bands)
{
   if(!bands.ready || !MathIsValidNumber(price) || price<=0 ||
      !MathIsValidNumber(bands.upper3) || !MathIsValidNumber(bands.lower3)) return false;
   if(dir==1) return price<bands.upper3;
   if(dir==-1) return price>bands.lower3;
   return false;
}

bool ObjectiveRevalidate(string &reason)
{
   reason="THESIS_INDETERMINATE";
   if(!armed.active || !armed.entry.enabled) return false;
   int validity=OMRevalidate(gObjectiveArmed,reason);
   if(validity<0)
   {
      WriteAuditRow("THESIS_INVALIDATED_"+reason,DirStr(armed.dir),armed.mode,0,0,0,0,ArmedTriggerPrice());
      ResetArmedSignal(); return false;
   }
   return validity==1;
}

bool EntryDispatchGuard(const MqlTick &tk)
{
   // No strategic cancellation may erase ownership of a financial request.
   if(!armed.active || !armed.entry.enabled || gAccountingUnresolved ||
      HasExecutionInFlight() || HasOpenPosition()) return false;
   string reason;
   if(EntryTimeoutExpired(armed.armedAt,TimeTradeServer(),Inp_ArmedTimeoutSec))
   {
      WriteAuditRow("TIMEOUT_ARMED",DirStr(armed.dir),armed.mode,0,0,0,0,ArmedTriggerPrice());
      ResetArmedSignal(); return false;
   }
   if(!EntryGridValid(tk.ask) || !EntryGridValid(tk.bid) || tk.ask<tk.bid) return false;
   if(armed.route=="CONT" &&
      !ObjectiveContInsideB3(armed.dir,armed.dir==1?tk.ask:tk.bid,gObjectiveArmed.bands))
   {
      WriteAuditRow("CONT_EXEC_OUTSIDE_B3",DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice());
      ResetArmedSignal(); return false;
   }
   if(EntryRealTrade(tk) && tk.time_msc>armed.entry.thesisMsc &&
      (armed.dir==1?tk.last>=armed.entry.trigger:tk.last<=armed.entry.trigger))
   {
      double overLast=armed.dir*(tk.last-armed.entry.trigger);
      double overExec=armed.dir*((armed.dir==1?tk.ask:tk.bid)-armed.entry.trigger);
      if(MathMax(overLast,overExec)>gMaxOvershoot)
      { WriteAuditRow("OVERSHOOT_BLOCK",DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice()); ResetArmedSignal(); return false; }
   }
   if(tk.last!=gOMLastPrice || !OMLiveReady(tk.time_msc) || !ObjectiveRevalidate(reason)) return false; // unknown continuation is never approval
   if(tk.ask-tk.bid>gSpreadMaxPts) reason="HOLD_SPREAD";
   else if(ValidateEntryDispatch(armed.entry,tk,reason))
   {
      double overLast=armed.dir*(tk.last-armed.entry.trigger);
      double overExec=armed.dir*((armed.dir==1?tk.ask:tk.bid)-armed.entry.trigger);
      if(MathMax(overLast,overExec)<=gMaxOvershoot)
      { armed.entryReason="DISPATCH_GUARD"; return true; }
      WriteAuditRow("OVERSHOOT_BLOCK",DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice());
      ResetArmedSignal(); return false;
   }
   WriteAuditRow(reason,DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice());
   return false;
}

bool IsFokSupported()
{
  ENUM_SYMBOL_TRADE_EXECUTION exec =
      (ENUM_SYMBOL_TRADE_EXECUTION)SymbolInfoInteger(Symbol(),
SYMBOL_TRADE_EXEMODE);
  if(exec == SYMBOL_TRADE_EXECUTION_INSTANT ||
     exec == SYMBOL_TRADE_EXECUTION_REQUEST)
      return true;
  long filling = SymbolInfoInteger(Symbol(), SYMBOL_FILLING_MODE);
  return ((filling & SYMBOL_FILLING_FOK) == SYMBOL_FILLING_FOK);
}









void ResetArmedSignal()
{
   if(armed.active && armed.signalID!="") WriteEntryDiagnostic(armed,"SIGNAL_END");
   ZeroMemory(armed);
   armed.mode="NONE"; armed.route="NONE";
   ZeroMemory(gObjectiveArmed);
   FARClearEvidence();
}

void ResetOpenPos()
{
  gOpenPos.active=false;gOpenPos.positionID=0;gOpenPos.direction=0;
  gOpenPos.entryPrice=0;gOpenPos.MAE=0;gOpenPos.MFE=0;
  gOpenPos.entryTime=0;gOpenPos.route="";gOpenPos.mode="";
  gOpenPos.lots=0;gOpenPos.initialRiskMoney=0;gOpenPos.tradeRecordIdx=-1;
}

//=====================================================================
// TICK COPY — FAIL CLOSED (from v2.44, unchanged)
//=====================================================================
int CopyTradeTicksStrict(ulong from_msc, ulong to_msc, MqlTick &ticksOut[])
{
   if(to_msc < from_msc) return -1;
   ResetLastError();
   int copied = CopyTicksRange(Symbol(), ticksOut, COPY_TICKS_TRADE, from_msc,
to_msc);
    if(copied < 0 || GetLastError() != 0) return -1;
    return copied;
}

// Normal sizing: original risk calculation and financial limits.
double ComputeLotsForEntry(int direction, double entryPrice, double slPrice)
{
   if(Inp_SizingMode==SIZING_FIXED)
   {
      // Use the selected, frozen ARMED classification; never reclassify here.
      if(!armed.active || armed.dir!=direction ||
         (armed.mode!="BASE" && armed.mode!="BASE_CONT" &&
          armed.mode!="TURBO" && armed.mode!="TURBO_CONT")) return 0.0;
      double lots=Inp_FixedLots;
      double step=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_STEP);
      double minimum=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);
      double maximum=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX);
      if(!Positive(step) || !OnVolumeGrid(lots,step) || lots<minimum ||
         lots>maximum || lots>Inp_MaxLots)
      {
         WriteAuditRow("FIXED_VOLUME_REJECTED",DirStr(direction),armed.mode,entryPrice,0,0,0,0);
         return 0.0; // no silent cap or rounding of BASE/TURBO volume
      }
      return lots;
   }
   double profit=0.0;
  ENUM_ORDER_TYPE type=(direction==1)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
  if(!OrderCalcProfit(type,Symbol(),1.0,entryPrice,slPrice,profit) ||
     !MathIsValidNumber(profit) || profit>=0.0)
  {
     WriteAuditRow("RISK_CALC_FAIL",DirStr(direction),armed.mode,entryPrice,0,0,0,0);
     return 0.0;
  }
  double riskCash=AccountInfoDouble(ACCOUNT_EQUITY)*Inp_RiskPerTradePct/100.0;
  if(!MathIsValidNumber(riskCash) || riskCash<=0) return 0.0;
  double step=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_STEP);
  double
cap=MathMin(Inp_MaxLots,SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX));
  double raw=MathMin(riskCash/MathAbs(profit),cap);
  double lots=NormalizeDouble(MathFloor(raw/step)*step,8);
  // Never allow a rounded floating representation to exceed raw risk/cap.
  if(lots>raw+1e-10) lots=NormalizeDouble(lots-step,8);
  if(lots<SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)-1e-10)
  {

WriteAuditRow("RISK_BELOW_MIN_LOT",DirStr(direction),armed.mode,entryPrice,0,0,0,0);
    return 0.0;
  }
  return lots;
}
bool MarginOk(ENUM_ORDER_TYPE otype, double lots)
{
  double margin=0;
  double price=(otype==ORDER_TYPE_BUY)?
      SymbolInfoDouble(Symbol(),SYMBOL_ASK):
      SymbolInfoDouble(Symbol(),SYMBOL_BID);
  if(!OrderCalcMargin(otype,Symbol(),lots,price,margin)) return false;
  return (AccountInfoDouble(ACCOUNT_MARGIN_FREE)>=margin);
}




bool SpreadOk()
{
  MqlTick tick;
  if(!SymbolInfoTick(Symbol(),tick) || tick.ask<=0 || tick.bid<=0 || tick.ask<tick.bid)
     return false;
  return tick.ask-tick.bid<=gSpreadMaxPts;
}
//=====================================================================
// POSITION HELPERS (adaptados da v2.44)
//=====================================================================
bool HasOpenPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
     if(!posInfo.SelectByIndex(i)) continue;
     if(posInfo.Symbol()!=Symbol()) continue;
     if(gNetting) return true;
     if(posInfo.Magic()==(long)gMagicCore) return true;
   }
   return false;
}

bool HasOwnPositionStrict()
{
  for(int i=PositionsTotal()-1;i>=0;i--)
  {
    if(!posInfo.SelectByIndex(i)) continue;
    if(posInfo.Symbol()!=Symbol()) continue;
    if(posInfo.Magic()==(long)gMagicCore) return true;
  }
  return false;
}

// Conta trades por POSITION_ID (não por deals) — idêntico à v2.44
//=====================================================================
// MAE/MFE TRACKING (por tick, sem escrita por tick)
//=====================================================================
void UpdateMAEMFE()
{
   if(!gOpenPos.active) return;
   MqlTick tk;
   if(!SymbolInfoTick(Symbol(),tk)) return;
   // Usar bid/ask para cálculo conservador
   double current=(gOpenPos.direction==1)?tk.bid:tk.ask;
   double move=(double)gOpenPos.direction*(current-gOpenPos.entryPrice);
   double adverse=-move;
   if(adverse>gOpenPos.MAE) gOpenPos.MAE=adverse;
   if(move>gOpenPos.MFE) gOpenPos.MFE=move;
}

//=====================================================================
// TELEMETRIA CSV
// Não escreve por tick. FileFlush apenas em eventos importantes ou no Timer.
//=====================================================================
string CsvCell(string value)
{
  if(StringLen(value) == 0) return "\"\"";
   bool quoted = StringFind(value,",") >= 0 || StringFind(value,"\"") >= 0 ||
         StringFind(value,"\r") >= 0 || StringFind(value,"\n") >= 0;
   if(!quoted) return value;
   StringReplace(value,"\"","\"\"");
   return "\"" + value + "\"";
}

void CsvAdd(string &line,string value)
{
  if(StringLen(line) > 0) line += ",";
  line += CsvCell(value);
}

string CsvD(double value)
{
  if(!MathIsValidNumber(value) || value == EMPTY_VALUE) return "";
  return DoubleToString(value,8);
}

string CsvTime(datetime value)
{
  return value > 0 ? TimeToString(value,TIME_DATE|TIME_SECONDS) : "";
}
bool TradeCsvContainsPID(ulong positionID)
{
  for(int i=0;i<ArraySize(gTradeCsvWrittenPIDs);i++)
   if(gTradeCsvWrittenPIDs[i] == positionID) return true;
  return false;
}

bool TradeCsvAddPID(ulong positionID)
{
  if(TradeCsvContainsPID(positionID)) return true;
  int n=ArraySize(gTradeCsvWrittenPIDs);
  if(ArrayResize(gTradeCsvWrittenPIDs,n+1) != n+1) return false;
  gTradeCsvWrittenPIDs[n]=positionID;
  return true;
}

bool CsvParsePID(string value,ulong &positionID)
{
  positionID=0;
  if(StringLen(value)==0) return false;
  for(int i=0;i<StringLen(value);i++)
  {
     ushort c=StringGetCharacter(value,i);
     if(c<48 || c>57) return false;
     ulong digit=(ulong)(c-48);
     ulong next=positionID*10+digit;
     if(next<digit || (next-digit)/10 != positionID) return false;
     positionID=next;
    }
    return positionID>0;
}

// Strict quote-aware parsing of one complete logical CSV record.
// CR/LF inside quoted fields are preserved; malformed quoting fails closed.
bool CsvParseRecord(string record,string &fields[])
{
   ArrayResize(fields,0);
   string value="";
   bool quoted=false,afterQuote=false;
   int len=StringLen(record);
   for(int i=0;i<len;i++)
   {
     ushort c=StringGetCharacter(record,i);
     if(quoted)
     {
        if(c==34)
        {
         if(i+1<len && StringGetCharacter(record,i+1)==34)
         { value+="\""; i++; }
         else { quoted=false; afterQuote=true; }
       }
       else value+=StringSubstr(record,i,1);
     }
     else if(c==44)
     {
       int n=ArraySize(fields);
       if(ArrayResize(fields,n+1)!=n+1) return false;
       fields[n]=value; value=""; afterQuote=false;
     }
     else if(c==34)
     {
       if(StringLen(value)>0 || afterQuote) return false;
       quoted=true;
     }
     else
     {
       if(afterQuote || c==10 || c==13) return false;
       value+=StringSubstr(record,i,1);
     }
    }
    if(quoted) return false;
    int n=ArraySize(fields);
     if(ArrayResize(fields,n+1)!=n+1) return false;
     fields[n]=value;
     return true;
}

int CsvColumnIndex(string &headers[],string name)
{
  for(int i=0;i<ArraySize(headers);i++) if(headers[i]==name) return i;
  return -1;
}

// One attach-time scan. Never truncate, repair, or overwrite an existing CSV.
// A nonterminated tail is conservatively incomplete, even if fields look valid.
bool InitializeTradeCsvIndex(string fileName)
{
   ArrayResize(gTradeCsvWrittenPIDs,0);
   gTradeCsvIndexLoaded=false; gTradeCsvAppendSafe=false;
   int
h=FileOpen(fileName,FILE_READ|FILE_BIN|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(h==INVALID_HANDLE)
   { Print("[Scalper 1995][TRADE_CSV_INDEX_UNAVAILABLE] ",fileName); return false; }
   ulong size=FileSize(h);
    if(size==0 || size>2147483647)
    { FileClose(h); Print("[Scalper 1995][TRADE_CSV_INDEX_INVALID_SIZE] ",fileName); return
false;
}
  uchar bytes[];
  if(ArrayResize(bytes,(int)size)!=(int)size)
  { FileClose(h); Print("[Scalper 1995][TRADE_CSV_INDEX_MEMORY_FAIL] ",fileName); return
false; }
  uint read=FileReadArray(h,bytes,0,(int)size);
  FileClose(h);
  if(read!=(uint)size)
  { Print("[Scalper 1995][TRADE_CSV_INDEX_READ_FAIL] ",fileName); return false; }
  for(int i=0;i<(int)read;i++)
     if(bytes[i]==0)
     { Print("[Scalper 1995][TRADE_CSV_INDEX_INVALID_NUL] ",fileName); return false; }
  string content=CharArrayToString(bytes,0,(int)read,CP_ACP);
  string expectedLine="";
  CsvConfigHeader(expectedLine); CsvTradeHeader(expectedLine);
  string expected[],headers[];
  if(!CsvParseRecord(expectedLine,expected)) return false;
  int schema=-1,symbol=-1,magic=-1,pid=-1,closed=-1,accounting=-1;
  bool haveHeader=false,inQuote=false;
  int recordStart=0,len=StringLen(content);
 for(int i=0;i<len;i++)
 {
    ushort c=StringGetCharacter(content,i);
   if(c==34)
   {
      if(inQuote && i+1<len && StringGetCharacter(content,i+1)==34) i++;
      else inQuote=!inQuote;
   }
   if((c!=10 && c!=13) || inQuote) continue;
   string record=StringSubstr(content,recordStart,i-recordStart);
   if(c==13 && i+1<len && StringGetCharacter(content,i+1)==10) i++;
   recordStart=i+1;
   if(!haveHeader)
   {
      if(!CsvParseRecord(record,headers) || ArraySize(headers)!=ArraySize(expected))
      { Print("[Scalper 1995][TRADE_CSV_SCHEMA_MISMATCH] ",fileName); return false; }
      for(int k=0;k<ArraySize(expected);k++)
         if(headers[k]!=expected[k])
         { Print("[Scalper 1995][TRADE_CSV_SCHEMA_MISMATCH] ",fileName); return false; }
      schema=CsvColumnIndex(headers,"SCHEMA_VERSION");
      symbol=CsvColumnIndex(headers,"SYMBOL");
      magic=CsvColumnIndex(headers,"MAGIC");
      pid=CsvColumnIndex(headers,"POSITION_ID");
      closed=CsvColumnIndex(headers,"CLOSED");
      accounting=CsvColumnIndex(headers,"ACCOUNTING_RESOLVED");
      if(schema<0 || symbol<0 || magic<0 || pid<0 || closed<0) return false;
   haveHeader=true; gTradeCsvIndexLoaded=true;
    }
    else if(StringLen(record)>0)
    {
      string fields[];
      if(!CsvParseRecord(record,fields) || ArraySize(fields)!=ArraySize(headers))
      { Print("[Scalper 1995][TRADE_CSV_INCOMPLETE_OR_INVALID_ROW] ",fileName); return
false; }
      if(fields[schema]=="S1995" && fields[symbol]==Symbol() &&
         fields[magic]==IntegerToString(gMagicCore) && fields[closed]=="1")
      {
         ulong positionID=0;
         if(!CsvParsePID(fields[pid],positionID) || !TradeCsvAddPID(positionID))
         { Print("[Scalper 1995][TRADE_CSV_INDEX_INVALID_PID] ",fileName); return false; }
         if(accounting>=0 && fields[accounting]=="0")
         {
            if(!PersistEconomicMarker(positionID)) gEconomicMarkerScanUnresolved=true;
            RememberDeferredAccountingPID(positionID);
         }
      }
    }
 }
  if(!haveHeader || inQuote || recordStart!=len)
  { Print("[Scalper 1995][TRADE_CSV_INCOMPLETE_TAIL] append disabled: ",fileName); return
false; }
  gTradeCsvAppendSafe=true;
  return true;
}

void CsvConfigHeader(string &line)
{
  CsvAdd(line,"SCHEMA_VERSION");
  CsvAdd(line,"MACRO_GATE_ENABLED");
  CsvAdd(line,"LATE_DIRECTION_BLOCK_ENABLED");
  CsvAdd(line,"REJECT_POC_TIES");
  CsvAdd(line,"SYMBOL");
  CsvAdd(line,"MAGIC");
}

void CsvConfigRow(string &line)
{
  CsvAdd(line,"S1995"); // SCHEMA_VERSION
  CsvAdd(line,"1"); // historical schema slot; retired strategy switch, no decision use
  CsvAdd(line,"1"); // historical schema slot; retired strategy switch
// LATE_DIRECTION_BLOCK_ENABLED
  CsvAdd(line,"0"); // historical schema slot; retired POC switch, no decision use
  CsvAdd(line,Symbol()); // SYMBOL
  CsvAdd(line,IntegerToString(gMagicCore)); // MAGIC
}

















void CsvTradeHeader(string &line)
{
  CsvAdd(line,"TIMESTAMP");
  CsvAdd(line,"POSITION_ID");
  CsvAdd(line,"DIR");
  CsvAdd(line,"ROUTE");
  CsvAdd(line,"MODE");
  CsvAdd(line,"ENTRY_TIME");
  CsvAdd(line,"EXIT_TIME");
  CsvAdd(line,"TOTAL_VOLUME_IN");
  CsvAdd(line,"TOTAL_VOLUME_OUT");
  CsvAdd(line,"WEIGHTED_ENTRY_PRICE");
  CsvAdd(line,"WEIGHTED_EXIT_PRICE");
   CsvAdd(line,"BREAKOUT_PRICE");
   CsvAdd(line,"BREAKOUT_PRICE_AVAILABLE");
   CsvAdd(line,"REQUEST_PRICE");
   CsvAdd(line,"ENTRY_SLIPPAGE");
   CsvAdd(line,"REQUEST_PRICE_STATUS");
   CsvAdd(line,"SL_PRICE");
   CsvAdd(line,"TP_PRICE");
   CsvAdd(line,"MAE");
   CsvAdd(line,"MFE");
   CsvAdd(line,"HOLD_SECONDS");
   CsvAdd(line,"GROSS_PNL");
   CsvAdd(line,"COMMISSION");
   CsvAdd(line,"FEE");
   CsvAdd(line,"SWAP");
   CsvAdd(line,"NET_PNL");
   CsvAdd(line,"INITIAL_RISK_MONEY");
   CsvAdd(line,"PNL_R");
   CsvAdd(line,"EXIT_REASON");
   CsvAdd(line,"QUOTA_COUNTED");
   CsvAdd(line,"MAE_MFE_PARTIAL_AFTER_RESTART");
   CsvAdd(line,"ACCOUNTING_RESOLVED");
   CsvAdd(line,"ACCOUNTING_STATUS");
    CsvAdd(line,"RISK_VALID");
    CsvAdd(line,"PNL_R_VALID");
    CsvAdd(line,"VOLUME_CLOSED_COMPLETE");
    CsvAdd(line,"CLOSED");
    CsvAdd(line,"DAILY_NET_PNL");
    CsvAdd(line,"DAILY_PNL_R");
    CsvAdd(line,"CONSECUTIVE_LOSSES");
    CsvAdd(line,"DAILY_RISK_BLOCKED");
    CsvAdd(line,"REQUESTS_ACCEPTED_TODAY");
    CsvAdd(line,"ORDERS_ENTERED_TODAY");
    CsvAdd(line,"HARD_FLIPS_PER_DAY");
    CsvAdd(line,"ARMED_CANCEL_HARD");
    CsvAdd(line,"OPPOSITE_REARM_AFTER_HARD");
}

void CsvTradeRow(string &line,const TradeRecord &r)
{
  CsvAdd(line,CsvTime(TimeTradeServer())); // TIMESTAMP
  CsvAdd(line,StringFormat("%I64u",r.positionID)); // POSITION_ID
  CsvAdd(line,DirStr(r.direction)); // DIR
  CsvAdd(line,r.route); // ROUTE
  CsvAdd(line,r.mode); // MODE
  CsvAdd(line,CsvTime(r.entryTime)); // ENTRY_TIME
  CsvAdd(line,CsvTime(r.exitTime)); // EXIT_TIME
  CsvAdd(line,CsvD(r.totalVolumeIn)); // TOTAL_VOLUME_IN
  CsvAdd(line,CsvD(r.totalVolumeOut)); // TOTAL_VOLUME_OUT
  CsvAdd(line,CsvD(r.weightedEntryPrice)); // WEIGHTED_ENTRY_PRICE
  CsvAdd(line,CsvD(r.weightedExitPrice)); // WEIGHTED_EXIT_PRICE
  CsvAdd(line,r.breakoutPriceAvailable ? CsvD(r.breakoutPrice) : ""); // BREAKOUT_PRICE
  CsvAdd(line,BStr(r.breakoutPriceAvailable)); // BREAKOUT_PRICE_AVAILABLE
  CsvAdd(line,r.requestPriceAvailable ? CsvD(r.requestPrice) : ""); // REQUEST_PRICE
  CsvAdd(line,r.requestPriceAvailable ? CsvD(r.entrySlippage) : ""); // ENTRY_SLIPPAGE
  CsvAdd(line,r.requestPriceAvailable ? "AVAILABLE" : (r.maeMfePartialAfterRestart ?
"REQUEST_PRICE_UNAVAILABLE_AFTER_RESTART" :
"REQUEST_PRICE_UNAVAILABLE")); // REQUEST_PRICE_STATUS
  CsvAdd(line,CsvD(r.slPrice)); // SL_PRICE
  CsvAdd(line,CsvD(r.tpPrice)); // TP_PRICE
  CsvAdd(line,CsvD(r.MAE)); // MAE
  CsvAdd(line,CsvD(r.MFE)); // MFE
  CsvAdd(line,IntegerToString(r.holdSeconds)); // HOLD_SECONDS
  CsvAdd(line,CsvD(r.grossProfit)); // GROSS_PNL
  CsvAdd(line,r.inoutCostsUnresolved ? "" : CsvD(r.commission)); // COMMISSION
  CsvAdd(line,r.inoutCostsUnresolved ? "" : CsvD(r.fee)); // FEE
  CsvAdd(line,CsvD(r.swap)); // SWAP
  CsvAdd(line,r.accountingResolved ? CsvD(r.netProfit) : ""); // NET_PNL
  CsvAdd(line,r.riskValid ? CsvD(r.initialRiskMoney) : ""); // INITIAL_RISK_MONEY
  CsvAdd(line,r.pnlRValid ? CsvD(r.PnL_R) : ""); // PNL_R
  CsvAdd(line,r.exitReason); // EXIT_REASON
  CsvAdd(line,BStr(r.quotaCounted)); // QUOTA_COUNTED
  CsvAdd(line,BStr(r.maeMfePartialAfterRestart)); //
// MAE_MFE_PARTIAL_AFTER_RESTART
  CsvAdd(line,BStr(r.accountingResolved)); // ACCOUNTING_RESOLVED
  CsvAdd(line,r.accountingResolved ? "RESOLVED" : (r.inoutCostsUnresolved ?
    "INOUT_COST_ALLOCATION_UNAVAILABLE" : (r.maeMfePartialAfterRestart ?
   "RESTART_ACCOUNTING_UNRESOLVED" : "ACCOUNTING_UNRESOLVED"))); //
// ACCOUNTING_STATUS
  CsvAdd(line,BStr(r.riskValid)); // RISK_VALID
  CsvAdd(line,BStr(r.pnlRValid)); // PNL_R_VALID
  CsvAdd(line,BStr(r.volumeClosedComplete)); // VOLUME_CLOSED_COMPLETE
  CsvAdd(line,BStr(r.closed)); // CLOSED
  CsvAdd(line,gDailyEconomicsValid ? CsvD(dailyNetPnL) : ""); // DAILY_NET_PNL
  CsvAdd(line,gDailyPnLRValid ? CsvD(dailyPnLR) : ""); // DAILY_PNL_R
  CsvAdd(line,gDailyEconomicsValid ? IntegerToString(consecutiveLosses) : ""); //
// CONSECUTIVE_LOSSES
  CsvAdd(line,BStr(dailyRiskBlocked)); // DAILY_RISK_BLOCKED
  CsvAdd(line,IntegerToString(requestsAcceptedToday)); //
// REQUESTS_ACCEPTED_TODAY
  CsvAdd(line,IntegerToString(ordersEnteredToday)); // ORDERS_ENTERED_TODAY
  CsvAdd(line,IntegerToString(hardFlipsPerDay)); // HARD_FLIPS_PER_DAY
  CsvAdd(line,IntegerToString(armedCancelHard)); // ARMED_CANCEL_HARD
  CsvAdd(line,IntegerToString(oppositeRearmAfterHard)); //
// OPPOSITE_REARM_AFTER_HARD
}


void WriteAuditRow(string status,string dirStr,string mode,
        double price,double posRel,double distD1,double effort,double trigger)
{
   // Signature retained for the unchanged financial subsystem; diagnostic only.
   if(armed.active && armed.signalID!="")
   { armed.entryReason=status; WriteEntryDiagnostic(armed,status); }
}




void WriteTradeHeader()
{
  if(csvTradeHandle == INVALID_HANDLE) return;
  string line = "";
  CsvConfigHeader(line);
  CsvTradeHeader(line);
  FileWriteString(csvTradeHandle,line + "\r\n");
}

bool WriteTradeRow(const TradeRecord &r)
{
  if(r.positionID==0 || !r.closed) return false;
  if(gTradeCsvIndexLoaded && TradeCsvContainsPID(r.positionID)) return true;
  if(csvTradeHandle == INVALID_HANDLE || !gTradeCsvIndexLoaded ||
!gTradeCsvAppendSafe)
     return false;
  string line = "";
  CsvConfigRow(line);
    CsvTradeRow(line,r);
    string payload=line + "\r\n";
    uchar encoded[];
    int expected=StringToCharArray(payload,encoded,0,WHOLE_ARRAY,CP_ACP)-1;
    if(expected<=0) return false;
      ResetLastError();
      uint written=FileWriteString(csvTradeHandle,payload);
      int writeError=GetLastError();
      if(written!=(uint)expected || writeError!=0)
      { gTradeCsvAppendSafe=false; return false; }
      ResetLastError();
      FileFlush(csvTradeHandle); // Confirmed trade finalization only.
      if(GetLastError()!=0) { gTradeCsvAppendSafe=false; return false; }
      if(!TradeCsvAddPID(r.positionID)) gTradeCsvAppendSafe=false;
      return true;
}


bool SendOrder(int direction, double unusedLots, string mode,
       double slPts, double tpPts,
       double posRel, double distD1, double effort, double trigger)
{
  string dStr=DirStr(direction);
  // Defense against an uninitialized/changed account mode. Unsupported modes
  // are already rejected explicitly by OnInit, before financial recovery or IO.
  if(!OperationalAccountModeSupported())
  { WriteAuditRow("ACCOUNT_MODE_UNSUPPORTED_OR_CHANGED",dStr,mode,0,posRel,distD1,effort,trigger); return false; }
  if(!armed.active || mode!=armed.mode || direction!=armed.dir) return false;
  if(HasOpenPosition())
  { WriteAuditRow("LATE_POSITION_BLOCK",dStr,mode,0,posRel,distD1,effort,trigger);
return false; }
 if(ordersEnteredToday>=Inp_MaxTradesDay)
 { WriteAuditRow("LATE_QUOTA_BLOCK",dStr,mode,0,posRel,distD1,effort,trigger); return
false; }
 if(dailyRiskBlocked || gAccountingUnresolved)
 { WriteAuditRow("LATE_DAILY_RISK_BLOCK",dStr,mode,0,posRel,distD1,effort,trigger);
return false; }
 if(HasExecutionInFlight())
 { WriteAuditRow("LATE_PENDING_BLOCK",dStr,mode,0,posRel,distD1,effort,trigger);
return false; }

   // FAR history work finishes BEFORE the final executable quote and any
   // persisted financial preparation; a veto never erases financial proof.
   if(FARBeforeDecision()) return false;
   // One final snapshot: all risk/stops calculations refer to this executable quote.
   MqlTick finalTick;
   if(!SymbolInfoTick(Symbol(),finalTick) || finalTick.ask<=0 || finalTick.bid<=0 ||
      finalTick.ask<finalTick.bid) return false;
   if(!EntryDispatchGuard(finalTick)) return false;
   double finalExec=(direction==1)?finalTick.ask:finalTick.bid;
   if(finalTick.ask-finalTick.bid>gSpreadMaxPts) return false;
   bool finalBreakout=(direction==1)?finalExec>=trigger:finalExec<=trigger;
   if(!finalBreakout)
   {
WriteAuditRow("LATE_BREAKOUT_LOST",dStr,mode,finalExec,posRel,distD1,effort,trigger)
; return false; }
   double over=(direction==1)?finalExec-trigger:trigger-finalExec;
   if(over>gMaxOvershoot)
   {
WriteAuditRow("LATE_OVERSHOOT_BLOCK",dStr,mode,finalExec,posRel,distD1,effort,trigger); return false; }
  double sl=NormEntrySL(direction,finalExec-direction*slPts);
  double tp=(Inp_ExitMode==PROGRESSIVE_NO_TP)?0.0:NormEntryTP(direction,finalExec+direction*tpPts);
  if(sl<=0 || !EntryTPValid(tp)) return false;
  double minDist=(double)SymbolInfoInteger(Symbol(),SYMBOL_TRADE_STOPS_LEVEL)*
      SymbolInfoDouble(Symbol(),SYMBOL_POINT);
  // Server stops are also measured from the closing quote (bid for buy, ask for sell).
  double closingQuote=(direction==1)?finalTick.bid:finalTick.ask;
  if(direction*(finalExec-sl)<minDist || (tp>0 && direction*(tp-finalExec)<minDist) ||
     direction*(closingQuote-sl)<minDist || (tp>0 && direction*(tp-closingQuote)<minDist))
  {
WriteAuditRow("STOPS_LEVEL_BLOCK",dStr,mode,finalExec,posRel,distD1,effort,trigger);
return false; }
  double lots=ComputeLotsForEntry(direction,finalExec,sl);
  if(lots<=0) return false;
  ENUM_ORDER_TYPE type=(direction==1)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
  double margin=0;
  if(!OrderCalcMargin(type,Symbol(),lots,finalExec,margin) ||
     !MathIsValidNumber(margin) || margin<0 ||
     AccountInfoDouble(ACCOUNT_MARGIN_FREE)<margin)
  { WriteAuditRow("NO_MARGIN",dStr,mode,finalExec,posRel,distD1,effort,trigger); return
false; }
   trade.SetExpertMagicNumber(gMagicCore);
   trade.SetTypeFilling(ORDER_FILLING_FOK);
   // Re-read immediately before dispatch. A moved executable quote needs fresh
   // sizing/stops; a changed closing quote always needs a fresh STOPS_LEVEL check.
   MqlTick dispatchTick;
   if(!SymbolInfoTick(Symbol(),dispatchTick)) return false;
   if(!EntryDispatchGuard(dispatchTick)) return false;
   double dispatchExec=(direction==1)?dispatchTick.ask:dispatchTick.bid;
   if(dispatchExec<=0 || dispatchTick.ask<=0 || dispatchTick.bid<=0 ||
      dispatchTick.ask<dispatchTick.bid || dispatchTick.ask-dispatchTick.bid>gSpreadMaxPts)
return false;
   if((direction==1 && dispatchExec<trigger) || (direction==-1 && dispatchExec>trigger))
   {
WriteAuditRow("LATE_BREAKOUT_LOST",dStr,mode,dispatchExec,posRel,distD1,effort,trigger); return false; }
   if(direction*(dispatchExec-trigger)>gMaxOvershoot)
   {
WriteAuditRow("LATE_OVERSHOOT_BLOCK",dStr,mode,dispatchExec,posRel,distD1,effort,trigger); return false; }
   if(dispatchExec!=finalExec)
   {
      finalExec=dispatchExec;
      sl=NormEntrySL(direction,finalExec-direction*slPts);
      tp=(Inp_ExitMode==PROGRESSIVE_NO_TP)?0.0:NormEntryTP(direction,finalExec+direction*tpPts);
      lots=ComputeLotsForEntry(direction,finalExec,sl);
      closingQuote=(direction==1)?dispatchTick.bid:dispatchTick.ask;
      if(sl<=0 || !EntryTPValid(tp) || lots<=0 || direction*(closingQuote-sl)<minDist ||
     (tp>0 && direction*(tp-closingQuote)<minDist))
      {
WriteAuditRow("STOPS_LEVEL_BLOCK",dStr,mode,finalExec,posRel,distD1,effort,trigger);
return false; }
      if(!OrderCalcMargin(type,Symbol(),lots,finalExec,margin) || !MathIsValidNumber(margin)
|| margin<0 || AccountInfoDouble(ACCOUNT_MARGIN_FREE)<margin)
      { WriteAuditRow("NO_MARGIN",dStr,mode,finalExec,posRel,distD1,effort,trigger); return
false; }
   }
   closingQuote=(direction==1)?dispatchTick.bid:dispatchTick.ask;
   if(direction*(finalExec-sl)<minDist || (tp>0 && direction*(tp-finalExec)<minDist) ||
      direction*(closingQuote-sl)<minDist || (tp>0 && direction*(tp-closingQuote)<minDist))
   {
WriteAuditRow("STOPS_LEVEL_BLOCK",dStr,mode,finalExec,posRel,distD1,effort,trigger);
return false; }
   if(HasOpenPosition()) return false;
   if(HasOwnPendingOrder() || HasExecutionInFlight())
   {
WriteAuditRow("LATE_PENDING_BLOCK",dStr,mode,finalExec,posRel,distD1,effort,trigger)
; return false; }
   // Validate the executable quote again AFTER calculations, then finish all
   // guards before touching the durable financial preparation protocol.
   MqlTick lastDispatchTick;
   if(armed.entry.enabled)
   {
      if(!SymbolInfoTick(Symbol(),lastDispatchTick) || !EntryDispatchGuard(lastDispatchTick)) return false;
      // Preserve the original recalculation protocol if this quote moved.
      double lastExec=direction==1?lastDispatchTick.ask:lastDispatchTick.bid;
      if(lastExec!=finalExec)
      {
         finalExec=lastExec;
         sl=NormEntrySL(direction,finalExec-direction*slPts);
         tp=(Inp_ExitMode==PROGRESSIVE_NO_TP)?0.0:NormEntryTP(direction,finalExec+direction*tpPts);
         lots=ComputeLotsForEntry(direction,finalExec,sl);
         if(lots<=0 || !OrderCalcMargin(type,Symbol(),lots,finalExec,margin) ||
            !MathIsValidNumber(margin) || margin<0 || AccountInfoDouble(ACCOUNT_MARGIN_FREE)<margin)
         { WriteAuditRow("NO_MARGIN",dStr,mode,finalExec,posRel,distD1,effort,trigger); return false; }
      }
      closingQuote=direction==1?lastDispatchTick.bid:lastDispatchTick.ask;
      if(sl<=0 || !EntryTPValid(tp) || direction*(finalExec-sl)<minDist ||
         (tp>0 && direction*(tp-finalExec)<minDist) || direction*(closingQuote-sl)<minDist ||
         (tp>0 && direction*(tp-closingQuote)<minDist))
      { WriteAuditRow("STOPS_LEVEL_BLOCK",dStr,mode,finalExec,posRel,distD1,effort,trigger); return false; }
      if(!ClaimEntryDispatch(armed.entry)) return false;
      armed.dispatchQuoteMsc=lastDispatchTick.time_msc;
      armed.dispatchAsk=lastDispatchTick.ask; armed.dispatchBid=lastDispatchTick.bid;
      armed.requestPrice=finalExec;
   }
   if(!armed.entry.enabled)
   {
      armed.dispatchQuoteMsc=dispatchTick.time_msc;
      armed.dispatchAsk=dispatchTick.ask; armed.dispatchBid=dispatchTick.bid;
      armed.requestPrice=finalExec;
   }
   armed.lots=lots; // execution telemetry only; never Stage 1 risk sizing
   if(!PreparePendingExec(direction,armed.route,mode,finalExec,lots,sl,tp)) return false;
  gPendingExec.breakoutPrice=gLastBreakoutPrice;
  gPendingExec.breakoutPriceAvailable=gLastBreakoutPrice>0;
  if(!MarkRequestDispatchPossible(false))
  { ResetPendingExec(); return false; } // No dispatch occurred; absence is proved locally.
  // Only capture memory here: diagnostic disk/history IO occurs after the
  // original financial completion protocol, never between barrier and send.
  int entryDiagnosticIndex=RememberEntryDispatch();
  bool
sent=trade.PositionOpen(Symbol(),type,lots,finalExec,sl,tp,"S1995|"+armed.route+"|"+mode);
  uint ret=trade.ResultRetcode();
  MqlTradeResult executionResult;
  trade.Result(executionResult);

CompletePendingExec(sent,ret,trade.ResultOrder(),trade.ResultDeal(),executionResult.request_id);
 BindEntryDispatch(entryDiagnosticIndex,executionResult.order,executionResult.deal,executionResult.request_id);
 bool accepted=sent && (ret==TRADE_RETCODE_DONE ||
ret==TRADE_RETCODE_PLACED || ret==TRADE_RETCODE_DONE_PARTIAL);

WriteAuditRow(accepted?"REQUEST_ACCEPTED":"ORDER_FAILED",dStr,mode,finalExec
,posRel,distD1,effort,trigger);
  return accepted;
}

//=====================================================================
// STAGE 1 — EVALUATE MATRIX
//=====================================================================


void EvaluateMatrix()
{
   datetime bar=iTime(Symbol(),Inp_SignalTF,0);
   if(bar<=gObjectiveAttachBar || bar==gLastMatrixEvalBar) return;
   OMThesis s;
   datetime closed=iTime(Symbol(),Inp_SignalTF,1);
   if(closed<=0 || closed+PeriodSeconds(Inp_SignalTF)!=bar || !OMGetClosed(closed,s)) return;
   if(armed.active) return;
   if(!s.detected || !s.eligible) { gLastMatrixEvalBar=bar; return; }
   if(gAccountingUnresolved || HasExecutionInFlight() || HasOpenPosition()) return;
   if((s.route=="ABS" && !Inp_EnableAbsorption) || (s.route=="CONT" && !Inp_EnableContinuation))
   { gLastMatrixEvalBar=bar; return; }
   double signalClose=iClose(Symbol(),Inp_SignalTF,1);
   if(!EntryGridValid(signalClose) || signalClose!=s.price)
   {
      ArmedSignal rejected; ZeroMemory(rejected);
      rejected.signalID=NewEntrySignalID(); rejected.entryReason="M1_TRADE_CLOSE_MISMATCH";
      rejected.entry.signalReferencePrice=signalClose;
      WriteEntryDiagnostic(rejected,"M1_TRADE_CLOSE_MISMATCH");
      gLastMatrixEvalBar=bar; return;
   }
   MqlTick clock;
   if(!SymbolInfoTick(Symbol(),clock) || !OMLiveReady(clock.time_msc) ||
      clock.time_msc<(long)bar*1000 || clock.last!=gOMLastPrice) return;
   gLastMatrixEvalBar=bar;
   EntryTriggerState entry; string reason;
   if(!InitSignalCloseTrigger(entry,s.dir,signalClose,gBreakoutMargin,clock.time_msc,reason)) return;
   if(s.route=="CONT" && !ObjectiveContInsideB3(s.dir,entry.trigger,s.bands))
   {
      ArmedSignal rejected; ZeroMemory(rejected);
      rejected.dir=s.dir; rejected.route=s.route;
      rejected.mode=s.route=="CONT"?"BASE_CONT":"BASE";
      rejected.entry=entry; rejected.signalID=NewEntrySignalID();
      rejected.entryReason="CONT_TRIGGER_OUTSIDE_B3";
      WriteEntryDiagnostic(rejected,"CONT_TRIGGER_OUTSIDE_B3"); return;
   }
   if(iTime(Symbol(),Inp_SignalTF,0)!=bar) return;
   ZeroMemory(armed); armed.active=true; armed.dir=s.dir;
   armed.route=s.route; armed.mode=s.route=="CONT"?"BASE_CONT":"BASE";
   armed.activeSL_Pts=gSL_Pts; armed.activeTP_Pts=gTP_Pts;
   armed.armedAt=TimeTradeServer(); armed.regionEndTime=iTime(Symbol(),Inp_SignalTF,1);
   armed.effort=s.effort; armed.vwapVig=s.bands.vwap; armed.entry=entry;
   armed.signalID=NewEntrySignalID(); armed.entryReason="SIGNAL_DETECTED";
   gObjectiveArmed=s;
   // Exact original default two closed M1 extremes, EXCLUSIVELY for FAR protection.
   // A failed collection does not block arm or invent favorable FAR evidence.
   MqlRates region[];
   if(CopyRates(Symbol(),Inp_SignalTF,1,2,region)==2)
   {
      bool valid=true; double high=0,low=DBL_MAX;
      for(int i=0;i<2;i++)
      {
         if(!FARPriceValid(region[i].high) || !FARPriceValid(region[i].low) ||
            region[i].high<region[i].low) { valid=false; break; }
         high=MathMax(high,region[i].high); low=MathMin(low,region[i].low);
      }
      if(valid) { armed.regionHigh=high; armed.regionLow=low; }
   }
   gCachedMicroBar=bar;
   FARCaptureArm();
   WriteEntryDiagnostic(armed,"SIGNAL_DETECTED");
   WriteAuditRow("ARMED",DirStr(armed.dir),armed.mode,signalClose,0,0,s.effort,entry.trigger);
}

//=====================================================================
// STAGE 2 — PROCESS ARMED SIGNAL
// Preserva toda a lógica da v2.44.
//=====================================================================
void ProcessArmedSignal()
{
   if(!armed.active || HasExecutionInFlight() || HasOpenPosition() || gAccountingUnresolved) return;
   datetime now=TimeTradeServer();
   if(EntryTimeoutExpired(armed.armedAt,now,Inp_ArmedTimeoutSec))
   { WriteAuditRow("TIMEOUT_ARMED",DirStr(armed.dir),armed.mode,0,0,0,0,ArmedTriggerPrice()); ResetArmedSignal(); return; }
   MqlDateTime dt; TimeToStruct(now,dt);
   if(dt.hour*100+dt.min>=Inp_StopEntryHHMM)
   { WriteAuditRow("ABORT_SESSION_END",DirStr(armed.dir),armed.mode,0,0,0,0,ArmedTriggerPrice()); ResetArmedSignal(); return; }
   if(ordersEnteredToday>=Inp_MaxTradesDay || dailyRiskBlocked) return;
   MqlTick tk;
   if(!SymbolInfoTick(Symbol(),tk)) return;
   if(!EntryGridValid(tk.ask) || !EntryGridValid(tk.bid) || tk.ask<tk.bid) return;
   // Original terminal overshoot precedes the spread hold and strategy data work.
   // Only an actual post-thesis trade beyond the frozen trigger is evidence.
   if(EntryRealTrade(tk) && tk.time_msc>armed.entry.thesisMsc &&
      (armed.dir==1?tk.last>=armed.entry.trigger:tk.last<=armed.entry.trigger))
   {
      double overLast=armed.dir*(tk.last-armed.entry.trigger);
      double overExec=armed.dir*((armed.dir==1?tk.ask:tk.bid)-armed.entry.trigger);
      if(MathMax(overLast,overExec)>gMaxOvershoot)
      { WriteAuditRow("OVERSHOOT_BLOCK",DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice()); ResetArmedSignal(); return; }
   }
   string reason;
   if(!ObjectiveRevalidate(reason)) return;
   if(FARBeforeDecision()) return;
   if(!OMLiveReady(tk.time_msc)) return;
   // Geography may invalidate before trigger confirmation, but never closes a position.
   if(armed.route=="CONT" &&
      !ObjectiveContInsideB3(armed.dir,armed.dir==1?tk.ask:tk.bid,gObjectiveArmed.bands))
   { WriteAuditRow("CONT_EXEC_OUTSIDE_B3",DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice()); ResetArmedSignal(); return; }
   if(ObserveEntryTrade(armed.entry,tk,reason)==1)
      WriteAuditRow("TRIGGER_CONFIRMED",DirStr(armed.dir),armed.mode,tk.last,0,0,0,ArmedTriggerPrice());
   // Quote-only callbacks can use already-proven Last without inventing a new trade.
   if(!EntryDispatchGuard(tk)) return;
   if(!SpreadOk()) return;
   double trigger=ArmedTriggerPrice();
   gLastBreakoutPrice=tk.last;
   WriteEntryDiagnostic(armed,"DISPATCH_CANDIDATE");
   SendOrder(armed.dir,armed.lots,armed.mode,armed.activeSL_Pts,armed.activeTP_Pts,
             armed.posRel,armed.distD1,armed.effort,trigger);
   if(!armed.active) return;
   // A transient pre-preparation guard failure may wait within the ORIGINAL timeout.
   // A claimed/attempted signal is never sent twice; financial ambiguity owns recovery.
   if(armed.entry.dispatchAttempted || HasExecutionInFlight() || HasOpenPosition()) ResetArmedSignal();
}

//=====================================================================
// PERSISTENCE (adaptada da v2.44, chaves prefixadas com "SCALP_1995_")
//=====================================================================




//=====================================================================
// EOD (adaptado da v2.44)
//=====================================================================
void ProcessEOD(int hhmm)
{
   if(hhmm<Inp_EOD_CloseHHMM) return;
   if(armed.active)
   {

WriteAuditRow("ABORT_EOD",DirStr(armed.dir),armed.mode,0,armed.posRel,armed.distD1
,armed.effort,0);
      ResetArmedSignal();
   }
   if(eodDone) return;
   // A live own order can be an entry, a close, or unresolved. Never duplicate it.
   if(gPendingOrderClassificationUnresolved || gPendingExit.active || gPendingExec.active ||
      gOrderObligationScanUnresolved ||
      gRequestJournalUnresolved || gRequestJournalWritePending ||
      gEntryJournalCleanupPending || gExitJournalCleanupPending ||
gIdentityLossUnresolved
||
HasOwnPendingOrder())
   {
      // Recovery still runs in OnTimer; this diagnostic must precede the guards.
      static datetime nextBlockedDiagnostic=0;
      datetime blockedAt=TimeTradeServer();
      if(blockedAt>=nextBlockedDiagnostic && HasOwnPositionStrict())
      {
         nextBlockedDiagnostic=blockedAt+10;
         PrintFormat("[SCALPER][EOD_CRITICAL_BLOCKED] hhmm=%d entry=%d exit=%d journal_invalid=%d journal_write=%d entry_cleanup=%d exit_cleanup=%d; reconciliation required, no close dispatched.",
           hhmm,(int)gPendingExec.active,(int)gPendingExit.active,
       (int)gRequestJournalUnresolved,(int)gRequestJournalWritePending,
       (int)gEntryJournalCleanupPending,(int)gExitJournalCleanupPending);
   }
   return;
  }
  if(!HasOwnPositionStrict())
   { if(!HasExecutionInFlight() && !gLiveOwnershipUnresolved) eodDone=true; return; }
  if(hhmm>=1830)
  {
     if(!eodStuckLogged) { eodStuckLogged=true; Print("[SCALPER][EOD_STUCK] Own position remains open after 18:30."); }
     return;
  }
  datetime now=TimeTradeServer();
  if(eodNextTry>0 && now<eodNextTry) return;
  eodNextTry=now+10;
  for(int i=PositionsTotal()-1;i>=0;i--)
  {
     if(!posInfo.SelectByIndex(i) || posInfo.Symbol()!=Symbol() ||
posInfo.Magic()!=(long)gMagicCore) continue;
     ulong ticket=posInfo.Ticket(), identifier=posInfo.Identifier();
     if(!OwnPositionSafe(identifier))
     { Print("[SCALPER][EOD_FOREIGN_NETTING_BLOCK] Ownership ambiguous; manual reconciliation required."); return; }
     BeginExitIntent(identifier,"EOD");
     gPendingExit.dispatchPhase=REQUEST_PREPARED;
     trade.SetExpertMagicNumber(gMagicCore);
     gPendingExit.positionTicket=ticket;
     gPendingExit.requestSnapshot.action=TRADE_ACTION_DEAL;
     gPendingExit.requestSnapshot.position=ticket;
     gPendingExit.requestSnapshot.symbol=Symbol();
     gPendingExit.requestSnapshot.magic=(ulong)gMagicCore;
     gPendingExit.requestSnapshot.type=(posInfo.PositionType()==POSITION_TYPE_BUY?
        ORDER_TYPE_SELL:ORDER_TYPE_BUY);
     gPendingExit.requestSnapshot.volume=posInfo.Volume();
     gPendingExit.requestSnapshot.price=SymbolInfoDouble(Symbol(),

gPendingExit.requestSnapshot.type==ORDER_TYPE_BUY?SYMBOL_ASK:SYMBOL_BID);
 gPendingExit.requestSnapshot.deviation=(ulong)gMaxDeviationPts;
 gPendingExit.requestSnapshot.type_filling=ORDER_FILLING_FOK;
 if(!PersistRequestJournal(true))
 {
    PrintFormat("[SCALPER][EOD_PERSISTENCE_CRITICAL] pid=%I64u PREPARED write failed; no close dispatched.",identifier);
    FailExitIntent(identifier,true); return;
 }
 if(!MarkRequestDispatchPossible(true))
 {
     PrintFormat("[SCALPER][EOD_PERSISTENCE_CRITICAL] pid=%I64u dispatch barrier failed; no close dispatched.",identifier);
     FailExitIntent(identifier,true); return;
  }
  trade.PositionClose(ticket);
    MqlTradeResult closeResult;
    trade.Result(closeResult);
    trade.Request(gPendingExit.requestSnapshot);
    uint ret=closeResult.retcode;
    CompletePendingExit(closeResult);
    PrintFormat("[SCALPER][EOD_REQUEST] ticket=%I64u ret=%u; closure requires confirmed deals.",ticket,ret);
    break;
  }
}

//=====================================================================
// DAILY RESET (adaptado da v2.44)
//=====================================================================
void DailyReset()
{
   ResetArmedSignal(); OMReset();
   gLastMatrixEvalBar=0;
   gObjectiveAttachBar=iTime(Symbol(),Inp_SignalTF,0);
   eodDone=false; eodStuckLogged=false; eodNextTry=0;
   ResetAccountingDay(); // literal financial reset/reconstruction, open lifecycle retained
}

//=====================================================================
// ON INIT
//=====================================================================
bool Positive(double value)
{ return MathIsValidNumber(value) && value>0; }
bool OnPriceGrid(double value)
{ return Positive(value) && MathAbs(value/gTickSize-MathRound(value/gTickSize))<=1e-6; }
bool ValidHHMM(int hhmm)
{ return hhmm>=0 && hhmm/100<=23 && hhmm%100<=59; }
bool OnVolumeGrid(double value, double step)
{ return Positive(value) && MathAbs(value/step-MathRound(value/step))<=1e-6; }
bool EntryTPValid(double tp)
{
   return MathIsValidNumber(tp) &&
      (Inp_ExitMode==PROGRESSIVE_NO_TP ? tp==0.0 : tp>0.0);
}

bool Validate1995Inputs()
{
   if((Inp_ExitMode!=ORIGINAL_FIXED_TP && Inp_ExitMode!=PROGRESSIVE_NO_TP) ||
      Inp_MaxProtectedR<1 || Inp_MaxProtectedR>5 ||
      (Inp_AggressionFilterMode!=FAR_OFF && Inp_AggressionFilterMode!=FAR_OBSERVAR &&
       Inp_AggressionFilterMode!=FAR_APLICAR) ||
      !MathIsValidNumber(Inp_AggressionThresholdPct) ||
      Inp_AggressionThresholdPct<=50 || Inp_AggressionThresholdPct>100) return false;
   if(Inp_ExitMode==PROGRESSIVE_NO_TP && !Inp_EnableBreakEven)
   { Print("[Scalper 1995][CONFIG] PROGRESSIVE_NO_TP requires Inp_EnableBreakEven=true"); return false; }
   int ctxSec=PeriodSeconds(Inp_ContextTF), sigSec=PeriodSeconds(Inp_SignalTF);
   if(ctxSec<=0 || sigSec<=0 || ctxSec<=sigSec) return false;
   if(!ValidHHMM(Inp_StartHHMM) || !ValidHHMM(Inp_StopEntryHHMM) ||
      !ValidHHMM(Inp_EOD_CloseHHMM) || Inp_StartHHMM>=Inp_StopEntryHHMM ||
      Inp_StopEntryHHMM>=Inp_EOD_CloseHHMM) return false;
   if(Inp_ArmedTimeoutSec<=0 || Inp_MaxTradesDay<1 || Inp_MaxTradesDay>MAX_TRADE_RECORDS) return false;
   if(!Positive(gSL_Pts) || !MathIsValidNumber(gTP_Pts) ||
      (Inp_ExitMode==ORIGINAL_FIXED_TP ? !Positive(gTP_Pts) : gTP_Pts<0) || !Positive(gSpreadMaxPts) ||
      !Positive(gMaxOvershoot)) return false;
   if(!OnPriceGrid(gSL_Pts) || (gTP_Pts!=0 && !OnPriceGrid(gTP_Pts)) || !OnPriceGrid(gMaxOvershoot) ||
      !OnPriceGrid(gBreakoutMargin) || gBreakoutMargin<gTickSize-1e-9) return false;
   if(Inp_CooldownSec<0 || Inp_LossCooldownSec<0) return false;
   if(gMagicCore<=0 || gMaxDeviationPts<0) return false;
   if(Inp_SizingMode!=SIZING_FIXED && Inp_SizingMode!=SIZING_RISK_PERCENT)
return false;
   double minimum=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);
   double maximum=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_STEP);
   if(!Positive(minimum) || !Positive(maximum) || maximum<minimum || !Positive(step)) return
false;
  if(!OnVolumeGrid(Inp_MaxLots,step) || Inp_MaxLots<minimum || Inp_MaxLots>maximum)
return false;
  if(Inp_SizingMode==SIZING_FIXED && (!OnVolumeGrid(Inp_FixedLots,step) ||
     Inp_FixedLots<minimum || Inp_FixedLots>maximum || Inp_FixedLots>Inp_MaxLots))
return false;
  if(Inp_SizingMode==SIZING_RISK_PERCENT && !Positive(Inp_RiskPerTradePct)) return
false;
  if(Inp_EnableDailyRiskStop && !Positive(Inp_MaxDailyLossR)) return false;
  if(Inp_EnableConsecutiveLossStop && Inp_MaxConsecutiveLosses<1) return false;
  if(!Inp_EnableAbsorption && !Inp_EnableContinuation) return false;
  if(!Positive(Inp_ABS_Effort) || !Positive(Inp_CONT_Effort) ||
     !Positive(gABS_MinDisplPts) || !Positive(gCONT_MinDisplPts)) return false;
  return OMValidateInputs();
}
void BootstrapCachesNoTrade()
{
   gObjectiveAttachBar=iTime(Symbol(),Inp_SignalTF,0);
   gLastMatrixEvalBar=gObjectiveAttachBar;
   OMReset(); // reconstruction never arms historical bars
}

// Restore 1.122 account compatibility. Ownership/conflict checks remain per action;
// neither Magic nor the local instance lock proves cross-terminal exclusivity.
bool InitializeAccountMode()
{
   gAccountMarginMode=(ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE);
   gNetting=(gAccountMarginMode==ACCOUNT_MARGIN_MODE_RETAIL_NETTING ||
             gAccountMarginMode==ACCOUNT_MARGIN_MODE_EXCHANGE);
   gExchange=(gAccountMarginMode==ACCOUNT_MARGIN_MODE_EXCHANGE);
   switch(gAccountMarginMode)
   {
      case ACCOUNT_MARGIN_MODE_RETAIL_HEDGING:
         Print("[Scalper 1995][ACCOUNT_MODE] RETAIL_HEDGING: supported; own positions require order/history identity, not Magic alone.");
         return true;
      case ACCOUNT_MARGIN_MODE_RETAIL_NETTING:
         Print("[Scalper 1995][ACCOUNT_MODE] RETAIL_NETTING: supported; consolidated-position ownership and conflicts checked by order/history identity; no cross-terminal exclusivity assumed.");
         return true;
      case ACCOUNT_MARGIN_MODE_EXCHANGE:
         Print("[Scalper 1995][ACCOUNT_MODE] EXCHANGE: supported; consolidated-position ownership and conflicts checked by order/history identity; no cross-terminal exclusivity assumed.");
         return true;
   }
   Print("[Scalper 1995][INIT_REJECTED] Unknown ACCOUNT_MARGIN_MODE; no trading or financial recovery started.");
   return false;
}

bool OperationalAccountModeSupported()
{
   return (gAccountMarginMode==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING ||
           gAccountMarginMode==ACCOUNT_MARGIN_MODE_RETAIL_NETTING ||
           gAccountMarginMode==ACCOUNT_MARGIN_MODE_EXCHANGE) &&
      (ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE)==gAccountMarginMode;
}

int OnInit()
{
  if(!InitializeAccountMode()) return INIT_PARAMETERS_INCORRECT;
  string sym=Symbol();
  gIsDollarFamily=(StringFind(sym,"WDO")>=0 || StringFind(sym,"DOL")>=0);
  gIsIndexFamily=!gIsDollarFamily && (StringFind(sym,"WIN")>=0 ||
StringFind(sym,"IND")>=0);
  if(!gIsDollarFamily && !gIsIndexFamily)
  { Print("[Scalper 1995][CONFIG] Unsupported contract symbol: ",sym); return INIT_PARAMETERS_INCORRECT; }
  gBandMultiplier=gIsIndexFamily?Inp_BandMultiplier_WIN:Inp_BandMultiplier_WDO;
  gMagicCore=gIsIndexFamily?Inp_Magic_WIN:Inp_Magic_WDO;

gMaxDeviationPts=gIsIndexFamily?Inp_MaxDeviationPts_WIN:Inp_MaxDeviationPts_WDO;
gSpreadMaxPts=gIsIndexFamily?Inp_SpreadMaxPts_WIN:Inp_SpreadMaxPts_WDO;
gBreakoutMargin=gIsIndexFamily?Inp_BreakoutMargin_WIN:Inp_BreakoutMargin_WDO;
gMaxOvershoot=gIsIndexFamily?Inp_MaxOvershoot_WIN:Inp_MaxOvershoot_WDO;
gSL_Pts=gIsIndexFamily?Inp_SL_Pts_WIN:Inp_SL_Pts_WDO;
gTP_Pts=gIsIndexFamily?Inp_TP_Pts_WIN:Inp_TP_Pts_WDO;

gABS_MinDisplPts=gIsIndexFamily?Inp_ABS_MinPriceMovePts_WIN:Inp_ABS_MinPriceMovePts_WDO;

gCONT_MinDisplPts=gIsIndexFamily?Inp_CONT_MinPriceMovePts_WIN:Inp_CONT_MinPriceMovePts_WDO;
  gTickSize=SymbolInfoDouble(Symbol(),SYMBOL_TRADE_TICK_SIZE);
   // Tick-grid normalization must use the actual trade tick size, never _Point.
   if(!Positive(gTickSize))
   { Print("[Scalper 1995][CONFIG] SYMBOL_TRADE_TICK_SIZE unavailable"); return INIT_PARAMETERS_INCORRECT; }
  if(!Positive(Inp_BandMultiplier_WIN) || !Positive(Inp_BandMultiplier_WDO) ||
     !Positive(gTickSize) || !Validate1995Inputs())
  { Print("[SCALPER][FATAL] Invalid Scalper 1995 parameters; no silent correction."); return
INIT_PARAMETERS_INCORRECT; }
  if(!IsFokSupported())
  { Print("[SCALPER][FATAL] FOK unsupported."); return
INIT_PARAMETERS_INCORRECT; }
  trade.SetExpertMagicNumber(gMagicCore);
  trade.SetDeviationInPoints(gMaxDeviationPts);
  trade.SetTypeFilling(ORDER_FILLING_FOK);
  trade.SetAsyncMode(false);
  // Same-version instances in this terminal must not race financial journals.
  // This is not a cross-terminal or non-cooperating-EA ownership guarantee.
  string lockName=StringFormat("Scalper1995_%I64d_%s_%d.instance.lock",
     AccountInfoInteger(ACCOUNT_LOGIN),sym,gMagicCore);
  gInstanceLock=FileOpen(lockName,FILE_READ|FILE_WRITE|FILE_BIN);
  if(gInstanceLock==INVALID_HANDLE)
  { Print("[Scalper 1995][INSTANCE_LOCK_UNAVAILABLE] initialization blocked"); return INIT_FAILED; }
  MqlDateTime now; TimeToStruct(TimeTradeServer(),now);
  gDayKey=now.year*1000+now.day_of_year;
  ResetArmedSignal(); ResetOpenPos();
  InitializeAccounting();
  gLastFlushTime=0; eodDone=false; eodStuckLogged=false; eodNextTry=0;
  RestoreDailyPersistence();
  BootstrapCachesNoTrade();
// A configurable label cannot remove the explicit schema namespace.
string prefix="Scalper1995_";
if(CSVFileName!="Scalper1995" && CSVFileName!="") prefix+=CSVFileName+"_";
string suffix=Symbol()+"_"+IntegerToString(gMagicCore);
gTradeCsvFileName=prefix+suffix+"_Trades.csv";
EntryDiagnosticsInit(); // session-local stream; originals and financial recovery are untouched

csvTradeHandle=FileOpen(prefix+suffix+"_Trades.csv",FILE_READ|FILE_WRITE|FILE_TXT
|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE);
  if(csvTradeHandle!=INVALID_HANDLE)
  {
     if(FileSize(csvTradeHandle)==0) WriteTradeHeader();
     FileFlush(csvTradeHandle);
     if(!InitializeTradeCsvIndex(prefix+suffix+"_Trades.csv"))
        Print("[SCALPER][TRADES_CSV_INDEX_UNAVAILABLE] Finalization records require CSV reconciliation.");
     FileSeek(csvTradeHandle,0,SEEK_END);
  }
  // One-second analytical catch-up also in tester; financial recovery retains its own throttles.
  gFinancialTimerDue=TimeTradeServer()+(MQLInfoInteger(MQL_TESTER)!=0?60:1);
  if(!EventSetTimer(1)) return INIT_FAILED;
  Print("[Remora Objective] EXPERIMENTAL; native compilation/replay not certified; financial namespace S1995 retained.");
  PrintFormat("[OBJECTIVE_INPUTS] warmup_sec=%d min_trades=%d min_sigma_ticks=%.8f session_start=%d session_end=%d max_gap_sec=%d baseline_waves=%d reversal_pts=%.8f event_ticks=%d CONT_eff=%.8f ABS_eff=%.8f rejection=%.8f chunk_msc=%d max_records=%d chunks_per_timer=%d sigma_tolerance_ticks=%.12f",
     Inp_BandsWarmupSec,Inp_BandsMinTrades,Inp_BandsMinSigmaTicks,
     Inp_RegularSessionStartHHMM,Inp_RegularSessionEndHHMM,Inp_FeedMaxGapSec,
     Inp_WaveBaselineMin,gIsIndexFamily?Inp_WaveReversalPts_WIN:Inp_WaveReversalPts_WDO,
     Inp_PathEventTicks,Inp_CONT_MinPathEfficiency,Inp_ABS_MaxPathEfficiency,
     Inp_ABS_MinRejectionFraction,Inp_DataChunkMsc,Inp_DataMaxChunkTrades,
     Inp_DataChunksPerTimer,Inp_SigmaCheckToleranceTicks);
  PrintFormat("[OBJECTIVE_EFFECTIVE] symbol=%s magic=%d context=%s signal=%s k=%.8f abs_volume_ratio=%.8f cont_volume_ratio=%.8f abs_progress=%.8f cont_progress=%.8f trigger_margin=%.8f timeout=%d spread=%.8f overshoot=%.8f deviation=%d SL=%.8f TP_input=%.8f exit=%s FAR=%s FAR_threshold=%.8f",
     sym,gMagicCore,EnumToString(Inp_ContextTF),EnumToString(Inp_SignalTF),gBandMultiplier,
     Inp_ABS_Effort,Inp_CONT_Effort,gABS_MinDisplPts,gCONT_MinDisplPts,gBreakoutMargin,
     Inp_ArmedTimeoutSec,gSpreadMaxPts,gMaxOvershoot,gMaxDeviationPts,gSL_Pts,gTP_Pts,
     EnumToString(Inp_ExitMode),EnumToString(Inp_AggressionFilterMode),Inp_AggressionThresholdPct);
  return INIT_SUCCEEDED;
}

//=====================================================================
// ON DEINIT
//=====================================================================
void OnDeinit(const int reason)
{
   EventKillTimer(); OMClose();
   EntryDiagnosticsClose();
   if(gInstanceLock!=INVALID_HANDLE) { FileClose(gInstanceLock); gInstanceLock=INVALID_HANDLE; }
   if(csvTradeHandle !=INVALID_HANDLE){ FileFlush(csvTradeHandle);
FileClose(csvTradeHandle); csvTradeHandle =INVALID_HANDLE; }
}

//=====================================================================
// ON TICK
//=====================================================================
// Accounting/execution uncertainty still blocks entries. This observer has no
// access to the arming path and does not populate its shared snapshot cache.


void ObjectiveDecisionCycle()
{
   datetime bar=iTime(Symbol(),Inp_SignalTF,0);
   if(bar<=0) return;
   // Observation never changes an existing thesis, its trigger, or its timeout.
   datetime closed=iTime(Symbol(),Inp_SignalTF,1);
   OMThesis observed;
   if(closed>0 && closed!=gObjectiveObservedBar && OMGetClosed(closed,observed))
   {
      gObjectiveObservedBar=closed;
      if(armed.active) OMTelemetry("OBSERVATION_WHILE_ARMED",observed);
      else if(gAccountingUnresolved || HasExecutionInFlight() || HasOpenPosition())
         OMTelemetry("OBSERVATION_FINANCIAL_BLOCK",observed);
   }
   // Closed snapshots are observed even when an older thesis or finance blocks arming.
   if(armed.active)
   {
      ProcessArmedSignal();
      // Do not arm a replacement in the event that invalidated the prior thesis.
      return;
   }
   MqlDateTime dt; TimeToStruct(TimeTradeServer(),dt);
   int hhmm=dt.hour*100+dt.min;
   if(hhmm<Inp_StartHHMM || hhmm>=Inp_StopEntryHHMM) return;
   if(HasOpenPosition() || HasExecutionInFlight() || ordersEnteredToday>=Inp_MaxTradesDay ||
      dailyRiskBlocked || gAccountingUnresolved) return;
   if(Inp_CooldownSec>0 && lastCloseConfirmedTime>0 &&
      TimeTradeServer()-lastCloseConfirmedTime<Inp_CooldownSec) return;
   if(Inp_LossCooldownSec>0 && lastTradeWasLoss && lastCloseConfirmedTime>0 &&
      TimeTradeServer()-lastCloseConfirmedTime<Inp_LossCooldownSec) return;
   EvaluateMatrix();
}

void OnTick()
{
  if(TimeCurrent()<BacktestStart) return;
  MqlDateTime day; TimeToStruct(TimeTradeServer(),day);
  int key=day.year*1000+day.day_of_year;
  if(key!=gDayKey) { gDayKey=key; DailyReset(); }
 SyncAccountingState();
 if(gOpenPos.active) UpdateMAEMFE();
 int hhmm=day.hour*100+day.min;
 ProcessEOD(hhmm);
 ManageBreakEven();
 if(hhmm>=Inp_StopEntryHHMM && armed.active) ResetArmedSignal();
 // OBJECTIVE_DATA_AFTER_FINANCE
 // Admit only a bounded live tail; bootstrap/recovery/backlog remain on timer.
 OMAdmitMarketEvent();
 ObjectiveDecisionCycle();
}

//=====================================================================
// ON TIMER
//=====================================================================
void OnTimer()
{
  if(TimeCurrent()<BacktestStart) return;
  // Keep the original financial timer cadence (tester60/live1 seconds).
  // Only analytical catch-up runs at the finer one-second tester schedule.
  datetime now=TimeTradeServer();
  bool financeDue=now>=gFinancialTimerDue;
  if(financeDue)
  {
     gFinancialTimerDue=now+(MQLInfoInteger(MQL_TESTER)!=0?60:1);
  MqlDateTime nowDT; TimeToStruct(TimeTradeServer(),nowDT);
  int key=nowDT.year*1000+nowDT.day_of_year;
 int hhmm=nowDT.hour*100+nowDT.min;
 if(key!=gDayKey) { gDayKey=key; DailyReset(); }
 SyncAccountingState(true);
 ReconcileBreakEvenProofs(); // Proof/persistence only; never dispatches a stop modification.
 if(hhmm>=Inp_StopEntryHHMM && armed.active) ResetArmedSignal();
 ProcessEOD(hhmm);
  }
 OMService();
 ObjectiveDecisionCycle(); // A verified current trade may confirm an already armed signal.
 if(financeDue && now-gLastFlushTime>=30)
 {
    gLastFlushTime=now;
    if(gEntryDiagnosticHandle!=INVALID_HANDLE) FileFlush(gEntryDiagnosticHandle);
    if(csvTradeHandle!=INVALID_HANDLE) FileFlush(csvTradeHandle);
 }
}

//=====================================================================
// ON TRADE TRANSACTION
// Trata DEAL_ENTRY_IN (entrada) e DEAL_ENTRY_OUT (saída).
// Agrupa por DEAL_POSITION_ID.
// Exige flat, salvo ciclo próprio fechado com residual INOUT explicitamente estrangeiro.
//=====================================================================


//=====================================================================
// ON TESTER
//=====================================================================
//=====================================================================
// RC1 execution context, confirmed quota and positionID accounting
//=====================================================================
// BE-only lifecycle. Initial TradeRecord.slPrice/risk and all entry rules stay unchanged.
double BEPrice(double entry)
{ return NormPriceDigits(MathRound(entry/gTickSize)*gTickSize); }

// Conservative rounding: never claim more protected R than requested.
double ProtectionPrice(int direction,double entry,double initialSL,int level,bool progressive)
{
   if(!progressive) return BEPrice(entry);
   double raw=entry+direction*level*MathAbs(entry-initialSL);
   double price=NormPriceDigits((direction==1?MathFloor(raw/gTickSize):MathCeil(raw/gTickSize))*gTickSize);
   if(direction*(price-raw)>0)
      price=NormPriceDigits(price-direction*gTickSize);
   return price;
}

// Numeric kernel: executable price must actually cross the trigger, without an epsilon
// that could anticipate a tick. Direct multi-R jumps are allowed.
int ProtectionEligibleLevel(int direction,double entry,double initialSL,double executable,
                            int maximum,bool progressive)
{
   double risk=MathAbs(entry-initialSL);
   if(!Positive(risk) || !Positive(executable) || (direction!=1 && direction!=-1)) return -1;
   // Compare prices directly: subtracting a fractional entry from its exact
   // represented trigger can round below R. No epsilon may advance a trigger.
   double firstTrigger=entry+direction*risk;
   bool reached=(direction==1?executable>=firstTrigger:executable<=firstTrigger);
   if(!reached) return -1;
   if(!progressive) return 0;
   int eligible=-1;
   for(int level=0;level<=maximum;level++)
   {
      double trigger=entry+direction*(level+1)*risk;
      if((direction==1 && executable>=trigger) || (direction==-1 && executable<=trigger))
         eligible=level;
   }
   return eligible;
}


bool BEPriceEqual(double a,double b)
{ return MathIsValidNumber(a) && MathIsValidNumber(b) &&
MathAbs(a-b)<=gTickSize*0.000001; }

double BERiskPoints(const TradeRecord &r)
{ return MathAbs(r.weightedEntryPrice-r.slPrice); }

bool BEReferenceValid(const TradeRecord &r)
{
   bool progressive=(r.be.exitMode==(int)PROGRESSIVE_NO_TP);
   if(r.be.exitMode!=(int)ORIGINAL_FIXED_TP && !progressive) return false;
   return r.initialStopsProven && r.riskValid && r.accountingResolved &&
      Positive(r.weightedEntryPrice) && Positive(r.slPrice) &&
      (r.direction==1 || r.direction==-1) &&
      r.direction*(r.weightedEntryPrice-r.slPrice)>0 &&
      r.be.direction==r.direction && BEPriceEqual(r.be.entryPrice,r.weightedEntryPrice) &&
      BEPriceEqual(r.be.initialSL,r.slPrice) && Positive(r.be.price) &&
      r.be.targetLevel>=0 && r.be.targetLevel<=(progressive?5:0) &&
      r.be.confirmedLevel>=-1 && r.be.confirmedLevel<=r.be.targetLevel &&
      BEPriceEqual(r.be.price,ProtectionPrice(r.direction,r.be.entryPrice,r.be.initialSL,
                                             r.be.targetLevel,progressive)) &&
      (r.be.confirmedLevel<0 || BEPriceEqual(r.be.confirmedPrice,
         ProtectionPrice(r.direction,r.be.entryPrice,r.be.initialSL,r.be.confirmedLevel,progressive))) &&
      (!progressive || r.be.tp==0);
}


bool BETriggerReached(const TradeRecord &r,const MqlTick &tick)
{
   return ProtectionEligibleLevel(r.direction,r.weightedEntryPrice,r.slPrice,
      r.direction==1?tick.bid:tick.ask,Inp_MaxProtectedR,
      Inp_ExitMode==PROGRESSIVE_NO_TP)>=0;
}


void BELog(const TradeRecord &r,string event,string detail="")
{
  PrintFormat("[SCALPER][%s] POSITION_ID=%I64u ticket=%I64u dir=%s entry=%.16f initialSL=%.16f R_points=%.16f trigger=%.16f newSL=%.16f TP_preserved=%.16f %s",
     event,r.positionID,r.be.ticket,DirStr(r.be.direction),r.be.entryPrice,r.be.initialSL,
     MathAbs(r.be.entryPrice-r.be.initialSL),
     r.be.entryPrice+r.be.direction*MathAbs(r.be.entryPrice-r.be.initialSL),
     r.be.price,r.be.tp,detail);
}

void BEFailure(TradeRecord &r,string detail)
{
  datetime now=TimeTradeServer();
  if(r.be.lastFailureLog==0 || now-r.be.lastFailureLog>=10)
  { BELog(r,"BE_MODIFY_FAIL",detail); r.be.lastFailureLog=now; }
}

string BEJournalPath(ulong pid)
{ return TradeMetaPath(pid)+".be.journal"; }

uint BEChecksum(string text)
{
  uint value=2166136261;
  for(int i=0;i<StringLen(text);i++)
    value=(value^(uint)StringGetCharacter(text,i))*16777619;
  return value;
}

string BEJournalRow(ulong pid,const BreakEvenState &b)
{
   string row="SCALPER1995_PR2|"+(string)AccountInfoInteger(ACCOUNT_LOGIN)+"|"+
      RJEncode(Symbol())+"|"+(string)gMagicCore+"|"+(string)pid+"|"+
      (string)b.stage+"|"+(string)b.ticket+"|"+(b.direction==1?"BUY":"SELL")+"|"+
      DoubleToString(b.entryPrice,16)+"|"+DoubleToString(b.initialSL,16)+"|"+
      DoubleToString(b.price,16)+"|"+DoubleToString(b.tp,16)+"|"+
      (string)b.triggerMSC+"|"+(string)b.confirmedMSC+"|"+
      (string)b.requestID+"|"+(string)b.retcode+"|"+
      (string)b.exitMode+"|"+(string)b.targetLevel+"|"+
      (string)(b.confirmedLevel+1)+"|"+DoubleToString(b.confirmedPrice,16)+"|"+
      (string)b.confirmedAt;
   return row+"|"+(string)BEChecksum(row)+"|COMPLETE_PR2";
}


bool BEParseRow(string row,ulong pid,BreakEvenState &b)
{
   string f[],symbol;
   ulong account,magic,parsedPID,stage,ticket,trigger,confirmed,requestID,retcode,
         exitMode,targetLevel,confirmedPlusOne,confirmedAt,checksum;
   if(StringSplit(row,'|',f)!=23 || f[0]!="SCALPER1995_PR2" || f[22]!="COMPLETE_PR2" ||
      !RJUnsigned(f[1],account) || account!=(ulong)AccountInfoInteger(ACCOUNT_LOGIN) ||
      !RJDecode(f[2],symbol) || symbol!=Symbol() ||
      !RJUnsigned(f[3],magic) || magic!=(ulong)gMagicCore ||
      !RJUnsigned(f[4],parsedPID) || parsedPID!=pid || pid==0 ||
      !RJUnsigned(f[5],stage) || stage<BE_TRIGGERED || stage>BE_CONFIRMED ||
      !RJUnsigned(f[6],ticket) || ticket==0 || (f[7]!="BUY" && f[7]!="SELL") ||
      !RJUnsigned(f[12],trigger) || trigger==0 || trigger>9223372036854775807 ||
      !RJUnsigned(f[13],confirmed) || confirmed>9223372036854775807 ||
      !RJUnsigned(f[14],requestID) || requestID>4294967295 ||
      !RJUnsigned(f[15],retcode) || retcode>4294967295 ||
      !RJUnsigned(f[16],exitMode) || exitMode>(ulong)PROGRESSIVE_NO_TP ||
      !RJUnsigned(f[17],targetLevel) || targetLevel>5 ||
      !RJUnsigned(f[18],confirmedPlusOne) || confirmedPlusOne>6 ||
      !RJUnsigned(f[20],confirmedAt) || confirmedAt>9223372036854775807 ||
      !RJUnsigned(f[21],checksum) || checksum>4294967295) return false;
   string prefix=f[0]; for(int i=1;i<21;i++) prefix+="|"+f[i];
   if(BEChecksum(prefix)!=(uint)checksum) return false;
   ZeroMemory(b);
   if(!RJDouble(f[8],b.entryPrice) || !RJDouble(f[9],b.initialSL) ||
      !RJDouble(f[10],b.price) || !RJDouble(f[11],b.tp) ||
      !RJDouble(f[19],b.confirmedPrice) || !Positive(b.entryPrice) ||
      !Positive(b.initialSL) || !Positive(b.price)) return false;
   b.stage=(int)stage; b.ticket=ticket; b.direction=(f[7]=="BUY"?1:-1);
   b.triggerMSC=(long)trigger; b.confirmedMSC=(long)confirmed;
   b.requestID=(uint)requestID; b.retcode=(uint)retcode;
   b.exitMode=(int)exitMode; b.targetLevel=(int)targetLevel;
   b.confirmedLevel=(int)confirmedPlusOne-1; b.confirmedAt=(long)confirmedAt;
   bool progressive=(b.exitMode==(int)PROGRESSIVE_NO_TP);
   if(b.direction*(b.entryPrice-b.initialSL)<=0 || b.confirmedLevel>b.targetLevel ||
      (!progressive && b.targetLevel!=0) || (progressive && b.tp!=0) ||
      !BEPriceEqual(b.price,ProtectionPrice(b.direction,b.entryPrice,b.initialSL,b.targetLevel,progressive)) ||
      (b.confirmedLevel<0 && (b.confirmedAt!=0 || b.confirmedPrice!=0)) ||
      (b.confirmedLevel>=0 && (b.confirmedAt==0 || !BEPriceEqual(b.confirmedPrice,
         ProtectionPrice(b.direction,b.entryPrice,b.initialSL,b.confirmedLevel,progressive)))) ||
      (b.stage>=BE_ACKNOWLEDGED && (b.retcode!=TRADE_RETCODE_DONE || b.requestID==0 ||
         b.confirmedMSC<b.triggerMSC)) ||
      (b.stage==BE_CONFIRMED && (b.confirmedLevel!=b.targetLevel ||
         b.confirmedAt!=b.confirmedMSC))) return false;
   b.durable=true;
   return true;
}

bool ProtectionStateFollows(const BreakEvenState &previous,const BreakEvenState &next)
{
   // Reject rewritten references or a replay/downgrade inside a valid-checksum journal.
   return previous.direction==next.direction && previous.exitMode==next.exitMode &&
      BEPriceEqual(previous.entryPrice,next.entryPrice) &&
      BEPriceEqual(previous.initialSL,next.initialSL) &&
      next.confirmedLevel>=previous.confirmedLevel &&
      next.targetLevel>=previous.targetLevel &&
      next.triggerMSC>=previous.triggerMSC && next.confirmedAt>=previous.confirmedAt;
}


bool BEReadJournal(ulong pid,BreakEvenState &b,bool &exists)
{
   exists=FileIsExist(BEJournalPath(pid));
   if(!exists) return false;
   int h=FileOpen(BEJournalPath(pid),FILE_READ|FILE_BIN|FILE_SHARE_READ);
   if(h==INVALID_HANDLE) return false;
   ResetLastError(); ulong size=FileSize(h);
   bool found=false,ok=(GetLastError()==0 && size>0 && size<=1048576);
   uchar bytes[4096]; ulong offset=0; string row=""; bool cr=false;
   while(ok && offset<size)
   {
      int want=(size-offset>4096)?4096:(int)(size-offset);
      ResetLastError(); uint got=FileReadArray(h,bytes,0,want);
      if(got!=(uint)want || GetLastError()!=0) { ok=false; break; }
      offset+=got;
      for(int i=0;i<want;i++)
      {
         uchar value=bytes[i];
         if(value==10 && cr)
         {
            if(row!="")
            {
               BreakEvenState candidate;
               if(!BEParseRow(row,pid,candidate) ||
                  (found && !ProtectionStateFollows(b,candidate))) { ok=false; break; }
               b=candidate; found=true;
            }
            row=""; cr=false; continue;
         }
         if(cr) { ok=false; break; }
         if(value==13) { cr=true; continue; }
         if(value<32 || value>126 || StringLen(row)>=32768) { ok=false; break; }
         row+=ShortToString((ushort)value);
      }
   }
   // Even a complete-looking payload without its final CRLF is a torn write.
   if(row!="" || cr || !found) ok=false;
   ResetLastError(); ulong finalSize=FileSize(h);
   if(GetLastError()!=0 || finalSize!=size) ok=false;
   ResetLastError(); FileClose(h);
   if(GetLastError()!=0) ok=false;
   // Never fall back over a torn pending tail to an older confirmed certificate.
   return found && ok;
}


bool BEPersist(TradeRecord &r)
{
  string row=BEJournalRow(r.positionID,r.be),payload="\r\n"+row+"\r\n";
  int h=FileOpen(BEJournalPath(r.positionID),
     FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
  bool ok=false;
  if(h!=INVALID_HANDLE)
  {
     if(FileSeek(h,0,SEEK_END))
     {
        ResetLastError(); uint written=FileWriteString(h,payload);
        ok=(written==(uint)StringLen(payload) && GetLastError()==0);
        ResetLastError(); FileFlush(h); if(GetLastError()!=0) ok=false;
     }
     FileClose(h);
    }
    BreakEvenState verified; bool exists=false;
    if(ok) ok=BEReadJournal(r.positionID,verified,exists) &&
       BEJournalRow(r.positionID,verified)==row;
    r.be.durable=ok;
    if(!ok) BEFailure(r,"BE_PERSISTENCE_UNCONFIRMED; no durable activation claimed");
    return ok;
}

void BELoad(TradeRecord &r)
{
  BreakEvenState loaded; bool exists=false;
  if(BEReadJournal(r.positionID,loaded,exists)) r.be=loaded;
  else if(exists)
  {
     r.be.stage=BE_UNRESOLVED;
     BELog(r,"BE_PROOF_UNAVAILABLE","Unreadable/corrupt journal; no inferred BE");
  }
}

bool BESelectOwn(ulong pid,ulong &ticket,int direction)
{
  for(int i=PositionsTotal()-1;i>=0;i--)
  {
    ulong candidate=PositionGetTicket(i);
    if(candidate==0 || !PositionSelectByTicket(candidate) ||
       PositionGetString(POSITION_SYMBOL)!=Symbol() ||
       PositionGetInteger(POSITION_MAGIC)!=(long)gMagicCore ||
       (ulong)PositionGetInteger(POSITION_IDENTIFIER)!=pid ||
       (PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY?1:-1)!=direction)
continue;
    ticket=candidate; return true;
  }
  return false;
}

bool BEEntryComplete(const TradeRecord &r)
{
  if(r.entryOrderTicket==0 || OrderSelect(r.entryOrderTicket) ||
     !HistoryOrderSelect(r.entryOrderTicket) ||
     HistoryOrderGetString(r.entryOrderTicket,ORDER_SYMBOL)!=Symbol() ||
     HistoryOrderGetInteger(r.entryOrderTicket,ORDER_MAGIC)!=(long)gMagicCore ||
     (ulong)HistoryOrderGetInteger(r.entryOrderTicket,ORDER_POSITION_ID)!=r.positionID)
     return false;
  ENUM_ORDER_STATE
state=(ENUM_ORDER_STATE)HistoryOrderGetInteger(r.entryOrderTicket,ORDER_STATE);
  if(state!=ORDER_STATE_FILLED && state!=ORDER_STATE_CANCELED &&
     state!=ORDER_STATE_REJECTED && state!=ORDER_STATE_EXPIRED) return false;
    double filled=HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_INITIAL)-
      HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_CURRENT);
    return filled>0 && MathAbs(filled-r.totalVolumeIn)<=AccountingVolumeTolerance();
}

bool BEStopsValid(const TradeRecord &r,const MqlTick &tick,double liveSL,double liveTP)
{
  double size=SymbolInfoDouble(Symbol(),SYMBOL_TRADE_TICK_SIZE);
  double point=SymbolInfoDouble(Symbol(),SYMBOL_POINT);
  if(!Positive(size) || !Positive(point) || MathAbs(size-gTickSize)>size*0.000001 ||
     !Positive(tick.bid) || !Positive(tick.ask) || tick.ask<tick.bid ||
     !OnPriceGrid(r.be.price) || !Positive(liveSL) ||
     r.direction*(r.be.price-liveSL)<=size*0.000001) return false;
  long stops=SymbolInfoInteger(Symbol(),SYMBOL_TRADE_STOPS_LEVEL);
  long freeze=SymbolInfoInteger(Symbol(),SYMBOL_TRADE_FREEZE_LEVEL);
  if(stops<0 || freeze<0) return false;
  double quote=(r.direction==1?tick.bid:tick.ask);
  double stopDistance=r.direction*(quote-r.be.price);
  double oldDistance=r.direction*(quote-liveSL);
  if(stopDistance<=0 || stopDistance+size*0.000001<stops*point ||
     (freeze>0 && (stopDistance<=freeze*point || oldDistance<=freeze*point))) return false;
  if(liveTP!=0)
  {
     double tpDistance=r.direction*(liveTP-quote);
     if(!OnPriceGrid(liveTP) || tpDistance<=0 || tpDistance+size*0.000001<stops*point ||
        (freeze>0 && tpDistance<=freeze*point)) return false;
  }
  return true;
}

// A historical certificate belongs to an actual confirmed stop, independently
// of a newer request's stage, target, retcode or durability flag in RAM.
bool BEExitAtProtectedLevel(const TradeRecord &r,ulong deal,const BreakEvenState &proof)
{
   return r.initialStopsProven && r.riskValid && r.accountingResolved &&
      r.direction==proof.direction && BEPriceEqual(r.weightedEntryPrice,proof.entryPrice) &&
      BEPriceEqual(r.slPrice,proof.initialSL) &&
      HistoryDealGetString(deal,DEAL_SYMBOL)==Symbol() &&
      (ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID)==r.positionID &&
      HistoryDealGetInteger(deal,DEAL_ENTRY)==DEAL_ENTRY_OUT &&
      HistoryDealGetInteger(deal,DEAL_REASON)==DEAL_REASON_SL &&
      HistoryDealGetInteger(deal,DEAL_TIME_MSC)>=proof.confirmedAt &&
      BEPriceEqual(HistoryDealGetDouble(deal,DEAL_SL),proof.confirmedPrice);
}

// This predicate is ONLY for confirming the latest acknowledged modification.
// Matching an older certified stop must never confirm a newer pending target.
bool BERequestedExitAtTarget(const TradeRecord &r,ulong deal)
{
   return BEReferenceValid(r) &&
      HistoryDealGetString(deal,DEAL_SYMBOL)==Symbol() &&
      (ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID)==r.positionID &&
      HistoryDealGetInteger(deal,DEAL_ENTRY)==DEAL_ENTRY_OUT &&
      HistoryDealGetInteger(deal,DEAL_REASON)==DEAL_REASON_SL &&
      HistoryDealGetInteger(deal,DEAL_TIME_MSC)>=r.be.confirmedMSC &&
      HistoryDealGetInteger(deal,DEAL_TIME_MSC)>=r.be.triggerMSC &&
      BEPriceEqual(HistoryDealGetDouble(deal,DEAL_SL),r.be.price);
}


bool BEProtectedDeal(const TradeRecord &r,ulong deal,const BreakEvenState &proof)
{
   return proof.stage==BE_CONFIRMED && proof.durable &&
      proof.retcode==TRADE_RETCODE_DONE && proof.requestID>0 &&
      proof.confirmedLevel>=0 && proof.confirmedLevel==proof.targetLevel &&
      proof.confirmedAt>0 && proof.confirmedAt==proof.confirmedMSC &&
      proof.confirmedAt>=proof.triggerMSC &&
      BEPriceEqual(proof.confirmedPrice,proof.price) &&
      BEExitAtProtectedLevel(r,deal,proof);
}

// Existing PR2 schema is retained. Read historical CONFIRMED rows as bounded
// certificates (at most six levels), never replace the live pending request.
bool BEReadProtectionCertificates(const TradeRecord &r,BreakEvenState &certificates[])
{
   ArrayResize(certificates,0);
   BreakEvenState latest; bool exists=false;
   if(!BEReadJournal(r.positionID,latest,exists)) return false;
   int h=FileOpen(BEJournalPath(r.positionID),FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
   if(h==INVALID_HANDLE) return false;
   ResetLastError(); ulong size=FileSize(h);
   bool ok=(GetLastError()==0 && size>0 && size<=1048576),found=false;
   BreakEvenState previous = {};
   while(ok && !FileIsEnding(h))
   {
      ResetLastError(); string row=FileReadString(h);
      if(GetLastError()!=0) { ok=false; break; }
      if(row=="") continue;
      BreakEvenState candidate;
      if(!BEParseRow(row,r.positionID,candidate) ||
         (found && !ProtectionStateFollows(previous,candidate))) { ok=false; break; }
      previous=candidate; found=true;
      if(candidate.stage!=BE_CONFIRMED) continue;
      int n=ArraySize(certificates);
      if(n>0 && certificates[n-1].confirmedLevel==candidate.confirmedLevel)
      { continue; } // retain earliest confirmation time for earlier partial exits
      if(n>=6 || ArrayResize(certificates,n+1)!=n+1) { ok=false; break; }
      certificates[n]=candidate;
   }
   ResetLastError(); ulong finalSize=FileSize(h);
   if(GetLastError()!=0 || finalSize!=size) ok=false;
   ResetLastError(); FileClose(h);
   if(GetLastError()!=0 || !found) ok=false;
   if(ok && BEJournalRow(r.positionID,previous)!=BEJournalRow(r.positionID,latest)) ok=false;
   if(!ok) ArrayResize(certificates,0);
   // A corrupt/torn journal never creates a certificate or authorizes dispatch.
   return ok;
}


bool BEConfirm(TradeRecord &r,ulong protectedExitDeal=0)
{
   if(r.be.stage==BE_CONFIRMED) return r.be.durable && BEReferenceValid(r);
   if(r.be.stage!=BE_ACKNOWLEDGED || r.be.retcode!=TRADE_RETCODE_DONE ||
      !BEReferenceValid(r)) return false;
   if(!r.be.durable && !BEPersist(r)) return false;
   ulong ticket=0;
   bool live=BESelectOwn(r.positionID,ticket,r.direction) &&
      BEPriceEqual(PositionGetDouble(POSITION_SL),r.be.price) &&
      PositionGetDouble(POSITION_TP)==r.be.tp;
   bool protectedExit=(protectedExitDeal>0 && BERequestedExitAtTarget(r,protectedExitDeal));
   if(!live && !protectedExit) return false;
   BreakEvenState before=r.be;
   r.be.stage=BE_CONFIRMED; r.be.confirmedLevel=r.be.targetLevel;
   r.be.confirmedPrice=r.be.price; r.be.confirmedAt=r.be.confirmedMSC;
   if(!BEPersist(r)) { r.be=before; r.be.durable=false; return false; }
   if(!r.be.successLogged)
   { BELog(r,"PROTECTION_CONFIRMED","level="+(string)r.be.confirmedLevel); r.be.successLogged=true; }
   return true;
}

// Classification is read-only with respect to a newer pending modification.
// Net economics and the original BE-neutral loss-counter rule remain unchanged.
void ClassifyProtectionExits(TradeRecord &r,ulong &deals[],int count,bool listValid)
{
   r.breakEvenExit=false; r.breakEvenClassificationPending=false;
   if(r.be.stage==BE_NONE) return;
   if(!listValid || count<=0)
   { r.breakEvenClassificationPending=r.volumeClosedComplete && !listValid; return; }
   // Only an acknowledged target with its own exact exit evidence may be promoted.
   for(int i=0;i<count && r.be.stage==BE_ACKNOWLEDGED;i++)
      if(BERequestedExitAtTarget(r,deals[i])) BEConfirm(r,deals[i]);
   BreakEvenState certificates[];
   if(!BEReadProtectionCertificates(r,certificates))
   {
      r.breakEvenClassificationPending=r.volumeClosedComplete;
      BEFailure(r,"PROTECTION_EXIT_CERTIFICATE_UNAVAILABLE; reconciliation required");
      return;
   }
   bool allCertified=true,allZero=true,anyPositive=false,awaitingTarget=false;
   for(int i=0;i<count;i++)
   {
      int level=-1;
      for(int j=0;j<ArraySize(certificates);j++)
         if(BEProtectedDeal(r,deals[i],certificates[j]))
         { level=certificates[j].confirmedLevel; break; }
      if(level<0)
      {
         allCertified=false; allZero=false;
         if(BERequestedExitAtTarget(r,deals[i]) &&
            (r.be.stage==BE_REQUEST_PENDING || r.be.stage==BE_ACKNOWLEDGED))
            awaitingTarget=true;
      }
      else { if(level!=0) allZero=false; if(level>0) anyPositive=true; }
   }
   r.breakEvenClassificationPending=r.volumeClosedComplete && awaitingTarget;
   if(r.breakEvenClassificationPending)
      BEFailure(r,"PROTECTION_EXIT_PROOF_PENDING; finalization/accounting publication deferred");
   r.breakEvenExit=allCertified && allZero && r.volumeClosedComplete && r.accountingResolved;
   if(r.breakEvenExit)
   {
      r.exitReason="BE";
      if(!r.be.exitLogged)
      { BELog(r,"BE_EXIT","certified level=0; net economics unchanged"); r.be.exitLogged=true; }
   }
   else if(allCertified && anyPositive && r.volumeClosedComplete && r.accountingResolved)
   {
      // Includes mixed certified 0R/+R partial exits; never BE-neutral as a whole.
      r.exitReason="PROFIT_LOCK";
      if(!r.be.exitLogged)
      { BELog(r,"PROFIT_LOCK_EXIT","certified stop levels; actual net PnL and costs retained"); r.be.exitLogged=true; }
   }
}



bool BEManagerLoss(const TradeRecord &r)
{ return r.netProfit<0 && !r.breakEvenExit; }

void BEAcceptResult(TradeRecord &r,const MqlTradeRequest &request,const
MqlTradeResult &result)
{
  if(r.be.stage!=BE_REQUEST_PENDING || request.action!=TRADE_ACTION_SLTP ||
     request.position!=r.be.ticket || request.position_by!=0 ||
     request.symbol!=Symbol() || request.magic!=(ulong)gMagicCore ||
     result.request_id==0 || (r.be.requestID>0 && result.request_id!=r.be.requestID) ||
     !BEPriceEqual(request.sl,r.be.price) || request.tp!=r.be.tp) return;
  if(result.request_id>0) r.be.requestID=result.request_id;
  r.be.retcode=result.retcode;
  if(result.retcode==TRADE_RETCODE_DONE)
  {
     r.be.stage=BE_ACKNOWLEDGED;
     // Second-resolution server clock is a conservative lower bound, not a fill price.
     r.be.confirmedMSC=(long)TimeTradeServer()*1000;
     if(r.be.confirmedMSC<r.be.triggerMSC) r.be.confirmedMSC=r.be.triggerMSC;
     if(BEPersist(r)) BEConfirm(r);
     if(r.volumeClosedComplete || r.breakEvenClassificationPending)
     { r.historyRefreshPending=true; gNeedsAccountingSync=true; }
  }
  else if(IsFinalRejectedRetcode(result.retcode) ||
result.retcode==TRADE_RETCODE_NO_CHANGES)
  {
     r.be.stage=BE_TRIGGERED; r.be.requestID=0; r.be.confirmedMSC=0;
     r.be.nextTry=TimeTradeServer()+1;
     BEPersist(r); BEFailure(r,"retcode="+(string)result.retcode+"; safe retry allowed");
   if(r.volumeClosedComplete || r.breakEvenClassificationPending)
   { r.historyRefreshPending=true; gNeedsAccountingSync=true; }
  }
  else
  {
    BEPersist(r);
    BEFailure(r,"retcode="+(string)result.retcode+"; awaiting exact request result, no blind retry");
  }
}

void BEHandleTransaction(const MqlTradeTransaction &trans,
  const MqlTradeRequest &request,const MqlTradeResult &result)
{
  if(trans.type!=TRADE_TRANSACTION_REQUEST ||
request.action!=TRADE_ACTION_SLTP) return;
  for(int i=0;i<gTradeRecordCount;i++)
     if(gTradeRecords[i].be.stage==BE_REQUEST_PENDING &&
        gTradeRecords[i].be.requestID>0 &&
        result.request_id==gTradeRecords[i].be.requestID)
        BEAcceptResult(gTradeRecords[i],request,result);
}

void ReconcileBreakEvenProofs()
{
  for(int i=0;i<gTradeRecordCount;i++)
  {
    TradeRecord r=gTradeRecords[i];
    if(r.be.stage!=BE_ACKNOWLEDGED) continue;
    BEConfirm(r); gTradeRecords[i]=r;
    if(r.volumeClosedComplete && r.breakEvenClassificationPending)
    { gTradeRecords[i].historyRefreshPending=true; gNeedsAccountingSync=true; }
  }
}

void ManageBreakEven()
{
   ReconcileBreakEvenProofs();
   for(int i=0;i<gTradeRecordCount;i++)
   {
      TradeRecord r=gTradeRecords[i];
      bool progressive=(Inp_ExitMode==PROGRESSIVE_NO_TP);
      if(r.be.stage==BE_ACKNOWLEDGED || r.be.stage==BE_UNRESOLVED ||
         r.be.stage==BE_REQUEST_PENDING || (!progressive && r.be.stage==BE_CONFIRMED) ||
         !Inp_EnableBreakEven || r.closed || r.volumeClosedComplete || r.historyRefreshPending ||
         !r.accountingResolved || !r.initialStopsProven || !r.riskValid ||
         !Positive(r.weightedEntryPrice) || !Positive(r.slPrice) ||
         r.direction*(r.weightedEntryPrice-r.slPrice)<=0 ||
         gPendingExec.active || gPendingExit.active || gLiveOwnershipUnresolved ||
         gPendingOrderClassificationUnresolved || gMultipleOwnOrdersActive ||
         gOrderRegistryUnavailable || gOrderObligationScanUnresolved) continue;
      if(r.be.stage!=BE_NONE && (r.be.exitMode!=(int)Inp_ExitMode || !BEReferenceValid(r)))
      {
         r.be.stage=BE_UNRESOLVED; BEFailure(r,"protection mode/reference changed; reconciliation required");
         gTradeRecords[i]=r; continue;
      }
      MqlTick tick;
      if(!SymbolInfoTick(Symbol(),tick) || !Positive(tick.bid) || !Positive(tick.ask) ||
         tick.ask<tick.bid || tick.time_msc<=0 || TimeTradeServer()<r.be.nextTry) continue;
      double entry=(r.be.stage==BE_NONE?r.weightedEntryPrice:r.be.entryPrice);
      double initialSL=(r.be.stage==BE_NONE?r.slPrice:r.be.initialSL);
      int level=ProtectionEligibleLevel(r.direction,entry,initialSL,
         r.direction==1?tick.bid:tick.ask,Inp_MaxProtectedR,progressive);
      if(level<0) continue;
      int confirmed=(r.be.stage==BE_NONE?-1:r.be.confirmedLevel);
      if(level<=confirmed) continue;
      // An unsubmitted/rejected prepared request can wait through a retracement, but
      // its target must not be lowered and its market trigger must still be reached.
      if(r.be.stage==BE_TRIGGERED && level<r.be.targetLevel) continue;
      ulong ticket=0;
      if(!BESelectOwn(r.positionID,ticket,r.direction) || !BEEntryComplete(r) ||
         !OwnPositionSafe(r.positionID) || !PositionSelectByTicket(ticket) ||
         PositionGetString(POSITION_SYMBOL)!=Symbol() ||
         PositionGetInteger(POSITION_MAGIC)!=(long)gMagicCore ||
         (ulong)PositionGetInteger(POSITION_IDENTIFIER)!=r.positionID ||
         (PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY?1:-1)!=r.direction ||
         !BEPriceEqual(PositionGetDouble(POSITION_PRICE_OPEN),r.weightedEntryPrice) ||
         MathAbs(PositionGetDouble(POSITION_VOLUME)-(r.totalVolumeIn-r.totalVolumeOut))>
            AccountingVolumeTolerance()) continue;
      double liveSL=PositionGetDouble(POSITION_SL),liveTP=PositionGetDouble(POSITION_TP);
      if(progressive && liveTP!=0) { BEFailure(r,"unexpected TP in progressive position"); continue; }
      if(confirmed>=0 && (!r.be.durable || !BEPriceEqual(liveSL,r.be.confirmedPrice)))
      {
         r.be.stage=BE_UNRESOLVED;
         BEFailure(r,"live stop differs from confirmed certificate; reconciliation required");
         gTradeRecords[i]=r; continue;
      }
      if(r.be.stage==BE_NONE)
      {
         r.be.exitMode=(int)Inp_ExitMode; r.be.direction=r.direction;
         r.be.entryPrice=r.weightedEntryPrice; r.be.initialSL=r.slPrice;
         r.be.confirmedLevel=-1; r.be.confirmedPrice=0; r.be.confirmedAt=0;
      }
      r.be.stage=BE_TRIGGERED; r.be.ticket=ticket; r.be.targetLevel=level;
      r.be.price=ProtectionPrice(r.direction,r.be.entryPrice,r.be.initialSL,level,progressive);
      r.be.tp=liveTP; r.be.requestID=0; r.be.retcode=0; r.be.confirmedMSC=0;
      r.be.triggerMSC=tick.time_msc; r.be.successLogged=false;
      r.be.nextTry=TimeTradeServer()+1;
      if(!BEPersist(r)) { gTradeRecords[i]=r; continue; }
      // Re-read the executable quote immediately before preparing possible dispatch.
      if(!BEReferenceValid(r) || !SymbolInfoTick(Symbol(),tick) ||
         ProtectionEligibleLevel(r.direction,r.be.entryPrice,r.be.initialSL,
            r.direction==1?tick.bid:tick.ask,Inp_MaxProtectedR,progressive)<r.be.targetLevel ||
         !BEStopsValid(r,tick,liveSL,liveTP))
      {
         BEFailure(r,"market trigger/stop/grid/freeze invalid; no modification sent");
         gTradeRecords[i]=r; continue;
      }
      r.be.stage=BE_REQUEST_PENDING;
      if(!BEPersist(r))
      {
         // A torn persistence tail is ambiguous even if this process did not dispatch.
         r.be.stage=BE_UNRESOLVED; gTradeRecords[i]=r; continue;
      }
      gTradeRecords[i]=r;
      trade.SetExpertMagicNumber(gMagicCore);
      bool dispatched=trade.PositionModify(ticket,r.be.price,r.be.tp);
      MqlTradeRequest request; MqlTradeResult result;
      trade.Request(request); trade.Result(result);
      if(!dispatched && result.retcode==TRADE_RETCODE_DONE) result.retcode=TRADE_RETCODE_ERROR;
      BEAcceptResult(gTradeRecords[i],request,result);
      if(!dispatched && gTradeRecords[i].be.stage==BE_REQUEST_PENDING)
         BEFailure(gTradeRecords[i],"PositionModify false; dispatch outcome uncertain; no blind retry");
   }
}



void ResetTradeRecord(TradeRecord &r)
{
   r.positionID=0; r.direction=0; r.route="UNAVAILABLE"; r.mode="UNAVAILABLE";
   r.quotaCounted=false; r.requestPrice=0; r.breakoutPrice=0;
   r.requestPriceAvailable=false; r.breakoutPriceAvailable=false;
   r.entryOrderTicket=0; r.expectedEntryVolume=0;
   r.entryTime=0; r.entryPrice=0; r.weightedEntryPrice=0; r.totalVolumeIn=0;
   r.entrySlippage=EMPTY_VALUE; r.slPrice=0; r.tpPrice=0;
   r.exitTime=0; r.exitPrice=0; r.weightedExitPrice=0; r.totalVolumeOut=0; r.volume=0;
   r.exitTimeMSC=0; r.lastExitDealTicket=0;
   r.grossProfit=0; r.commission=0; r.fee=0; r.swap=0; r.netProfit=0;
   r.exitReason="UNAVAILABLE"; r.MAE=0; r.MFE=0; r.holdSeconds=0;
   r.initialRiskMoney=0; r.PnL_R=EMPTY_VALUE;
   r.closed=false; r.maeMfePartialAfterRestart=false; r.volumeClosedComplete=false;
   r.finalizationWritten=false; r.dailyApplied=false;
   r.accountingResolved=true; r.riskValid=false; r.pnlRValid=false;
   r.initialStopsProven=false; r.economicMarkerPending=false;
   r.economicMarkerCleanupPending=false; r.economicMarkerDeleteError=0;
   r.historyRefreshPending=false;
   r.residualForeignDetected=false; r.ownCycleEconomicallyClosed=false;
   r.volumeOwnershipResolved=false; r.inoutCostsUnresolved=false;
   ZeroMemory(r.be); r.breakEvenExit=false; r.breakEvenClassificationPending=false;
}
void ResetPendingExec(bool releaseProof=true)
{
  if(releaseProof && gPendingExec.active) ResolveRequestJournal(false);
  gPendingExec.active=false; gPendingExec.direction=0;
  gPendingExec.route="UNAVAILABLE"; gPendingExec.mode="UNAVAILABLE";
  gPendingExec.requestPrice=0; gPendingExec.requestedLots=0;
  gPendingExec.slPrice=0; gPendingExec.tpPrice=0; gPendingExec.sentAt=0;
  gPendingExec.orderTicket=0; gPendingExec.resultDeal=0;
  gPendingExec.requestID=0;
  gPendingExec.accepted=false; gPendingExec.requestPriceAvailable=false;
  gPendingExec.breakoutPrice=0; gPendingExec.breakoutPriceAvailable=false;
  gPendingExec.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
}

void BeginExitIntent(ulong positionID,string intention)
{
  gPendingExit.active=true; gPendingExit.positionID=positionID;
  gPendingExit.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  gPendingExit.reason=intention; gPendingExit.sentAt=TimeTradeServer();
  gPendingExit.orderTicket=0; gPendingExit.resultDeal=0; gPendingExit.positionTicket=0;
   gPendingExit.requestID=0; gPendingExit.accepted=false; gPendingExit.uncertain=false;
    ZeroMemory(gPendingExit.requestSnapshot);
}

void ClearPendingExitIntent()
{
  gPendingExit.active=false; gPendingExit.positionID=0; gPendingExit.positionTicket=0;
  gPendingExit.reason=""; gPendingExit.sentAt=0;
  gPendingExit.orderTicket=0; gPendingExit.resultDeal=0; gPendingExit.requestID=0;
  gPendingExit.accepted=false; gPendingExit.uncertain=false;
  gPendingExit.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  ZeroMemory(gPendingExit.requestSnapshot);
}

void FailExitIntent(ulong positionID,bool requestResolved=false)
{
  if(!gPendingExit.active || gPendingExit.positionID!=positionID) return;
  // A closed position alone is not terminal proof for its exit request.
  if(!requestResolved) return;
  ResolveRequestJournal(true);
  ClearPendingExitIntent();
}

datetime AccountingDayStart()
{
  MqlDateTime dt; TimeToStruct(TimeTradeServer(),dt);
  dt.hour=0; dt.min=0; dt.sec=0;
  return StructToTime(dt);
}

bool HasOwnPendingOrder()
{
  for(int i=OrdersTotal()-1;i>=0;i--)
  {
    ulong ticket=OrderGetTicket(i);
    if(ticket==0) continue;
    if(OrderGetString(ORDER_SYMBOL)==Symbol() &&
       OrderGetInteger(ORDER_MAGIC)==(long)gMagicCore) return true;
  }
  return false;
}

bool HasOwnPendingOrderToday()
{
  datetime start=AccountingDayStart();
  for(int i=OrdersTotal()-1;i>=0;i--)
  {
    ulong ticket=OrderGetTicket(i);
    if(ticket==0) continue;
  if(OrderGetString(ORDER_SYMBOL)==Symbol() &&
     OrderGetInteger(ORDER_MAGIC)==(long)gMagicCore &&
     (datetime)OrderGetInteger(ORDER_TIME_SETUP)>=start) return true;
 }
 return false;
}
bool HasExecutionInFlight()
{
  if(gOrderObligationScanUnresolved) return true;
  for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
     if(gUnresolvedOrders[i].active && (gUnresolvedOrders[i].classificationPending ||
        gUnresolvedOrders[i].persistencePending)) return true;
  if(gRequestJournalUnresolved || gEntryJournalCleanupPending ||
     gExitJournalCleanupPending || gRequestJournalWritePending) return true;
  if(gPendingExec.active || gPendingExit.active ||
     gPendingOrderClassificationUnresolved || HasOwnPendingOrder()) return true;
  // A confirmed IN can arrive before Positions exposes the position; an OUT
  // can likewise precede flat state. The tracked lifecycle spans both races.
  for(int i=0;i<gTradeRecordCount;i++)
     if(gTradeRecords[i].positionID>0 && !gTradeRecords[i].closed &&
        gTradeRecords[i].totalVolumeIn>0) return true;
  return false;
}

bool PreparePendingExec(int direction,string route,string mode,double requestPrice,
          double lots,double sl,double tp)
{
  // Zero TP is legitimate only for progressive entry; recovery parsers accept
  // previously saved zero independently of today's mode (never rewrite proof).
  if(!EntryTPValid(tp) || !OnPriceGrid(sl) || !Positive(lots)) return false;
  // Call only after the final guards; active state blocks another request.
  if(gPendingExec.active || gRequestJournalUnresolved ||
     gEntryJournalCleanupPending || gRequestJournalWritePending) return false;
  ResetPendingExec(false);
  gPendingExec.active=true; gPendingExec.direction=direction;
  gPendingExec.dispatchPhase=REQUEST_PREPARED;
  gPendingExec.route=route; gPendingExec.mode=mode;
  gPendingExec.requestPrice=requestPrice;
gPendingExec.requestPriceAvailable=(requestPrice>0);
  gPendingExec.requestedLots=lots; gPendingExec.slPrice=sl; gPendingExec.tpPrice=tp;
  gPendingExec.sentAt=TimeTradeServer();
  if(!PersistRequestJournal(false)) { ResetPendingExec(); return false; }
  return true;
}

bool IsAcceptedRetcode(uint ret)
{
  return ret==TRADE_RETCODE_DONE || ret==TRADE_RETCODE_PLACED ||
    ret==TRADE_RETCODE_DONE_PARTIAL;
}
bool IsUncertainRetcode(uint ret)
{ return ret==TRADE_RETCODE_TIMEOUT || ret==TRADE_RETCODE_CONNECTION; }

void CompletePendingExec(bool sent,uint ret,ulong orderTicket,ulong resultDeal,uint
requestID=0)
{
  gPendingExec.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  if(orderTicket>0) gPendingExec.orderTicket=orderTicket;
    if(resultDeal>0) gPendingExec.resultDeal=resultDeal;
    if(requestID>0) gPendingExec.requestID=requestID;
    if(IsAcceptedRetcode(ret))
    {
       if(!gPendingExec.accepted) requestsAcceptedToday++;
       gPendingExec.accepted=true;
    }
    // FILLED, ORDER_DELETE and HISTORY_ADD are never evidence of no deal.
    // Transport uncertainty keeps the request guard active until reconciliation.
    else if(IsFinalRejectedRetcode(ret) && !gPendingExec.accepted &&
       gPendingExec.orderTicket==0 && gPendingExec.resultDeal==0)
       ResetPendingExec();
    if(gPendingExec.active) PersistRequestJournal(false);
    gNeedsAccountingSync=true;
}

double AccountingVolumeTolerance()
{
  double step=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_STEP);
  return (step>0 ? step*0.000001 : 0.00000001);
}

double CalcInitialRiskMoney(int direction,double entryPrice,double slPrice,double volume)
{
  if(volume<=0 || entryPrice<=0 || slPrice<=0 ||
     (double)direction*(entryPrice-slPrice)<=0) return 0;
  double profit=0;
  ENUM_ORDER_TYPE type=(direction==1 ? ORDER_TYPE_BUY :
ORDER_TYPE_SELL);
  if(!OrderCalcProfit(type,Symbol(),volume,entryPrice,slPrice,profit) ||
     !MathIsValidNumber(profit) || profit>=0) return 0;
  return MathAbs(profit);
}

int FindTrackedTrade(ulong positionID)
{
  for(int i=0;i<gTradeRecordCount;i++)
   if(gTradeRecords[i].positionID==positionID) return i;
  return -1;
}
// 1: proved current-version entry; 0: proved foreign/non-entry; -1: unavailable proof.
// The originating order and account-scoped history establish identity, not Magic alone.
int Identify1995EntryDeal(ulong deal)
{
   if(deal==0) return -1;
   ResetLastError();
   string symbol=HistoryDealGetString(deal,DEAL_SYMBOL);
   long magic=HistoryDealGetInteger(deal,DEAL_MAGIC);
   long entry=HistoryDealGetInteger(deal,DEAL_ENTRY);
   long type=HistoryDealGetInteger(deal,DEAL_TYPE);
   ulong order=(ulong)HistoryDealGetInteger(deal,DEAL_ORDER);
   ulong pid=(ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID);
   if(GetLastError()!=0) return -1;
   if(symbol!=Symbol() || magic!=(long)gMagicCore || entry!=DEAL_ENTRY_IN ||
      (type!=DEAL_TYPE_BUY && type!=DEAL_TYPE_SELL)) return 0;
   if(order==0 || pid==0 || !HistoryOrderSelect(order)) return -1;
   ResetLastError();
   string orderSymbol=HistoryOrderGetString(order,ORDER_SYMBOL);
   long orderMagic=HistoryOrderGetInteger(order,ORDER_MAGIC);
   ulong orderPID=(ulong)HistoryOrderGetInteger(order,ORDER_POSITION_ID);
   string comment=HistoryOrderGetString(order,ORDER_COMMENT);
   if(GetLastError()!=0 || orderPID==0) return -1;
   if(orderSymbol!=Symbol() || orderMagic!=(long)gMagicCore || orderPID!=pid) return -1;
   // Explicit legacy identity is a conflict, never a source for this version's ledger.
   string legacy="RC"+"1|";
   if(comment==legacy+"ABS|BASE" || comment==legacy+"ABS|TURBO" ||
      comment==legacy+"CONT|BASE_CONT" || comment==legacy+"CONT|TURBO_CONT" ||
      comment=="SCALPER_BASE" || comment=="SCALPER_TURBO" ||
      comment=="SCALPER_BASE_CONT" || comment=="SCALPER_TURBO_CONT") return 0;
   string route,mode;
   if(StringFind(comment,"S1995|")!=0 || !ParseScalperComment(comment,route,mode)) return -1;
   string dealRoute,dealMode;
   if(ParseScalperComment(HistoryDealGetString(deal,DEAL_COMMENT),dealRoute,dealMode) &&
      (dealRoute!=route || dealMode!=mode)) return -1;
   return 1;
}

bool Is1995EntryDeal(ulong deal)
{
   int identity=Identify1995EntryDeal(deal);
   if(identity<0) MarkTemporaryAccountingHistory();
   return identity==1;
}

bool HasOwnEntryHistory(ulong positionID)
{
  if(!HistorySelectByPosition(positionID)) return false;
  for(int i=0;i<HistoryDealsTotal();i++)
  {
     ulong deal=HistoryDealGetTicket(i);
     if(Is1995EntryDeal(deal)) return true;
    }
    return false;
}

int NewTrackedTrade(ulong positionID)
{
  int known=FindTrackedTrade(positionID); if(known>=0) return known;
  int idx=-1;
  for(int i=0;i<gTradeRecordCount;i++)
     if(gTradeRecords[i].closed && gTradeRecords[i].finalizationWritten &&
        gTradeRecords[i].dailyApplied && gTradeRecords[i].accountingResolved &&
        !gTradeRecords[i].economicMarkerPending &&
!gTradeRecords[i].historyRefreshPending &&
        !gTradeRecords[i].inoutCostsUnresolved &&
        gTradeRecords[i].exitTime<AccountingDayStart()) { idx=i; break; }
  if(idx<0)
  {
     if(ArrayResize(gTradeRecords,gTradeRecordCount+1)!=gTradeRecordCount+1)
     {
        RememberDeferredAccountingPID(positionID);
        return -1;
     }
     idx=gTradeRecordCount++;
  }
  ResetTradeRecord(gTradeRecords[idx]); gTradeRecords[idx].positionID=positionID;
  BELoad(gTradeRecords[idx]);
  ForgetDeferredAccountingPID(positionID);
  return idx;
}

bool PositionStateByID(ulong positionID,double &volume,double &sl,double &tp,int
&direction)
{
  volume=0; sl=0; tp=0; direction=0;
  for(int i=PositionsTotal()-1;i>=0;i--)
  {
    ulong ticket=PositionGetTicket(i);
    if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=Symbol()) continue;
  if((ulong)PositionGetInteger(POSITION_IDENTIFIER)!=positionID) continue;
  volume=PositionGetDouble(POSITION_VOLUME);
  sl=PositionGetDouble(POSITION_SL); tp=PositionGetDouble(POSITION_TP);
  direction=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY ? 1 : -1);
  return true;
 }
 return false;
}
bool ParseScalperComment(string comment,string &route,string &mode)
{
  route="UNAVAILABLE"; mode="UNAVAILABLE";
  if(comment=="S1995|ABS|BASE")
  { route="ABS"; mode="BASE"; return true; }
    if(comment=="S1995|ABS|TURBO")
    { route="ABS"; mode="TURBO"; return true; }
    if(comment=="S1995|CONT|BASE_CONT")
    { route="CONT"; mode="BASE_CONT"; return true; }
    if(comment=="S1995|CONT|TURBO_CONT")
    { route="CONT"; mode="TURBO_CONT"; return true; }
    return false;
}

string GvDateToday()
{
  MqlDateTime dt; TimeToStruct(TimeTradeServer(),dt);
  return StringFormat("%04d%02d%02d",dt.year,dt.mon,dt.day);
}

string AccountingKey(string field)
{
  return StringFormat("SCALP_1995_%I64d_%s_%I64d_%s_%s",

AccountInfoInteger(ACCOUNT_LOGIN),Symbol(),(long)gMagicCore,field,GvDateToday());
}
string GvKeyShots() { return AccountingKey("CONF"); }
string GvKeyDailyBlock() { return AccountingKey("BLOCK"); }
string GvKeyConsecLoss() { return AccountingKey("LOSS"); }
string GvKeyDailyPnL() { return AccountingKey("NET"); }
string GvKeyDailyPnLR() { return AccountingKey("R"); }

bool PersistShotCount()
{
  bool ok=(GlobalVariableSet(GvKeyShots(),(double)ordersEnteredToday)!=0);
  if(!ok) Print("[SCALPER][PERSIST_FAIL] CONFIRMED_TRADE_COUNT");
  GlobalVariablesFlush();
  return ok;
}

void PersistDailyAccounting()
{
  // VALID is a commit marker. Partial state is rebuilt, never silently trusted.
  GlobalVariableSet(AccountingKey("VALID"),0.0);
  bool ok=true;
  if(GlobalVariableSet(AccountingKey("RISK_LATCH"),gDailyRiskLimitLatched?1.0:0.0)==0)
ok=false;
  if(GlobalVariableSet(GvKeyShots(),(double)ordersEnteredToday)==0) ok=false;
  if(GlobalVariableSet(GvKeyDailyPnL(),dailyNetPnL)==0) ok=false;
  if(GlobalVariableSet(GvKeyDailyPnLR(),dailyPnLR)==0) ok=false;
  if(GlobalVariableSet(GvKeyConsecLoss(),(double)consecutiveLosses)==0) ok=false;
  if(GlobalVariableSet(GvKeyDailyBlock(),dailyRiskBlocked?1.0:0.0)==0) ok=false;
  if(GlobalVariableSet(AccountingKey("RVALID"),gDailyPnLRValid?1.0:0.0)==0) ok=false;
  if(GlobalVariableSet(AccountingKey("CLOSE"),(double)lastCloseConfirmedTime)==0)
ok=false;
  if(GlobalVariableSet(AccountingKey("LASTLOSS"),lastTradeWasLoss?1.0:0.0)==0)
ok=false;
  if(ok) GlobalVariableSet(AccountingKey("VALID"),1.0);
  else Print("[SCALPER][PERSIST_FAIL] DAILY_ACCOUNTING_INCOMPLETE");
  GlobalVariablesFlush();
}
void PersistDailyBlock() { PersistDailyAccounting(); }
void PersistConsecLoss(int n) { consecutiveLosses=n; PersistDailyAccounting(); }
void PersistDailyPnL(double pnl) { dailyNetPnL=pnl; PersistDailyAccounting(); }

string TradeMetaPath(ulong positionID)
{
  return StringFormat("Scalper1995_%I64d_%s_%I64d_%I64u.meta.csv",
   AccountInfoInteger(ACCOUNT_LOGIN),Symbol(),(long)gMagicCore,positionID);
}

void SaveTradeMetadata(const TradeRecord &r)
{
  int h=FileOpen(TradeMetaPath(r.positionID),FILE_WRITE|FILE_CSV|FILE_ANSI,';');
  if(h==INVALID_HANDLE) { Print("[SCALPER][PERSIST_FAIL] TRADE_METADATA");
return; }
  FileWrite(h,"S1995",r.route,r.mode,r.requestPriceAvailable?1:0,

DoubleToString(r.requestPrice,16),DoubleToString(r.slPrice,16),DoubleToString(r.tpPrice,16),
 DoubleToString(r.initialRiskMoney,16),r.riskValid?1:0,r.finalizationWritten?1:0,
 r.breakoutPriceAvailable?1:0,DoubleToString(r.breakoutPrice,16),
    (string)r.entryOrderTicket,DoubleToString(r.expectedEntryVolume,16),
    (string)AccountInfoInteger(ACCOUNT_LOGIN),Symbol(),(string)gMagicCore,
    (string)r.positionID,r.initialStopsProven?"COMPLETE_1995":"COMPLETE");
    FileFlush(h); FileClose(h);
}

void LoadTradeMetadata(TradeRecord &r)
{
  int h=FileOpen(TradeMetaPath(r.positionID),FILE_READ|FILE_CSV|FILE_ANSI,';');
  if(h==INVALID_HANDLE) return;
  if(FileReadString(h)!="S1995") { FileClose(h); return; }
  TradeRecord parsed=r;
  parsed.route=FileReadString(h); parsed.mode=FileReadString(h);
  string requestFlag=FileReadString(h);
  parsed.requestPriceAvailable=(requestFlag=="1");
  parsed.requestPrice=StringToDouble(FileReadString(h));
  parsed.slPrice=StringToDouble(FileReadString(h));
parsed.tpPrice=StringToDouble(FileReadString(h));
  parsed.initialRiskMoney=StringToDouble(FileReadString(h));
  string riskFlag=FileReadString(h), writtenFlag=FileReadString(h),
breakoutFlag=FileReadString(h);
  parsed.riskValid=(riskFlag=="1"); parsed.finalizationWritten=(writtenFlag=="1");
  parsed.breakoutPriceAvailable=(breakoutFlag=="1");
  parsed.breakoutPrice=StringToDouble(FileReadString(h));
  parsed.entryOrderTicket=(ulong)StringToInteger(FileReadString(h));
  parsed.expectedEntryVolume=StringToDouble(FileReadString(h));
  string account=FileReadString(h), symbol=FileReadString(h), magic=FileReadString(h);
  string pid=FileReadString(h), complete=FileReadString(h);
  FileClose(h);
  bool routeValid=((parsed.route=="ABS" && (parsed.mode=="BASE" ||
parsed.mode=="TURBO")) ||
     (parsed.route=="CONT" && (parsed.mode=="BASE_CONT" ||
parsed.mode=="TURBO_CONT")) ||
     (parsed.route=="UNAVAILABLE" && parsed.mode=="UNAVAILABLE"));
  bool flagsValid=((requestFlag=="0" || requestFlag=="1") &&
     (riskFlag=="0" || riskFlag=="1") && (writtenFlag=="0" || writtenFlag=="1") &&
     (breakoutFlag=="0" || breakoutFlag=="1"));
  bool valuesValid=(MathIsValidNumber(parsed.requestPrice) &&
MathIsValidNumber(parsed.slPrice) &&
     MathIsValidNumber(parsed.tpPrice) && MathIsValidNumber(parsed.initialRiskMoney) &&
     MathIsValidNumber(parsed.breakoutPrice) &&
MathIsValidNumber(parsed.expectedEntryVolume) &&
     parsed.requestPrice>=0 && parsed.slPrice>=0 && parsed.tpPrice>=0 &&
     parsed.initialRiskMoney>=0 && parsed.breakoutPrice>=0 &&
parsed.expectedEntryVolume>=0 &&
     (!parsed.requestPriceAvailable || parsed.requestPrice>0) &&
     (!parsed.riskValid || (parsed.initialRiskMoney>0 && parsed.slPrice>0)) &&
     (!parsed.breakoutPriceAvailable || parsed.breakoutPrice>0));
  bool identityValid=(account==(string)AccountInfoInteger(ACCOUNT_LOGIN) &&
symbol==Symbol() &&
     magic==(string)gMagicCore && pid==(string)r.positionID);
  if((complete!="COMPLETE" && complete!="COMPLETE_1995") || !routeValid || !flagsValid
|| !valuesValid || !identityValid)
  { Print("[SCALPER][TRADE_METADATA_INCOMPLETE_OR_INVALID] persisted fields not adopted"); return; }
  parsed.finalizationWritten=false; // CSV index is the output authority after restart.
    // Legacy RC1.1 metadata could contain a later mutable live SL/TP.
    parsed.initialStopsProven=(complete=="COMPLETE_1995" && parsed.slPrice>0);
    if(!parsed.initialStopsProven)
    { parsed.slPrice=0; parsed.tpPrice=0; parsed.initialRiskMoney=0; parsed.riskValid=false; }
    r=parsed;
}

bool IsConfirmedToday(ulong positionID)
{
  for(int i=0;i<ArraySize(gConfirmedPositionsToday);i++)
    if(gConfirmedPositionsToday[i]==positionID) return true;
  return false;
}
bool AddConfirmedToday(ulong positionID)
{
  if(positionID==0) return false;
  if(IsConfirmedToday(positionID)) return true;
  int n=ArraySize(gConfirmedPositionsToday);
  if(ArrayResize(gConfirmedPositionsToday,n+1)!=n+1)
  { gQuotaHistoryValid=false; return false; }
  gConfirmedPositionsToday[n]=positionID;
  return true;
}

int CountTodayTrades()
{
  datetime start=AccountingDayStart();
  if(!HistorySelect(start,TimeTradeServer())) return -1;
  ulong candidates[]; int count=0;
  for(int i=0;i<HistoryDealsTotal();i++)
  {
     ulong deal=HistoryDealGetTicket(i);
     int identity=Identify1995EntryDeal(deal);
     if(identity<0) return -1;
     if(identity==0) continue;
     ulong pid=(ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID);
     if(pid==0) return -1;
     bool seen=false;
     for(int j=0;j<count;j++) if(candidates[j]==pid) { seen=true; break; }
     if(!seen)
     {
         if(ArrayResize(candidates,count+1)!=count+1) return -1;
         candidates[count++]=pid;
     }
    }
    ulong confirmed[]; int confirmedCount=0;
    for(int i=0;i<count;i++)
    {
       if(!HistorySelectByPosition(candidates[i])) return -1;
       datetime first=0;
       for(int j=0;j<HistoryDealsTotal();j++)
       {
          ulong d=HistoryDealGetTicket(j);
          int identity=Identify1995EntryDeal(d);
          if(identity<0) return -1;
          if(identity==0) continue;
          datetime tm=(datetime)HistoryDealGetInteger(d,DEAL_TIME);
          if(first==0 || tm<first) first=tm;
       }
       if(first==0) return -1; // incomplete per-position evidence, retry later
       if(first>=start)
       {
          if(ArrayResize(confirmed,confirmedCount+1)!=confirmedCount+1) return -1;
          confirmed[confirmedCount++]=candidates[i];
       }
      }
      // Publish only a complete authoritative snapshot. A failed scan must not
      // replace the in-memory PID set with a partial one and allow duplicate quota.
      if(ArrayResize(gConfirmedPositionsToday,confirmedCount)!=confirmedCount) return -1;
      for(int i=0;i<confirmedCount;i++) gConfirmedPositionsToday[i]=confirmed[i];
      for(int i=0;i<gTradeRecordCount;i++)
         gTradeRecords[i].quotaCounted=IsConfirmedToday(gTradeRecords[i].positionID);
      return confirmedCount;
}

string DealExitReason(ulong deal,ulong positionID)
{
  ENUM_DEAL_REASON
reason=(ENUM_DEAL_REASON)HistoryDealGetInteger(deal,DEAL_REASON);
  switch(reason)
  {
    case DEAL_REASON_SL: return "SL";
    case DEAL_REASON_TP: return "TP";
    case DEAL_REASON_EXPERT:
     if(gPendingExit.active && gPendingExit.positionID==positionID &&
        HistoryDealGetInteger(deal,DEAL_MAGIC)==(long)gMagicCore &&
        ((gPendingExit.resultDeal>0 && gPendingExit.resultDeal==deal) ||
         (gPendingExit.orderTicket>0 &&
gPendingExit.orderTicket==(ulong)HistoryDealGetInteger(deal,DEAL_ORDER))))
      return gPendingExit.reason;
    return "EXPERT";
   case DEAL_REASON_CLIENT: return "MANUAL_DESKTOP";
   case DEAL_REASON_MOBILE: return "MANUAL_MOBILE";
   case DEAL_REASON_WEB: return "MANUAL_WEB";
   case DEAL_REASON_SO: return "STOP_OUT";
   case DEAL_REASON_ROLLOVER: return "ROLLOVER";
   case DEAL_REASON_VMARGIN: return "VMARGIN";
   case DEAL_REASON_SPLIT: return "SPLIT";
   case DEAL_REASON_CORPORATE_ACTION: return "CORPORATE_ACTION";
  }
  return EnumToString(reason)+"("+IntegerToString((int)reason)+")";
}

bool PendingMatchesDeal(ulong deal)
{
  if(!gPendingExec.active || !Is1995EntryDeal(deal)) return false;
  if(gPendingExec.resultDeal>0 && deal==gPendingExec.resultDeal) return true;
  ulong order=(ulong)HistoryDealGetInteger(deal,DEAL_ORDER);
  if(gPendingExec.orderTicket>0) return order==gPendingExec.orderTicket;
  // A request without ticket is first matched uniquely by the controlled
  // reconciler; rebuilding one PID must not silently choose among candidates.
  return false;
}

void AttachPendingToRecord(TradeRecord &r,ulong deal)
{
  if(!PendingMatchesDeal(deal)) return;
  r.route=gPendingExec.route; r.mode=gPendingExec.mode;
    r.requestPrice=gPendingExec.requestPrice;
    r.requestPriceAvailable=gPendingExec.requestPriceAvailable;
    r.slPrice=gPendingExec.slPrice; r.tpPrice=gPendingExec.tpPrice;
    r.initialStopsProven=(gPendingExec.slPrice>0);
    r.entryOrderTicket=(ulong)HistoryDealGetInteger(deal,DEAL_ORDER);
    r.expectedEntryVolume=gPendingExec.requestedLots;
    r.breakoutPrice=gPendingExec.breakoutPrice;
    r.breakoutPriceAvailable=gPendingExec.breakoutPriceAvailable;
    // Save before releasing the request guard. Armed is never an accounting source.
    SaveTradeMetadata(r);
    // A durable PID obligation must replace the request guard before it is
    // released; Positions can still lag this confirmed IN, including at restart.
    if(PersistEconomicMarker(r.positionID)) ResetPendingExec();
    else r.economicMarkerPending=true;
}

bool OwnPositionSafe(ulong positionID)
{
    if(!HistorySelectByPosition(positionID)) return false;
    bool ownEntry=false;
    for(int i=0;i<HistoryDealsTotal();i++)
    {
       ulong d=HistoryDealGetTicket(i);
       if(d==0 || HistoryDealGetString(d,DEAL_SYMBOL)!=Symbol()) continue;
       long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
       long type=HistoryDealGetInteger(d,DEAL_TYPE);
       if(type!=DEAL_TYPE_BUY && type!=DEAL_TYPE_SELL) continue;
       if(entry==DEAL_ENTRY_IN || entry==DEAL_ENTRY_INOUT)
       {
          if(entry==DEAL_ENTRY_IN && !Is1995EntryDeal(d)) return false;
          if(entry==DEAL_ENTRY_IN) ownEntry=true;
          else return false; // A reversal changes ownership of the net position.
       }
      }
      return ownEntry;
}

// Complete history is sorted explicitly. Transaction arrival order is irrelevant;
// economic totals are rebuilt, never incremented twice by replayed notifications.
bool RebuildTrackedHistory(int idx,bool restarting)
{
   ulong positionID=gTradeRecords[idx].positionID;
   if(!HistorySelectByPosition(positionID))
   { gTradeRecords[idx].historyRefreshPending=true;
gTradeRecords[idx].accountingResolved=false;
     gTradeRecords[idx].volumeOwnershipResolved=false;
     gTradeRecords[idx].ownCycleEconomicallyClosed=false;
     MarkTemporaryAccountingHistory(); return false; }
   ulong deals[]; long times[];
   int n=HistoryDealsTotal();
   if(ArrayResize(deals,n)!=n || ArrayResize(times,n)!=n)
   {
      gTradeRecords[idx].historyRefreshPending=true;
      gTradeRecords[idx].accountingResolved=false;
      gTradeRecords[idx].volumeOwnershipResolved=false;
      gTradeRecords[idx].ownCycleEconomicallyClosed=false;
      MarkTemporaryAccountingHistory(); return false;
   }
   for(int i=0;i<n;i++)
   { deals[i]=HistoryDealGetTicket(i);
times[i]=HistoryDealGetInteger(deals[i],DEAL_TIME_MSC); }
  for(int i=1;i<n;i++)
  {
     ulong d=deals[i]; long tm=times[i]; int j=i-1;
     while(j>=0 && (times[j]>tm || (times[j]==tm && deals[j]>d)))
   { deals[j+1]=deals[j]; times[j+1]=times[j]; j--; }
   deals[j+1]=d; times[j+1]=tm;
  }
  TradeRecord r=gTradeRecords[idx];
  r.historyRefreshPending=false;
  r.entryTime=0; r.exitTime=0; r.totalVolumeIn=0; r.totalVolumeOut=0;
  r.exitTimeMSC=0; r.lastExitDealTicket=0;
  r.weightedEntryPrice=0; r.weightedExitPrice=0;
  r.grossProfit=0; r.commission=0; r.fee=0; r.swap=0;
  r.accountingResolved=true;
  r.residualForeignDetected=false; r.ownCycleEconomicallyClosed=false;
  r.volumeOwnershipResolved=false; r.inoutCostsUnresolved=false;
  bool ownsCycle=false, foreignEntry=false, residualForeign=false;
  bool beHasContext=(r.be.stage!=BE_NONE); // rejected/new pending targets retain earlier certificates
  ulong beOwnExitDeals[]; int beOwnExitCount=0;
  bool beExitListValid=(!beHasContext || ArrayResize(beOwnExitDeals,n)==n);
  r.breakEvenExit=false; r.breakEvenClassificationPending=false;
  double tol=AccountingVolumeTolerance();
  for(int i=0;i<n;i++)
  {
     // Everything after a proven INOUT rejection belongs to the foreign residual.
     // Do not replay it into the original Scalper ledger, even with the same Magic.
     if(r.ownCycleEconomicallyClosed) break;
     ulong d=deals[i];
     if(d==0 || HistoryDealGetString(d,DEAL_SYMBOL)!=Symbol()) continue;
     long type=HistoryDealGetInteger(d,DEAL_TYPE);
     if(type!=DEAL_TYPE_BUY && type!=DEAL_TYPE_SELL) continue;
     long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
     long magic=HistoryDealGetInteger(d,DEAL_MAGIC);
     int dir=(type==DEAL_TYPE_BUY ? 1 : -1);
     double vol=HistoryDealGetDouble(d,DEAL_VOLUME);
     double price=HistoryDealGetDouble(d,DEAL_PRICE);
     datetime tm=(datetime)HistoryDealGetInteger(d,DEAL_TIME);
     if(vol<=0 || price<=0) { r.accountingResolved=false; continue; }
     if(entry==DEAL_ENTRY_IN)
     {
        if(!Is1995EntryDeal(d))
        { foreignEntry=true; if(ownsCycle) r.accountingResolved=false; continue; }
        if(foreignEntry || residualForeign || (ownsCycle && dir!=r.direction))
        { r.accountingResolved=false; continue; }
        if(!ownsCycle)
        {
           ownsCycle=true; r.direction=dir; r.entryTime=tm;
           AttachPendingToRecord(r,d);
           if(r.entryOrderTicket==0)
r.entryOrderTicket=(ulong)HistoryDealGetInteger(d,DEAL_ORDER);
           if(r.expectedEntryVolume<=0 && r.entryOrderTicket>0 &&
HistoryOrderSelect(r.entryOrderTicket))
        {
      ENUM_ORDER_STATE
orderState=(ENUM_ORDER_STATE)HistoryOrderGetInteger(r.entryOrderTicket,ORDER_STATE);
      if(orderState==ORDER_STATE_FILLED)

r.expectedEntryVolume=HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_INITIAL);
    else if(orderState==ORDER_STATE_CANCELED ||
orderState==ORDER_STATE_REJECTED ||
orderState==ORDER_STATE_EXPIRED)
r.expectedEntryVolume=HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_INITIAL)-

HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_CURRENT);
  }
  if(r.route=="UNAVAILABLE" || r.mode=="UNAVAILABLE")
  {
     string route,mode;
     if(ParseScalperComment(HistoryDealGetString(d,DEAL_COMMENT),route,mode))
     { r.route=route; r.mode=mode; }
     else if(HistoryOrderSelect(r.entryOrderTicket) &&

ParseScalperComment(HistoryOrderGetString(r.entryOrderTicket,ORDER_COMMENT),route,mode))
           { r.route=route; r.mode=mode; }
        }
     }
     double total=r.totalVolumeIn+vol;
     r.weightedEntryPrice=(r.weightedEntryPrice*r.totalVolumeIn+price*vol)/total;
     r.totalVolumeIn=total;
     r.grossProfit+=HistoryDealGetDouble(d,DEAL_PROFIT);
     r.commission+=HistoryDealGetDouble(d,DEAL_COMMISSION);
     r.fee+=HistoryDealGetDouble(d,DEAL_FEE);
r.swap+=HistoryDealGetDouble(d,DEAL_SWAP);
     if(r.entryTime>=AccountingDayStart())
     {
        if(!IsConfirmedToday(positionID))
        {
           if(AddConfirmedToday(positionID)) { ordersEnteredToday++; PersistShotCount(); }
        }
        r.quotaCounted=IsConfirmedToday(positionID);
     }
   }
   else if(entry==DEAL_ENTRY_OUT || entry==DEAL_ENTRY_OUT_BY ||
entry==DEAL_ENTRY_INOUT)
   {
    if(!ownsCycle) continue;
    double remaining=MathMax(0.0,r.totalVolumeIn-r.totalVolumeOut);
    if(remaining<=tol) continue;
    double ownVol=MathMin(vol,remaining);
      if(entry!=DEAL_ENTRY_INOUT && vol>remaining+tol) r.accountingResolved=false;
      double total=r.totalVolumeOut+ownVol;
      r.weightedExitPrice=(r.weightedExitPrice*r.totalVolumeOut+price*ownVol)/total;
      r.totalVolumeOut=total; r.exitTime=tm;
      r.exitTimeMSC=HistoryDealGetInteger(d,DEAL_TIME_MSC); r.lastExitDealTicket=d;
      // DEAL_PROFIT/SWAP of INOUT belong to its closing component.
      r.grossProfit+=HistoryDealGetDouble(d,DEAL_PROFIT);
      r.swap+=HistoryDealGetDouble(d,DEAL_SWAP);
       if(MathAbs(vol-ownVol)<=tol)
       {
          r.commission+=HistoryDealGetDouble(d,DEAL_COMMISSION);
          r.fee+=HistoryDealGetDouble(d,DEAL_FEE);
       }
       else if(HistoryDealGetDouble(d,DEAL_COMMISSION)!=0 ||
HistoryDealGetDouble(d,DEAL_FEE)!=0)
       {
          // A single INOUT cost has no authoritative close/reversal split.
          // Do not invent proportional fees for the unowned residual.
          if(entry==DEAL_ENTRY_INOUT) r.inoutCostsUnresolved=true;
          else r.accountingResolved=false;
          Print("[SCALPER][RESTART_ACCOUNTING_PARTIAL] INOUT_COST_ALLOCATION_UNAVAILABLE");
       }
       if(beHasContext && beExitListValid) beOwnExitDeals[beOwnExitCount++]=d;
       r.exitReason=DealExitReason(d,positionID);
       if(entry==DEAL_ENTRY_INOUT && vol>ownVol+tol)
       {
          // RC1 never requests a reversal: current-position guards forbid it.
          // Even a matching request cannot turn a mixed netting cycle into
          // a fresh positionID. Preserve the own close; reject appropriation.
          residualForeign=true; r.residualForeignDetected=true;
          r.ownCycleEconomicallyClosed=(gNetting && r.accountingResolved && !foreignEntry
&&
             r.totalVolumeIn>tol && r.totalVolumeOut+tol>=r.totalVolumeIn);
          Print("[SCALPER][INOUT_RESIDUAL_NOT_APPROPRIATED]");
       }
    }
 }
 if(!ownsCycle)
 { gTradeRecords[idx].historyRefreshPending=true;
gTradeRecords[idx].accountingResolved=false;
   gTradeRecords[idx].volumeOwnershipResolved=false;
   gTradeRecords[idx].ownCycleEconomicallyClosed=false;
    MarkTemporaryAccountingHistory(); return false; }
  if(foreignEntry) r.accountingResolved=false;
  r.entryPrice=r.weightedEntryPrice; r.exitPrice=r.weightedExitPrice;
  r.volume=r.totalVolumeIn;
  r.netProfit=r.grossProfit+r.commission+r.fee+r.swap;
  double liveVol,liveSL,liveTP; int liveDir;
  bool live=PositionStateByID(positionID,liveVol,liveSL,liveTP,liveDir);
  if(live && !residualForeign)
 {
     // Initial SL/TP come from request/metadata/entry order, not mutable live stops.
     double expected=r.totalVolumeIn-r.totalVolumeOut;
     // During transaction delivery, the deal cache and position state can lag
     // independently. A completed OUT waits in TryFinalize until flat; a
     // transient state mismatch does not permanently poison the record.
   if(restarting && (MathAbs(expected-liveVol)>tol || liveDir!=r.direction))
      r.accountingResolved=false;
   }
   if(r.entryOrderTicket>0 && HistoryOrderSelect(r.entryOrderTicket))
   {
      double initialSL=HistoryOrderGetDouble(r.entryOrderTicket,ORDER_SL);
      if(initialSL>0)
      {
         r.slPrice=initialSL; r.tpPrice=HistoryOrderGetDouble(r.entryOrderTicket,ORDER_TP);
         r.initialStopsProven=true;
      }
   }
   if(!r.initialStopsProven) { r.slPrice=0; r.tpPrice=0; }
   double risk=CalcInitialRiskMoney(r.direction,r.weightedEntryPrice,r.slPrice,r.totalVolumeIn);
   if(risk>0) { r.initialRiskMoney=risk; r.riskValid=true; }
   else { r.initialRiskMoney=0; r.riskValid=false; }
   if(r.requestPriceAvailable)
      r.entrySlippage=(double)r.direction*(r.weightedEntryPrice-r.requestPrice);
   else r.entrySlippage=EMPTY_VALUE;
   r.volumeClosedComplete=(r.totalVolumeIn>tol && r.totalVolumeOut+tol>=r.totalVolumeIn);
   r.volumeOwnershipResolved=r.accountingResolved;
   r.ownCycleEconomicallyClosed=(r.ownCycleEconomicallyClosed &&
      r.volumeOwnershipResolved && r.volumeClosedComplete &&
r.residualForeignDetected);
   // Classify only after the complete entry mean and initial order stops are rebuilt.
   ClassifyProtectionExits(r,beOwnExitDeals,beOwnExitCount,beExitListValid);
  if(r.inoutCostsUnresolved)
  { r.accountingResolved=false; r.netProfit=EMPTY_VALUE; r.PnL_R=EMPTY_VALUE;
r.pnlRValid=false; }
  if(r.volumeClosedComplete && gOpenPos.active && gOpenPos.positionID==positionID &&
     (r.expectedEntryVolume<=0 || r.totalVolumeIn+tol>=r.expectedEntryVolume))
  {
     // Volume already closed stops excursion tracking even if Positions lags
     // or an unowned INOUT residual still occupies the netting identifier.
     r.MAE=gOpenPos.MAE; r.MFE=gOpenPos.MFE; ResetOpenPos();
  }
  if(restarting) r.maeMfePartialAfterRestart=true;
  r.holdSeconds=(r.exitTime>0 ? (long)(r.exitTime-r.entryTime) : 0);
  gTradeRecords[idx]=r;
  SyncEconomicMarker(idx);
  if(!r.accountingResolved)
  {
     if(live && !CanIgnoreForeignResidual(r)) gLiveOwnershipUnresolved=true;
     gDailyEconomicsValid=false;
     gDailyPnLRValid=false;
     gDailyHistoryRetryRequired=true;
     Print("[SCALPER][RESTART_ACCOUNTING_UNRESOLVED] historical/current volume or ownership mismatch");
  }
  SaveTradeMetadata(gTradeRecords[idx]);
   return true;
}

void SyncOpenPositionFromRecord(int idx)
{
  TradeRecord r=gTradeRecords[idx];
  if(r.volumeClosedComplete) return;
  double volume,sl,tp; int direction;
  if(r.totalVolumeIn<=0 || !r.accountingResolved) return;
  bool positionVisible=PositionStateByID(r.positionID,volume,sl,tp,direction);
  if(positionVisible && direction!=r.direction) return;
  if(gOpenPos.active && gOpenPos.positionID!=r.positionID)
  { gLiveOwnershipUnresolved=true;
Print("[SCALPER][MULTIPLE_OWN_POSITIONS_UNRESOLVED]"); return; }
  if(!gOpenPos.active)
  { ResetOpenPos(); gOpenPos.active=true; gOpenPos.MAE=r.MAE;
gOpenPos.MFE=r.MFE; }
  gOpenPos.positionID=r.positionID; gOpenPos.direction=r.direction;
  gOpenPos.entryPrice=r.weightedEntryPrice; gOpenPos.lots=r.totalVolumeIn;
  gOpenPos.entryTime=r.entryTime; gOpenPos.route=r.route; gOpenPos.mode=r.mode;
  gOpenPos.initialRiskMoney=r.initialRiskMoney; gOpenPos.tradeRecordIdx=idx;
}

bool CanIgnoreForeignResidual(const TradeRecord &r)
{
  double tol=AccountingVolumeTolerance();
  return gNetting && !r.historyRefreshPending && r.volumeOwnershipResolved &&
   r.residualForeignDetected && r.ownCycleEconomicallyClosed &&
   r.totalVolumeIn>tol && r.totalVolumeOut+tol>=r.totalVolumeIn;
}

bool MayFinalizeTrackedCycle(const TradeRecord &r)
{
  if(r.breakEvenClassificationPending) return false;
  if(r.historyRefreshPending) return false;
  // Unknown costs may keep economics partial, without keeping the own cycle open.
  return r.accountingResolved || (CanIgnoreForeignResidual(r) && r.inoutCostsUnresolved);
}

bool IsTrackedVolumeCycleComplete(const TradeRecord &r)
{
  if(!MayFinalizeTrackedCycle(r) || !r.volumeClosedComplete) return false;
  if(HasOwnPendingOrder() || gPendingOrderClassificationUnresolved ||
     gOrderRegistryUnavailable || gMultipleOwnOrdersActive ||
     gOrderObligationScanUnresolved) return false;
  // Every observed exact-order lifecycle associated with this PID must finish,
  // not only the first entry order. A vanished UNKNOWN still carries its PID.
  for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
     if(gUnresolvedOrders[i].active &&
        (gUnresolvedOrders[i].positionID==r.positionID ||
         gUnresolvedOrders[i].positionByID==r.positionID)) return false;
  double vol,sl,tp; int direction;
  if(PositionStateByID(r.positionID,vol,sl,tp,direction) && !CanIgnoreForeignResidual(r))
return false;
  if(r.entryOrderTicket>0 && OrderSelect(r.entryOrderTicket))
     return false;
  // A notified exit can precede other entry fills. A known requested quantity
  // provides a further guard, without assuming FOK means one deal.
    if(r.expectedEntryVolume>0 &&
r.totalVolumeIn+AccountingVolumeTolerance()<r.expectedEntryVolume)
    {
      bool completed=false;
      if(r.entryOrderTicket>0 && HistoryOrderSelect(r.entryOrderTicket))
      {
         ENUM_ORDER_STATE
st=(ENUM_ORDER_STATE)HistoryOrderGetInteger(r.entryOrderTicket,ORDER_STATE);
         if(st==ORDER_STATE_CANCELED || st==ORDER_STATE_REJECTED ||
st==ORDER_STATE_EXPIRED)
           // Rejected terminal orders can also have confirmed partial fills.
         {
            double
filled=HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_INITIAL)-
               HistoryOrderGetDouble(r.entryOrderTicket,ORDER_VOLUME_CURRENT);
            completed=(MathAbs(filled-r.totalVolumeIn)<=AccountingVolumeTolerance());
         }
      }
      if(!completed) return false;
    }
    return true;
}

void TryFinalizeTrackedTrade(ulong positionID)
{
  int idx=FindTrackedTrade(positionID);
  if(idx<0 || gTradeRecords[idx].closed || !gTradeRecords[idx].volumeClosedComplete)
return;
  TradeRecord r=gTradeRecords[idx];
  if(!MayFinalizeTrackedCycle(r)) return;
  if(!IsTrackedVolumeCycleComplete(r)) { gNeedsAccountingSync=true; return; }
  if(gOpenPos.active && gOpenPos.positionID==positionID)
  { r.MAE=gOpenPos.MAE; r.MFE=gOpenPos.MFE; }
  r.closed=true; r.holdSeconds=(long)(r.exitTime-r.entryTime);
  r.netProfit=(r.accountingResolved ? r.grossProfit+r.commission+r.fee+r.swap :
EMPTY_VALUE);
  if(r.accountingResolved && r.riskValid && r.initialRiskMoney>0)
  { r.PnL_R=r.netProfit/r.initialRiskMoney; r.pnlRValid=true; }
  else
  { r.PnL_R=EMPTY_VALUE; r.pnlRValid=false;
Print("[SCALPER][ACCOUNTING_RISK_UNAVAILABLE]"); }
  if(!r.accountingResolved)
  {
     // Acknowledge this partial cycle once; no invented net result or loss count.
     r.PnL_R=EMPTY_VALUE; r.pnlRValid=false; r.dailyApplied=true;
     gDailyEconomicsValid=false; gDailyPnLRValid=false;
     gDailyEconomicsState=ECONOMIC_ALLOCATION_IMPOSSIBLE;
     lastCloseConfirmedTime=TimeTradeServer();
     RecomputeDailyRiskBlock();
     PersistDailyAccounting();
     Print("[SCALPER][OWN_CYCLE_CLOSED_ACCOUNTING_PARTIAL] INOUT_COST_ALLOCATION_UNAVAILABLE");
  }
  if(r.accountingResolved && !r.dailyApplied && r.exitTime>=AccountingDayStart())
  {
     dailyNetPnL+=r.netProfit;
     if(r.pnlRValid) dailyPnLR+=r.PnL_R;
     else gDailyPnLRValid=false;
     lastTradeWasLoss=BEManagerLoss(r);
     consecutiveLosses=(lastTradeWasLoss ? consecutiveLosses+1 : 0);
     lastCloseConfirmedTime=TimeTradeServer();
     if(Inp_EnableDailyRiskStop && gDailyPnLRValid && dailyPnLR<=-Inp_MaxDailyLossR)
        gDailyRiskLimitLatched=true;
     if(Inp_EnableConsecutiveLossStop && gDailyEconomicsValid &&
consecutiveLosses>=Inp_MaxConsecutiveLosses)
        gDailyRiskLimitLatched=true;
     r.dailyApplied=true;
     gDailyHistoryRetryRequired=true;
     RecomputeDailyRiskBlock();
     PersistDailyAccounting();
  }
  gTradeRecords[idx]=r;
  if(!r.finalizationWritten && csvTradeHandle!=INVALID_HANDLE)
  {
     if(WriteTradeRow(gTradeRecords[idx])) gTradeRecords[idx].finalizationWritten=true;
  }
  SaveTradeMetadata(gTradeRecords[idx]);
  SyncEconomicMarker(idx);
  FailExitIntent(positionID);
  if(gOpenPos.active && gOpenPos.positionID==positionID) ResetOpenPos();
}

int FindUnresolvedOrder(ulong ticket)
{
  for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
    if(gUnresolvedOrders[i].active && gUnresolvedOrders[i].orderTicket==ticket) return i;
  return -1;
}

int RememberUnresolvedOrder(ulong ticket)
{
  if(ticket==0) return -1; // Request context itself protects an unknown ticket.
  // Commit the exact identity before any allocation can lose its RAM slot.
  bool present=FileIsExist(OrderObligationPath(ticket));
  bool durable=EnsureOrderObligationIdentity(ticket);
  if(!durable) gOrderObligationScanUnresolved=true;
  int idx=FindUnresolvedOrder(ticket);
if(idx>=0)
{
   if(!present || !durable) gUnresolvedOrders[idx].persistencePending=true;
   for(int i=0;i<gOrderRegistryFallbackCount;i++)
      if(gOrderRegistryFallback[i]==ticket)
      {
         for(int j=i+1;j<gOrderRegistryFallbackCount;j++)
            gOrderRegistryFallback[j-1]=gOrderRegistryFallback[j];
         gOrderRegistryFallbackCount--; break;
      }
   return idx;
}
int n=ArraySize(gUnresolvedOrders);
idx=-1;
for(int i=0;i<n;i++) if(!gUnresolvedOrders[i].active) { idx=i; break; }
if(idx<0)
{
   if(ArrayResize(gUnresolvedOrders,n+1)!=n+1)
   {
      bool seen=false;
      for(int i=0;i<gOrderRegistryFallbackCount;i++)
         if(gOrderRegistryFallback[i]==ticket) { seen=true; break; }
      if(!seen)
      {
         if(gOrderRegistryFallbackCount<MAX_TRADE_RECORDS)
            gOrderRegistryFallback[gOrderRegistryFallbackCount++]=ticket;
         else if(!FileIsExist(OrderObligationPath(ticket)))
         {
            // Only a genuinely lost identity is a permanent obligation.
            gOrderRegistryOverflow=true;
            MarkInfrastructureIdentityLoss();
         }
      }
      // A durable filename remains recoverable even if both RAM lists fill.
      gOrderObligationScanUnresolved=true;
      gOrderRegistryUnavailable=true; gPendingOrderClassificationUnresolved=true;
      return -1;
   }
   idx=n;
  }
  UnresolvedOrderContext c;
  UnknownOrderObligationContext(ticket,c);
  c.firstSeen=TimeTradeServer();
  if(!gOrderObligationRestoring) PersistOrderObligationSnapshot(c);
  gUnresolvedOrders[idx]=c;
  gPendingOrderClassificationUnresolved=true;
  for(int i=0;i<gOrderRegistryFallbackCount;i++)
     if(gOrderRegistryFallback[i]==ticket)
      {
          for(int j=i+1;j<gOrderRegistryFallbackCount;j++)
           gOrderRegistryFallback[j-1]=gOrderRegistryFallback[j];
          gOrderRegistryFallbackCount--; break;
      }
    return idx;
}

bool ReadOwnOrder(UnresolvedOrderContext &c,bool &live)
{
  ulong ticket=c.orderTicket;
  live=OrderSelect(ticket);
  if(!live && !HistoryOrderSelect(ticket)) return false;
  string
symbol=live?OrderGetString(ORDER_SYMBOL):HistoryOrderGetString(ticket,ORDER_SYMBOL);
  long
magic=live?OrderGetInteger(ORDER_MAGIC):HistoryOrderGetInteger(ticket,ORDER_MAGIC);
  if(symbol!=Symbol() || magic!=(long)gMagicCore) return false;

c.orderType=live?OrderGetInteger(ORDER_TYPE):HistoryOrderGetInteger(ticket,ORDER_TYPE);

c.orderReason=live?OrderGetInteger(ORDER_REASON):HistoryOrderGetInteger(ticket,ORDER_REASON);
 ulong
pid=(ulong)(live?OrderGetInteger(ORDER_POSITION_ID):HistoryOrderGetInteger(ticket,ORDER_POSITION_ID));
 if(c.positionID>0 && pid>0 && c.positionID!=pid) return false;
 if(pid>0) c.positionID=pid;

c.positionByID=(ulong)(live?OrderGetInteger(ORDER_POSITION_BY_ID):HistoryOrderGetInteger(ticket,ORDER_POSITION_BY_ID));

c.setupTime=(datetime)(live?OrderGetInteger(ORDER_TIME_SETUP):HistoryOrderGetInteger(ticket,ORDER_TIME_SETUP));
 c.doneTime=live?0:(datetime)HistoryOrderGetInteger(ticket,ORDER_TIME_DONE);
c.lastState=(ENUM_ORDER_STATE)(live?OrderGetInteger(ORDER_STATE):HistoryOrderGetInteger(ticket,ORDER_STATE));

c.initialVolume=live?OrderGetDouble(ORDER_VOLUME_INITIAL):HistoryOrderGetDouble(ticket,ORDER_VOLUME_INITIAL);

c.remainingVolume=live?OrderGetDouble(ORDER_VOLUME_CURRENT):HistoryOrderGetDouble(ticket,ORDER_VOLUME_CURRENT);
c.comment=live?OrderGetString(ORDER_COMMENT):HistoryOrderGetString(ticket,ORDER_COMMENT);
  return c.setupTime>0 && c.initialVolume>0 && c.remainingVolume>=0;
}

bool PendingOrderFillEvidence(ulong order,bool &entryFill,bool &exitFill,
                  bool &conflict,ulong &positionID,double &filledVolume,
                  string &route,string &mode)
{
  entryFill=false; exitFill=false; conflict=false;
  positionID=0; filledVolume=0; route="UNAVAILABLE"; mode="UNAVAILABLE";
  UnresolvedOrderContext c; c.orderTicket=order; c.positionID=0;
  bool live;
  if(!ReadOwnOrder(c,live)) return false;
  // No account-wide scan from zero. Setup is the authoritative lower bound;
  // one second of overlap covers timestamps truncated by ORDER_TIME_SETUP.
  datetime until=TimeTradeServer();
  if(c.doneTime>=until) until=c.doneTime+1;
  if(!HistorySelect(c.setupTime-1,until)) return false;
  for(int i=0;i<HistoryDealsTotal();i++)
  {
     ulong d=HistoryDealGetTicket(i);
     if(d==0 || (ulong)HistoryDealGetInteger(d,DEAL_ORDER)!=order) continue;
     if(HistoryDealGetString(d,DEAL_SYMBOL)!=Symbol()) { conflict=true; continue; }
     long type=HistoryDealGetInteger(d,DEAL_TYPE);
     if(type!=DEAL_TYPE_BUY && type!=DEAL_TYPE_SELL) continue;
     ulong pid=(ulong)HistoryDealGetInteger(d,DEAL_POSITION_ID);
     long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
     // CLOSE_BY has two position IDs. Its paired OUT_BY is not a second
     // fill of the primary position; both ledgers reconcile independently.
     if(c.orderType==ORDER_TYPE_CLOSE_BY && pid==c.positionByID &&
pid!=c.positionID)
     {
        if(entry!=DEAL_ENTRY_OUT_BY) conflict=true;
        continue;
     }
     if(pid==0 || (positionID>0 && positionID!=pid) ||
        (c.positionID>0 && c.positionID!=pid)) conflict=true;
   positionID=pid;
   if(entry==DEAL_ENTRY_IN)
   {
      entryFill=true;
      if(!Is1995EntryDeal(d)) conflict=true;
      string foundRoute,foundMode;

if(ParseScalperComment(HistoryDealGetString(d,DEAL_COMMENT),foundRoute,foundMode))
      {
          if(route!="UNAVAILABLE" && (route!=foundRoute || mode!=foundMode))
conflict=true;
          route=foundRoute; mode=foundMode;
        }
     }
     else if(entry==DEAL_ENTRY_OUT || entry==DEAL_ENTRY_OUT_BY ||
entry==DEAL_ENTRY_INOUT)
        exitFill=true; // Own portion of INOUT must still be proven by the ledger.
     else conflict=true;
     double volume=HistoryDealGetDouble(d,DEAL_VOLUME);
     if(volume<=0 || !MathIsValidNumber(volume)) conflict=true;
     else filledVolume+=volume;
  }
  if(entryFill && exitFill) conflict=true;
  return true;
}

bool TerminalOrder(ENUM_ORDER_STATE state)
{
  return state==ORDER_STATE_FILLED || state==ORDER_STATE_CANCELED ||
     state==ORDER_STATE_REJECTED || state==ORDER_STATE_EXPIRED;
}

bool ProvenOrderFillComplete(const UnresolvedOrderContext &c,double filled)
{
  double expected=c.initialVolume-c.remainingVolume;
  double tol=AccountingVolumeTolerance();
  return TerminalOrder(c.lastState) && expected>=-tol &&
     MathAbs(expected-filled)<=tol &&
     (c.lastState!=ORDER_STATE_FILLED || filled>tol);
}

bool AdoptLiveEntry(const UnresolvedOrderContext &c)
{
  string verifiedRoute,verifiedMode;
  if(StringFind(c.comment,"S1995|")!=0 ||
     !ParseScalperComment(c.comment,verifiedRoute,verifiedMode) ||
     verifiedRoute!=c.route || verifiedMode!=c.mode) return false;
  if(gRequestJournalUnresolved || gRequestJournalWritePending ||
     gEntryJournalCleanupPending || gExitJournalCleanupPending) return false;
  if(gPendingExit.active) return false;
  if(gPendingExec.active)
 {
     // Never overwrite a known request with a newly discovered ambiguous order.
     if(gPendingExec.orderTicket==c.orderTicket) return true;
     return false;
  }
  if(!OrderSelect(c.orderTicket)) return false;
  ResetPendingExec(false); gPendingExec.active=true; gPendingExec.accepted=true;
  gPendingExec.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  gPendingExec.orderTicket=c.orderTicket;
  gPendingExec.direction=(c.orderType==ORDER_TYPE_BUY?1:-1);
  gPendingExec.sentAt=c.setupTime; gPendingExec.requestedLots=c.initialVolume;
  gPendingExec.slPrice=OrderGetDouble(ORDER_SL);
gPendingExec.tpPrice=OrderGetDouble(ORDER_TP);
  gPendingExec.route=c.route; gPendingExec.mode=c.mode;
  gPendingExec.requestPriceAvailable=false;
  PersistRequestJournal(false);
  return true;
}

bool AdoptLiveExit(const UnresolvedOrderContext &c)
{
  if(gRequestJournalUnresolved || gRequestJournalWritePending ||
     gEntryJournalCleanupPending || gExitJournalCleanupPending) return false;
  if(c.positionID==0 || gPendingExec.active) return false;
  if(gPendingExit.active && (gPendingExit.positionID!=c.positionID ||
     (gPendingExit.orderTicket>0 && gPendingExit.orderTicket!=c.orderTicket))) return false;
  if(!gPendingExit.active) BeginExitIntent(c.positionID,"RECOVERED_EXIT");
  gPendingExit.orderTicket=c.orderTicket; gPendingExit.sentAt=c.setupTime;
  gPendingExit.accepted=true;
  PersistRequestJournal(true);
  return true;
}

void RestorePendingOrder()
{
  int found=0;
  bool complete=true;
  // Failed allocations retain exact identities independently of OrdersTotal.
  int fallback=gOrderRegistryFallbackCount;
  for(int i=fallback-1;i>=0;i--)
     if(RememberUnresolvedOrder(gOrderRegistryFallback[i])<0) complete=false;
  for(int i=OrdersTotal()-1;i>=0;i--)
  {
     ulong ticket=OrderGetTicket(i);
     if(ticket==0) { complete=false; continue; }
     if(OrderGetString(ORDER_SYMBOL)!=Symbol() ||
OrderGetInteger(ORDER_MAGIC)!=(long)gMagicCore) continue;
     found++;
     if(RememberUnresolvedOrder(ticket)<0) complete=false;
  }
  gMultipleOwnOrdersActive=found>1;
  gOrderRegistryUnavailable=!complete || gOrderRegistryFallbackCount>0 ||
gOrderRegistryOverflow;
  gPendingOrderClassificationUnresolved=gMultipleOwnOrdersActive ||
gOrderRegistryUnavailable ||
     gOrderObligationScanUnresolved;
  for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
     if(gUnresolvedOrders[i].active && (gUnresolvedOrders[i].classificationPending ||
        gUnresolvedOrders[i].persistencePending))
        gPendingOrderClassificationUnresolved=true;
    // Zero live orders does not clear any stored ambiguity.
}

void ReconcileUnresolvedOrders()
{
   RestorePendingOrder();
   for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
   {
     if(!gUnresolvedOrders[i].active) continue;
     UnresolvedOrderContext c=gUnresolvedOrders[i];
     c.classificationPending=true;
     bool live;
     if(!ReadOwnOrder(c,live)) { StoreOrderObligationContext(i,c,false); continue; }
     bool entryFill,exitFill,conflict; ulong pid; double filled; string route,mode;
     if(!PendingOrderFillEvidence(c.orderTicket,entryFill,exitFill,conflict,pid,filled,route,mode)
|| conflict)
     { StoreOrderObligationContext(i,c,true); continue; }
     if(pid>0) c.positionID=pid;
     bool marker=StringFind(c.comment,"S1995|")==0 &&
ParseScalperComment(c.comment,c.route,c.mode);
     bool market=c.orderType==ORDER_TYPE_BUY || c.orderType==ORDER_TYPE_SELL;
     int idx=FindTrackedTrade(c.positionID);
     if(entryFill || exitFill)
     {
        if(entryFill && (!market || c.positionByID>0 || c.orderReason==ORDER_REASON_SL ||
           c.orderReason==ORDER_REASON_TP ||
           (marker && route!="UNAVAILABLE" && (c.route!=route || c.mode!=mode))))
        { StoreOrderObligationContext(i,c,true); continue; }
        // OUT with another Magic is admitted only through proven own IN history.
        if(idx<0 && (entryFill || HasOwnEntryHistory(c.positionID)))
        {
           idx=NewTrackedTrade(c.positionID);
           if(idx>=0) LoadTradeMetadata(gTradeRecords[idx]);
        }
        if(idx<0 || !RebuildTrackedHistory(idx,false)) { StoreOrderObligationContext(i,c,true);
continue; }
        TradeRecord r=gTradeRecords[idx];
      bool own=r.volumeOwnershipResolved && r.totalVolumeIn>0;
      if(!own || (entryFill && (r.residualForeignDetected || r.entryOrderTicket!=c.orderTicket)))
      { StoreOrderObligationContext(i,c,true); continue; }
      c.nature=entryFill?PENDING_ORDER_ENTRY:PENDING_ORDER_EXIT;
      if(exitFill && gPendingExec.active && gPendingExec.orderTicket==c.orderTicket)
         ResetPendingExec(); // Exact order + own exit ledger, never an inferred entry.
      SyncOpenPositionFromRecord(idx);
      TryFinalizeTrackedTrade(c.positionID);
      if(c.positionByID>0)
   {
        int by=FindTrackedTrade(c.positionByID);
        if(by<0 && HasOwnEntryHistory(c.positionByID))
        { by=NewTrackedTrade(c.positionByID); if(by>=0)
LoadTradeMetadata(gTradeRecords[by]); }
        if(by>=0 && RebuildTrackedHistory(by,false))
TryFinalizeTrackedTrade(c.positionByID);
     }
     if(!live && ProvenOrderFillComplete(c,filled))
     {
        if(ReleaseOrderObligation(c) && exitFill && gPendingExit.active &&
           gPendingExit.orderTicket==c.orderTicket &&
           gPendingExit.positionID==c.positionID && gTradeRecords[idx].closed)
           FailExitIntent(c.positionID,true);
     }
     else if(live && !gMultipleOwnOrdersActive)
     {
        // A confirmed own IN is already represented by its ledger. Do not
        // recreate/reset entry request metadata after the first fill.
        bool adopted=entryFill?true:AdoptLiveExit(c);
        c.classificationPending=!adopted;
     }
   }
   else if(!live && ProvenOrderFillComplete(c,filled) &&
c.lastState!=ORDER_STATE_FILLED)
   {
     // Terminal negative state plus complete, exact-order zero-fill history.
     if(ReleaseOrderObligation(c))
     {
        if(gPendingExec.active && gPendingExec.orderTicket==c.orderTicket)
ResetPendingExec();
        if(gPendingExit.active && gPendingExit.orderTicket==c.orderTicket)
FailExitIntent(gPendingExit.positionID,true);
     }
   }
   else if(live && !gMultipleOwnOrdersActive)
   {
     if(marker && market && c.orderReason!=ORDER_REASON_SL &&
c.orderReason!=ORDER_REASON_TP &&
        c.positionID==0 && c.positionByID==0 && !HasOpenPosition())
     {
        c.nature=PENDING_ORDER_ENTRY; c.classificationPending=!AdoptLiveEntry(c);
      }
      else if(!marker && idx>=0 && gTradeRecords[idx].accountingResolved &&
OwnPositionSafe(c.positionID))
      {
        TradeRecord r=gTradeRecords[idx]; double volume,sl,tp; int direction;
        double remainder=r.totalVolumeIn-r.totalVolumeOut;
     bool opposite=(c.orderType==ORDER_TYPE_BUY && r.direction==-1) ||
             (c.orderType==ORDER_TYPE_SELL && r.direction==1);
     bool bounded=!r.closed && remainder>0 && c.remainingVolume>0 &&
        c.remainingVolume<=remainder+AccountingVolumeTolerance() &&
        PositionStateByID(c.positionID,volume,sl,tp,direction) && direction==r.direction &&
        MathAbs(volume-remainder)<=AccountingVolumeTolerance();
     if(bounded && ((market && opposite && c.positionByID==0) ||
        (c.orderType==ORDER_TYPE_CLOSE_BY && c.positionByID>0)))
     { c.nature=PENDING_ORDER_EXIT; c.classificationPending=!AdoptLiveExit(c); }
    }
  }
  StoreOrderObligationContext(i,c,true);
  }
  gPendingOrderClassificationUnresolved=gMultipleOwnOrdersActive ||
gOrderRegistryUnavailable ||
    gOrderObligationScanUnresolved;
  for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
    if(gUnresolvedOrders[i].active && (gUnresolvedOrders[i].classificationPending ||
       gUnresolvedOrders[i].persistencePending))
       gPendingOrderClassificationUnresolved=true;
}

bool MatchesUnidentifiedEntryOrder(ulong ticket)
{
  UnresolvedOrderContext c; ZeroMemory(c);
  c.orderTicket=ticket; bool live;
  if(!ReadOwnOrder(c,live) || gPendingExec.sentAt<=0 ||
     c.setupTime<gPendingExec.sentAt || c.positionByID>0 ||
     c.orderReason==ORDER_REASON_SL || c.orderReason==ORDER_REASON_TP)
return false;
  int direction=(c.orderType==ORDER_TYPE_BUY?1:
     (c.orderType==ORDER_TYPE_SELL?-1:0));
  string route,mode;
  return direction==gPendingExec.direction &&
     ParseScalperComment(c.comment,route,mode) && route==gPendingExec.route &&
     mode==gPendingExec.mode &&
     MathAbs(c.initialVolume-gPendingExec.requestedLots)<=AccountingVolumeTolerance();
}

void RecoverUnidentifiedEntryOrder()
{
  if(!gPendingExec.active || gPendingExec.orderTicket>0 ||
      gPendingExec.resultDeal>0 || gPendingExec.sentAt<=0) return;
   datetime start=gPendingExec.sentAt-1;
   if(!HistorySelect(start,TimeTradeServer())) { MarkTemporaryAccountingHistory(); return; }
   // Snapshot exact tickets before HistoryOrderSelect changes the selected list.
   ulong tickets[]; int count=0;
   int total=HistoryOrdersTotal()+OrdersTotal();
   if(ArrayResize(tickets,total)!=total) { MarkTemporaryAccountingHistory(); return; }
   for(int i=0;i<HistoryOrdersTotal();i++)
   {
      ulong ticket=HistoryOrderGetTicket(i);
      if(ticket>0 && HistoryOrderGetString(ticket,ORDER_SYMBOL)==Symbol() &&
         HistoryOrderGetInteger(ticket,ORDER_MAGIC)==(long)gMagicCore)
tickets[count++]=ticket;
   }
   for(int i=0;i<OrdersTotal();i++)
   {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0 || OrderGetString(ORDER_SYMBOL)!=Symbol() ||
         OrderGetInteger(ORDER_MAGIC)!=(long)gMagicCore) continue;
      bool known=false;
      for(int j=0;j<count;j++) if(tickets[j]==ticket) { known=true; break; }
      if(!known) tickets[count++]=ticket;
   }
   ulong candidate=0; int matches=0;
   for(int i=0;i<count;i++)
      if(MatchesUnidentifiedEntryOrder(tickets[i]))
      {
         matches++; candidate=tickets[i];
         RememberUnresolvedOrder(tickets[i]);
      }
   if(matches==1)
   {
      // Own symbol/Magic, exact route/mode, request volume/type and uniqueness
      // jointly associate the order; time and BUY/SELL alone never do so.
      gPendingExec.orderTicket=candidate;
      gPendingExec.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
      PersistRequestJournal(false);
   }
}

void ReconcilePendingExecution()
{
  if(!gPendingExec.active) return;
  RecoverUnidentifiedEntryOrder();
  ulong order=gPendingExec.orderTicket;
  if(order==0 && gPendingExec.resultDeal>0 &&
HistoryDealSelect(gPendingExec.resultDeal))
  {
     ulong d=gPendingExec.resultDeal;
     if(!Is1995EntryDeal(d)) return;
     order=(ulong)HistoryDealGetInteger(d,DEAL_ORDER);
     gPendingExec.orderTicket=order;
    }
    if(order==0) return; // Transport uncertainty has no negative proof.
    RememberUnresolvedOrder(order);
}

void ReconcilePendingExitIntent()
{
  if(!gPendingExit.active) return;
  ulong pid=gPendingExit.positionID;
  int idx=FindTrackedTrade(pid);
  if(idx>=0 && !gTradeRecords[idx].closed)
  {
     if(!RebuildTrackedHistory(idx,false)) return;
     TryFinalizeTrackedTrade(pid);
     if(!gPendingExit.active) return;
  }
  ulong order=gPendingExit.orderTicket;
  if(order==0 && gPendingExit.resultDeal>0 && HistoryDealSelect(gPendingExit.resultDeal))
  {
     ulong d=gPendingExit.resultDeal; long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
     if(HistoryDealGetString(d,DEAL_SYMBOL)!=Symbol() ||
        (ulong)HistoryDealGetInteger(d,DEAL_POSITION_ID)!=pid ||
        (entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY &&
entry!=DEAL_ENTRY_INOUT)) return;
     order=(ulong)HistoryDealGetInteger(d,DEAL_ORDER); gPendingExit.orderTicket=order;
  }
  if(order==0) return;
  int oi=RememberUnresolvedOrder(order);
  if(oi<0) return;
  UnresolvedOrderContext c=gUnresolvedOrders[oi]; bool live;
  if(!ReadOwnOrder(c,live) || live) return;
  bool entryFill,exitFill,conflict; ulong fillPID; double filled; string route,mode;
  if(!PendingOrderFillEvidence(order,entryFill,exitFill,conflict,fillPID,filled,route,mode) ||
     conflict || entryFill || (fillPID>0 && fillPID!=pid) || !ProvenOrderFillComplete(c,filled))
return;
  bool released=ReleaseOrderObligation(c);
  StoreOrderObligationContext(oi,c,false);
  if(!released) return;
  RestorePendingOrder();
  if(idx>=0 && gTradeRecords[idx].closed)
  { FailExitIntent(pid,true); return; }
  if(!exitFill && c.lastState!=ORDER_STATE_FILLED)
  { FailExitIntent(pid,true); return; }
  if(idx<0 || !RebuildTrackedHistory(idx,false)) return;
  TryFinalizeTrackedTrade(pid);
  if(!gPendingExit.active) return;
  if(gTradeRecords[idx].closed) { FailExitIntent(pid,true); return; }
  TradeRecord r=gTradeRecords[idx]; double liveVol,sl,tp; int direction;
  double remainder=r.totalVolumeIn-r.totalVolumeOut;
  if(r.accountingResolved && remainder>AccountingVolumeTolerance() &&
OwnPositionSafe(pid) &&
    PositionStateByID(pid,liveVol,sl,tp,direction) && direction==r.direction &&
    MathAbs(liveVol-remainder)<=AccountingVolumeTolerance()) FailExitIntent(pid,true);
}


void ReconstructOpenPosition(bool restarting=true)
{
  // A fresh authoritative scan owns this flag; absence alone does not clear a
  // tracked order/deal ambiguity, which has its own independent context.
  gLiveOwnershipUnresolved=false;
  ulong ids[]; int count=0;
  for(int i=PositionsTotal()-1;i>=0;i--)
  {
     ulong ticket=PositionGetTicket(i);
     if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=Symbol()) continue;
     ulong pid=(ulong)PositionGetInteger(POSITION_IDENTIFIER);
     long liveMagic=PositionGetInteger(POSITION_MAGIC);
     int tracked=FindTrackedTrade(pid);
     if(!HistorySelectByPosition(pid))
     {
        if(gNetting || liveMagic==(long)gMagicCore || tracked>=0)
           gLiveOwnershipUnresolved=true;
        continue;
     }
     bool ownEntry=false;
     for(int j=0;j<HistoryDealsTotal();j++)
     {
        ulong d=HistoryDealGetTicket(j);
        if(Is1995EntryDeal(d))
        { ownEntry=true; break; }
     }
     if(!OwnPositionSafe(pid))
     {
        if(gNetting && ownEntry)
        {
           int idx=tracked; bool existing=(idx>=0);
           if(idx<0) idx=NewTrackedTrade(pid);
           if(idx>=0)
           {
              if(!existing) LoadTradeMetadata(gTradeRecords[idx]);
              if(RebuildTrackedHistory(idx,restarting) &&
                 CanIgnoreForeignResidual(gTradeRecords[idx]))
              { TryFinalizeTrackedTrade(pid); continue; }
           }
        gLiveOwnershipUnresolved=true;
        continue;
     }
     if(ownEntry || liveMagic==(long)gMagicCore || tracked>=0)
        gLiveOwnershipUnresolved=true;
     continue;
     }
     if(ArrayResize(ids,count+1)!=count+1)
     { gLiveOwnershipUnresolved=true; continue; }
     ids[count++]=pid;
    }
    if(count>1) gLiveOwnershipUnresolved=true;
    for(int i=0;i<count;i++)
    {
       int idx=FindTrackedTrade(ids[i]); bool existing=(idx>=0);
       if(idx<0) idx=NewTrackedTrade(ids[i]);
       if(idx<0) { gLiveOwnershipUnresolved=true; continue; }
       if(!existing) LoadTradeMetadata(gTradeRecords[idx]);
       if(!RebuildTrackedHistory(idx,restarting))
       { gLiveOwnershipUnresolved=true; continue; }
       if(!gTradeRecords[idx].accountingResolved)
       { gLiveOwnershipUnresolved=true; continue; }
       // Keep the one-slot excursion tracker from adopting a second position.
       if(count==1) SyncOpenPositionFromRecord(idx);
       if(restarting && !gTradeRecords[idx].requestPriceAvailable)
          Print("[SCALPER][REQUEST_PRICE_UNAVAILABLE_AFTER_RESTART]");
       if(restarting) Print("[SCALPER][MAE_MFE_PARTIAL_AFTER_RESTART] 1");
    }
}

bool RestoreDailyEconomicsFromHistory(bool restarting=true)
{
  datetime start=AccountingDayStart();
  datetime previousCloseConfirmation=lastCloseConfirmedTime;
  if(!HistorySelect(start,TimeTradeServer()))
  {
     gDailyEconomicsValid=false; gDailyPnLRValid=false;
     gDailyEconomicsState=TEMPORARY_HISTORY_UNAVAILABLE;
     gDailyHistoryRetryRequired=true;
     return false;
  }
  ulong ids[]; int n=0;
  for(int i=0;i<HistoryDealsTotal();i++)
  {
     ulong d=HistoryDealGetTicket(i);
     if(d==0 || HistoryDealGetString(d,DEAL_SYMBOL)!=Symbol()) continue;
     long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
     if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY &&
        entry!=DEAL_ENTRY_INOUT) continue;
     ulong pid=(ulong)HistoryDealGetInteger(d,DEAL_POSITION_ID);
 if(pid==0)
 {
    gDailyEconomicsValid=false; gDailyPnLRValid=false;
    gDailyEconomicsState=TEMPORARY_HISTORY_UNAVAILABLE;
 gDailyHistoryRetryRequired=true;
    return false;
 }
 bool seen=false;
 for(int j=0;j<n;j++) if(ids[j]==pid) { seen=true; break; }
 if(!seen)
 {
    if(ArrayResize(ids,n+1)!=n+1)
    {
       gDailyEconomicsValid=false; gDailyPnLRValid=false;
       gDailyEconomicsState=DAILY_ECONOMICS_UNRESOLVED;
       return false;
    }
    ids[n++]=pid;
 }
}
int closedIdx[]; int closedCount=0;
int finalizeIdx[]; int finalizeCount=0;
double net=0, sumR=0;
bool rValid=true, allResolved=true, historyUnavailable=false;
bool allocationImpossible=false;
for(int i=0;i<n;i++)
{
  int idx=FindTrackedTrade(ids[i]); bool existing=(idx>=0);
  // First establish ownership from complete per-position history. A
  // manual OUT with another Magic is still part of the proven own cycle.
  if(!HistorySelectByPosition(ids[i]))
  { allResolved=false; historyUnavailable=true; continue; }
  bool own=false;
  for(int j=0;j<HistoryDealsTotal();j++)
  {
     ulong d=HistoryDealGetTicket(j);
     int identity=Identify1995EntryDeal(d);
     if(identity<0) { allResolved=false; historyUnavailable=true; continue; }
     if(identity==1) { own=true; break; }
  }
  if(!own) continue;
  if(idx<0) idx=NewTrackedTrade(ids[i]);
  if(idx<0) { allResolved=false; continue; }
  if(!existing) LoadTradeMetadata(gTradeRecords[idx]);
  if(!RebuildTrackedHistory(idx,restarting))
   { allResolved=false; historyUnavailable=true; continue; }
   TradeRecord r=gTradeRecords[idx];
    if(!MayFinalizeTrackedCycle(r))
    {
       allResolved=false;
       if(r.inoutCostsUnresolved) allocationImpossible=true;
       continue;
    }
    if(!IsTrackedVolumeCycleComplete(r))
    {
       if(r.volumeClosedComplete)
       { gNeedsAccountingSync=true; allResolved=false; historyUnavailable=true; }
       continue;
    }
    if(r.exitTime<start) continue;
    // The authoritative aggregate applies the day once; TryFinalize remains
    // the closure authority and therefore cannot add this cycle a second time.
    r.dailyApplied=true;
    if(!r.accountingResolved)
    {
       r.netProfit=EMPTY_VALUE; r.PnL_R=EMPTY_VALUE; r.pnlRValid=false;
       allResolved=false; rValid=false;
       if(r.inoutCostsUnresolved) allocationImpossible=true;
       gTradeRecords[idx]=r;
    }
    else
    {
       if(r.riskValid && r.initialRiskMoney>0)
       { r.PnL_R=r.netProfit/r.initialRiskMoney; r.pnlRValid=true; sumR+=r.PnL_R; }
       else { r.PnL_R=EMPTY_VALUE; r.pnlRValid=false; rValid=false; }
       net+=r.netProfit;
       gTradeRecords[idx]=r;
       if(ArrayResize(closedIdx,closedCount+1)!=closedCount+1)
       { allResolved=false; continue; }
       closedIdx[closedCount++]=idx;
    }
    if(ArrayResize(finalizeIdx,finalizeCount+1)!=finalizeCount+1)
    { allResolved=false; continue; }
    finalizeIdx[finalizeCount++]=idx;
    }
    for(int i=1;i<closedCount;i++)
    {
      int x=closedIdx[i],j=i-1;
      while(j>=0 &&
(gTradeRecords[closedIdx[j]].exitTimeMSC>gTradeRecords[x].exitTimeMSC ||
         (gTradeRecords[closedIdx[j]].exitTimeMSC==gTradeRecords[x].exitTimeMSC &&
          (gTradeRecords[closedIdx[j]].lastExitDealTicket>gTradeRecords[x].lastExitDealTicket
||
(gTradeRecords[closedIdx[j]].lastExitDealTicket==gTradeRecords[x].lastExitDealTicket &&
        gTradeRecords[closedIdx[j]].positionID>gTradeRecords[x].positionID)))))
   { closedIdx[j+1]=closedIdx[j]; j--; }
   closedIdx[j+1]=x;
 }
 int losses=0; datetime last=0; bool lastLoss=false;
 double runningR=0; bool runningRValid=true;
 for(int i=0;i<closedCount;i++)
 {
    TradeRecord r=gTradeRecords[closedIdx[i]];
    lastLoss=BEManagerLoss(r); losses=(lastLoss ? losses+1 : 0); last=r.exitTime;
    if(r.pnlRValid) runningR+=r.PnL_R; else runningRValid=false;
    // Recover an already-hit stop from the historical daily path, even if a
    // subsequent close recovered the total. These are the existing limits.
    if(Inp_EnableDailyRiskStop && allResolved && runningRValid &&
       runningR<=-Inp_MaxDailyLossR)
       gDailyRiskLimitLatched=true;
    if(Inp_EnableConsecutiveLossStop && allResolved &&
       losses>=Inp_MaxConsecutiveLosses)
       gDailyRiskLimitLatched=true;
 }
 dailyNetPnL=net; dailyPnLR=sumR;
 consecutiveLosses=losses;
 // A retry must not move a known runtime confirmation clock backwards.

lastCloseConfirmedTime=(previousCloseConfirmation>last?previousCloseConfirmation:last);
  lastTradeWasLoss=lastLoss;
  gDailyEconomicsValid=allResolved;
  gDailyHistoryRetryRequired=historyUnavailable;
  gDailyPnLRValid=(rValid && allResolved);
  gDailyEconomicsState=(allocationImpossible ? ECONOMIC_ALLOCATION_IMPOSSIBLE
:
    (historyUnavailable ? TEMPORARY_HISTORY_UNAVAILABLE :
     (allResolved ? DAILY_ECONOMICS_VALID : DAILY_ECONOMICS_UNRESOLVED)));
  RecomputeDailyRiskBlock();
  for(int i=0;i<finalizeCount;i++)
  {
    int idx=finalizeIdx[i];
    if(!gTradeRecords[idx].closed) TryFinalizeTrackedTrade(gTradeRecords[idx].positionID);
    else FailExitIntent(gTradeRecords[idx].positionID);
  }
  return allResolved;
}

void RestoreDailyPersistence(bool restarting=true)
{
  RestoreUnresolvedEconomicMarkers();
  int historyCount=CountTodayTrades();
  bool committed=GlobalVariableCheck(AccountingKey("VALID")) &&
     GlobalVariableGet(AccountingKey("VALID"))==1.0 &&
     GlobalVariableCheck(GvKeyDailyPnL()) && GlobalVariableCheck(GvKeyDailyPnLR())
&&
     GlobalVariableCheck(GvKeyConsecLoss()) &&
GlobalVariableCheck(GvKeyDailyBlock());
  gQuotaHistoryValid=(historyCount>=0);
  if(gQuotaHistoryValid) ordersEnteredToday=historyCount;
  // A failed read does not adopt an old counter or publish a partial PID set.
  // Entries remain blocked until a complete CountTodayTrades succeeds.
  if(committed && GlobalVariableCheck(AccountingKey("RISK_LATCH")) &&
     GlobalVariableGet(AccountingKey("RISK_LATCH"))==1.0)
     gDailyRiskLimitLatched=true;
  bool reconstructed=RestoreDailyEconomicsFromHistory(restarting);
  if(!reconstructed && committed)
  {
     dailyNetPnL=GlobalVariableGet(GvKeyDailyPnL());
     dailyPnLR=GlobalVariableGet(GvKeyDailyPnLR());
     consecutiveLosses=(int)GlobalVariableGet(GvKeyConsecLoss());
     // A committed snapshot can predate an unprocessed close. It is partial
     // evidence and cannot restore validity while history is unavailable.
     gDailyEconomicsValid=false; gDailyPnLRValid=false;
     if(GlobalVariableCheck(AccountingKey("CLOSE")))
        lastCloseConfirmedTime=(datetime)GlobalVariableGet(AccountingKey("CLOSE"));
     if(GlobalVariableCheck(AccountingKey("LASTLOSS")))
        lastTradeWasLoss=(GlobalVariableGet(AccountingKey("LASTLOSS"))==1.0);
  }
  ReconstructOpenPosition(restarting);
  if(restarting || !gPendingExec.active) RestorePendingOrder();
  RecomputeDailyRiskBlock(); RecomputeAccountingBlock();
  if(gQuotaHistoryValid && reconstructed) PersistDailyAccounting();
}

// RC1.2 infrastructure helpers; final EA lifecycle follows below.
void RememberDeferredAccountingPID(ulong pid)
{
   for(int i=0;i<ArraySize(gDeferredAccountingPIDs);i++)
      if(gDeferredAccountingPIDs[i]==pid) return;
   int n=ArraySize(gDeferredAccountingPIDs);
   if(ArrayResize(gDeferredAccountingPIDs,n+1)!=n+1)
   {
      bool seen=false;
      for(int i=0;i<gDeferredFallbackCount;i++) if(gDeferredFallback[i]==pid) { seen=true;
break; }
      if(!seen)
      {
      if(gDeferredFallbackCount<MAX_TRADE_RECORDS)
gDeferredFallback[gDeferredFallbackCount++]=pid;
      else
      {
         gDeferredRegistryOverflow=true;
         MarkInfrastructureIdentityLoss();
      }
    }
    gDeferredRegistryUnavailable=true;
  }
  else gDeferredAccountingPIDs[n]=pid;
  gAccountingCapacityUnresolved=true;
}

void ForgetDeferredAccountingPID(ulong pid)
{
  int n=ArraySize(gDeferredAccountingPIDs);
  for(int i=0;i<n;i++)
    if(gDeferredAccountingPIDs[i]==pid)
    {
       for(int j=i+1;j<n;j++) gDeferredAccountingPIDs[j-1]=gDeferredAccountingPIDs[j];
       ArrayResize(gDeferredAccountingPIDs,n-1); break;
    }
  gAccountingCapacityUnresolved=(gDeferredRegistryUnavailable ||
ArraySize(gDeferredAccountingPIDs)>0);
  for(int i=0;i<gDeferredFallbackCount;i++)
    if(gDeferredFallback[i]==pid)
    {
       for(int j=i+1;j<gDeferredFallbackCount;j++)
gDeferredFallback[j-1]=gDeferredFallback[j];
       gDeferredFallbackCount--; break;
    }
  gDeferredRegistryUnavailable=gDeferredRegistryOverflow || gDeferredFallbackCount>0;
  gAccountingCapacityUnresolved=gDeferredRegistryUnavailable ||
ArraySize(gDeferredAccountingPIDs)>0;
}

bool IsFinalRejectedRetcode(uint ret)
{
  switch(ret)
  {
    case TRADE_RETCODE_REQUOTE: case TRADE_RETCODE_REJECT:
    case TRADE_RETCODE_CANCEL: case TRADE_RETCODE_INVALID:
    case TRADE_RETCODE_INVALID_VOLUME: case
TRADE_RETCODE_INVALID_PRICE:
    case TRADE_RETCODE_INVALID_STOPS: case
TRADE_RETCODE_TRADE_DISABLED:
    case TRADE_RETCODE_MARKET_CLOSED: case TRADE_RETCODE_NO_MONEY:
    case TRADE_RETCODE_PRICE_CHANGED: case TRADE_RETCODE_PRICE_OFF:
    case TRADE_RETCODE_INVALID_EXPIRATION: case
TRADE_RETCODE_TOO_MANY_REQUESTS:
    case TRADE_RETCODE_SERVER_DISABLES_AT: case
TRADE_RETCODE_CLIENT_DISABLES_AT:
    case TRADE_RETCODE_INVALID_FILL: case TRADE_RETCODE_ONLY_REAL:
    case TRADE_RETCODE_LIMIT_ORDERS: case TRADE_RETCODE_LIMIT_VOLUME:
    case TRADE_RETCODE_INVALID_ORDER: case
TRADE_RETCODE_POSITION_CLOSED:
    case TRADE_RETCODE_INVALID_CLOSE_VOLUME: case
TRADE_RETCODE_LIMIT_POSITIONS:
    case TRADE_RETCODE_LONG_ONLY: case TRADE_RETCODE_SHORT_ONLY:
    case TRADE_RETCODE_CLOSE_ONLY: case TRADE_RETCODE_FIFO_CLOSE:
    case TRADE_RETCODE_HEDGE_PROHIBITED: return true;
  }
  return false; // Unknown, LOCKED, ERROR and CLOSE_ORDER_EXIST are uncertain.
}

void CompletePendingExit(const MqlTradeResult &result)
{
  if(!gPendingExit.active) return;
  gPendingExit.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  if(result.request_id>0) gPendingExit.requestID=result.request_id;
  if(result.order>0) gPendingExit.orderTicket=result.order;
  if(result.deal>0) gPendingExit.resultDeal=result.deal;
  if(IsAcceptedRetcode(result.retcode))
  { gPendingExit.accepted=true; gPendingExit.uncertain=false; }
  else if(IsFinalRejectedRetcode(result.retcode) && !gPendingExit.accepted &&
     gPendingExit.orderTicket==0 && gPendingExit.resultDeal==0)
     FailExitIntent(gPendingExit.positionID,true);
  else gPendingExit.uncertain=true;
  if(gPendingExit.active) PersistRequestJournal(true);
  gNeedsAccountingSync=true;
}

bool MatchesExitRequest(const MqlTradeRequest &request,const MqlTradeResult &result)
{
  if(!gPendingExit.active || gPendingExit.positionTicket==0 ||
     gPendingExit.requestID==0 || result.request_id!=gPendingExit.requestID) return false;
  return request.position==gPendingExit.positionTicket && request.symbol==Symbol() &&
     request.magic==(ulong)gMagicCore && request.action==TRADE_ACTION_DEAL &&
     request.position_by==0 && request.type==gPendingExit.requestSnapshot.type &&

MathAbs(request.volume-gPendingExit.requestSnapshot.volume)<=AccountingVolumeTolerance();
}
void SyncAccountingState(bool reconcilePending=false)
{
    // Tick path is a cheap projection only. No history selection/finalization.
    if(!reconcilePending) { RecomputeAccountingBlock(); return; }
    datetime now=TimeTradeServer();
    if(now<gNextOrderReconcile) { RecomputeAccountingBlock(); return; }
    gNextOrderReconcile=now+5; // Timer or transaction transition, never each tick.
    RecoverTradeCsvInfrastructure();
    ReconcileDeferredDeals();
    RecoverAccountingInfrastructure();
    ReconcilePendingExecution();
    ReconcileUnresolvedOrders();
    ReconcilePendingExitIntent();
    for(int i=0;i<gTradeRecordCount;i++)
    {
       if(gTradeRecords[i].historyRefreshPending ||
          (!gTradeRecords[i].closed && !gTradeRecords[i].accountingResolved &&
           !gTradeRecords[i].inoutCostsUnresolved))
       {
          if(RebuildTrackedHistory(i,false)) SyncOpenPositionFromRecord(i);
       }
       if(!gTradeRecords[i].closed) TryFinalizeTrackedTrade(gTradeRecords[i].positionID);
       else if(gPendingExit.active && gPendingExit.positionID==gTradeRecords[i].positionID)
          FailExitIntent(gPendingExit.positionID);
    }
    gNeedsAccountingSync=false;
    if(csvTradeHandle!=INVALID_HANDLE)
       for(int i=0;i<gTradeRecordCount;i++)
          if(gTradeRecords[i].closed && !gTradeRecords[i].finalizationWritten &&
             MayFinalizeTrackedCycle(gTradeRecords[i]))
          {
             if(WriteTradeRow(gTradeRecords[i]))
             {
                gTradeRecords[i].finalizationWritten=true;
                SaveTradeMetadata(gTradeRecords[i]); SyncEconomicMarker(i);
             }
          }
    RecomputeDailyRiskBlock();
    RecomputeAccountingBlock();
}

void RecomputeAccountingBlock()
{
  gAccountingCapacityUnresolved=(ArraySize(gDeferredAccountingPIDs)>0 ||
   gDeferredRegistryUnavailable);
  bool blocked=gPendingOrderClassificationUnresolved || !gQuotaHistoryValid ||
   gLiveOwnershipUnresolved || gAccountingCapacityUnresolved ||
   gMultipleOwnOrdersActive || gOrderRegistryUnavailable ||
   gOrderObligationScanUnresolved ||
     ArraySize(gDeferredDeals)>0 || gDeferredDealFallbackCount>0 ||
gDeferredDealOverflow ||
     !gDailyEconomicsValid || gEconomicMarkerScanUnresolved ||
     gIdentityLossUnresolved || gRequestJournalUnresolved ||
     gRequestJournalWritePending || gEntryJournalCleanupPending ||
gExitJournalCleanupPending;
  for(int i=0;i<gTradeRecordCount;i++)
  {
     TradeRecord r=gTradeRecords[i];
     if(r.positionID==0) continue;
     // An INOUT cost that cannot be allocated is an explicit permanent
     // economic ambiguity; midnight cannot invent the missing allocation.
     bool relevant=!r.closed || r.exitTime>=AccountingDayStart() ||
        r.inoutCostsUnresolved;
     if(r.economicMarkerPending) blocked=true;
     if(r.breakEvenClassificationPending) blocked=true;
     if(relevant && (r.historyRefreshPending || !r.accountingResolved ||
        r.inoutCostsUnresolved)) blocked=true;
  }
  for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
     if(gUnresolvedOrders[i].active && (gUnresolvedOrders[i].classificationPending ||
        gUnresolvedOrders[i].persistencePending)) blocked=true;
  // The only assignment to the aggregate blocker is here.
  gAccountingUnresolved=blocked;
}

void RecomputeDailyRiskBlock()
{
  // Preserve the existing daily stop latch for an actual economic breach.
  // History validity itself is recomputed and never latched as a breach.
  if(Inp_EnableDailyRiskStop && gDailyPnLRValid &&
     dailyPnLR<=-Inp_MaxDailyLossR) gDailyRiskLimitLatched=true;
  if(Inp_EnableConsecutiveLossStop && gDailyEconomicsValid &&
     consecutiveLosses>=Inp_MaxConsecutiveLosses) gDailyRiskLimitLatched=true;
  // Match RC1.1: a persisted daily stop cannot enable disabled controls.
  dailyRiskBlocked=(gDailyRiskLimitLatched &&
     (Inp_EnableDailyRiskStop || Inp_EnableConsecutiveLossStop)) ||
     (Inp_EnableDailyRiskStop && !gDailyPnLRValid) ||
     (Inp_EnableConsecutiveLossStop && !gDailyEconomicsValid);
}

void RecoverAccountingInfrastructure()
{
  bool needsQuota=!gQuotaHistoryValid;
  bool needsEconomics=gDailyHistoryRetryRequired ||
   (gDailyEconomicsState!=ECONOMIC_ALLOCATION_IMPOSSIBLE &&
    (!gDailyEconomicsValid || !gDailyPnLRValid));
  bool needsRecords=false;
bool needsMarkers=gEMRMaintenanceNeeded || gEconomicMarkerScanUnresolved || gIdentityLossPersistPending ||
   gOrderObligationScanUnresolved || gOrderRegistryUnavailable ||
   gRequestJournalUnresolved || gRequestJournalWritePending ||
   gEntryJournalCleanupPending || gExitJournalCleanupPending;
for(int i=0;i<gTradeRecordCount;i++)
   if(gTradeRecords[i].economicMarkerPending ||
      gTradeRecords[i].economicMarkerCleanupPending) needsMarkers=true;
for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
   if(gUnresolvedOrders[i].active && gUnresolvedOrders[i].persistencePending)
needsMarkers=true;
for(int i=0;i<gTradeRecordCount;i++)
{
   TradeRecord r=gTradeRecords[i];
   if(r.positionID>0 && !r.inoutCostsUnresolved &&
      (r.historyRefreshPending || (!r.closed && !r.accountingResolved)))
   { needsRecords=true; break; }
}
if(!needsQuota && !needsEconomics && !needsRecords && !needsMarkers &&
   !gLiveOwnershipUnresolved && !gAccountingCapacityUnresolved) return;
datetime now=TimeTradeServer();
if(gLastAccountingRecoveryTime>0 && now-gLastAccountingRecoveryTime<10) return;
gLastAccountingRecoveryTime=now;
if(gIdentityLossPersistPending) PersistInfrastructureIdentityLoss();
RecoverRequestJournals();
if(gOrderObligationScanUnresolved || gOrderRegistryUnavailable)
RestoreOrderObligations();
RecoverEconomicMarkers();
// Snapshot deferred identities because NewTrackedTrade removes each PID
// after successful allocation. Failed allocations never forget the PID.
// No snapshot allocation is necessary: iterate backwards and remove only
// the exact PID recovered by NewTrackedTrade/ForgetDeferredAccountingPID.
for(int list=0;list<2;list++)
{
   int
deferredCount=list==0?ArraySize(gDeferredAccountingPIDs):gDeferredFallbackCount;
   for(int i=deferredCount-1;i>=0;i--)
   {
      ulong pid=list==0?gDeferredAccountingPIDs[i]:gDeferredFallback[i];
      if(!HistorySelectByPosition(pid)) continue;
      bool own=false;
      for(int j=0;j<HistoryDealsTotal();j++)
      {
         ulong deal=HistoryDealGetTicket(j);
         if(Is1995EntryDeal(deal))
         { own=true; break; }
      }
      if(!own) continue;
       int idx=FindTrackedTrade(pid); bool existing=(idx>=0);
       if(idx<0) idx=NewTrackedTrade(pid);
       if(idx<0) continue;
       ForgetDeferredAccountingPID(pid);
       if(!existing) LoadTradeMetadata(gTradeRecords[idx]);
       if(RebuildTrackedHistory(idx,false))
       {
          SyncOpenPositionFromRecord(idx);
          TryFinalizeTrackedTrade(pid); gNeedsAccountingSync=true;
       }
     }
    }
    if(needsQuota)
    {
       int count=CountTodayTrades();
       if(count>=0) { ordersEnteredToday=count; gQuotaHistoryValid=true; }
    }
    if(needsRecords)
    {
       for(int i=0;i<gTradeRecordCount;i++)
       {
          TradeRecord r=gTradeRecords[i];
          if(r.positionID==0 || r.inoutCostsUnresolved ||
             !(r.historyRefreshPending || (!r.closed && !r.accountingResolved))) continue;
          if(RebuildTrackedHistory(i,false))
          { SyncOpenPositionFromRecord(i); gNeedsAccountingSync=true; }
       }
    }
    if(gLiveOwnershipUnresolved || gAccountingCapacityUnresolved)
       ReconstructOpenPosition(false);
    // Record repair can invalidate or recover today's economics. Rebuild the
    // current-day window only; never query the account from time zero here.
    if(needsEconomics || needsRecords || !gDailyEconomicsValid)
       RestoreDailyEconomicsFromHistory(false);
    RecomputeDailyRiskBlock(); RecomputeAccountingBlock();
    if(gQuotaHistoryValid && gDailyEconomicsValid) PersistDailyAccounting();
}

void RecoverTradeCsvInfrastructure()
{
  if(gTradeCsvFileName=="" ||
     (csvTradeHandle!=INVALID_HANDLE && gTradeCsvIndexLoaded &&
gTradeCsvAppendSafe)) return;
  datetime now=TimeTradeServer();
  if(now<gNextTradeCsvRecovery) return;
  gNextTradeCsvRecovery=now+30;
  // Reopen the current path after unavailable I/O or external repair. Never
  // truncate/repair an existing file, and never trust metadata as CSV presence.
if(csvTradeHandle!=INVALID_HANDLE)
{ FileClose(csvTradeHandle); csvTradeHandle=INVALID_HANDLE; }
csvTradeHandle=FileOpen(gTradeCsvFileName,

FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE);
  if(csvTradeHandle==INVALID_HANDLE) return;
  ResetLastError();
  ulong size=FileSize(csvTradeHandle);
  if(GetLastError()!=0)
  { FileClose(csvTradeHandle); csvTradeHandle=INVALID_HANDLE; return; }
  if(size==0)
  {
     WriteTradeHeader();
     FileFlush(csvTradeHandle);
  }
  // Invalid schema/tail stays append-disabled. A later full successful scan
  // can recognize an authoritative external repair without destroying rows.
  if(!InitializeTradeCsvIndex(gTradeCsvFileName)) return;
  if(!FileSeek(csvTradeHandle,0,SEEK_END)) gTradeCsvAppendSafe=false;
}

void MarkTemporaryAccountingHistory()
{
  gDailyHistoryRetryRequired=true;
  gDailyEconomicsValid=false; gDailyPnLRValid=false;
  if(gDailyEconomicsState!=ECONOMIC_ALLOCATION_IMPOSSIBLE)
     gDailyEconomicsState=TEMPORARY_HISTORY_UNAVAILABLE;
}

bool ProcessAccountingDeal(ulong ticket)
{
  if(!HistoryDealSelect(ticket)) return false;
  if(HistoryDealGetString(ticket,DEAL_SYMBOL)!=Symbol()) return true;
  long type=HistoryDealGetInteger(ticket,DEAL_TYPE);
  if(type!=DEAL_TYPE_BUY && type!=DEAL_TYPE_SELL) return true;
  long entry=HistoryDealGetInteger(ticket,DEAL_ENTRY);
  ulong pid=(ulong)HistoryDealGetInteger(ticket,DEAL_POSITION_ID);
  long magic=HistoryDealGetInteger(ticket,DEAL_MAGIC);
  if(pid==0) return false;
  int idx=FindTrackedTrade(pid);
  int newIdentity=Identify1995EntryDeal(ticket);
  if(newIdentity<0) return false;
  bool ownNew=(newIdentity==1);
  if(idx<0 && ownNew)
  {
     idx=NewTrackedTrade(pid);
     if(idx>=0) LoadTradeMetadata(gTradeRecords[idx]);
  }
  if(idx<0 && (entry==DEAL_ENTRY_OUT || entry==DEAL_ENTRY_OUT_BY ||
entry==DEAL_ENTRY_INOUT))
  {
     // Unavailable ownership history is not a proven foreign cycle.
     if(!HistorySelectByPosition(pid)) return false;
     bool own=false;
     for(int i=0;i<HistoryDealsTotal();i++)
     {
        ulong d=HistoryDealGetTicket(i);
        int identity=Identify1995EntryDeal(d);
        if(identity<0) return false;
        if(identity==1) { own=true; break; }
     }
     if(!own) return true;
     idx=NewTrackedTrade(pid);
     if(idx>=0)
     { LoadTradeMetadata(gTradeRecords[idx]);
gTradeRecords[idx].maeMfePartialAfterRestart=true; }
  }
  if(idx<0) return !ownNew; // Capacity failure retains own IN identity for retry.
  if(gTradeRecords[idx].closed) return true;
  if(!RebuildTrackedHistory(idx,false)) return false;
  SyncOpenPositionFromRecord(idx); TryFinalizeTrackedTrade(pid);
  return true;
}

void RememberDeferredDeal(ulong ticket)
{
  MarkTemporaryAccountingHistory();
  // Keep the exact event identity even if no position or own record is visible.
  for(int i=0;i<ArraySize(gDeferredDeals);i++) if(gDeferredDeals[i]==ticket) return;
  for(int i=0;i<gDeferredDealFallbackCount;i++) if(gDeferredDealFallback[i]==ticket) return;
  int n=ArraySize(gDeferredDeals);
  if(ArrayResize(gDeferredDeals,n+1)==n+1) gDeferredDeals[n]=ticket;
  else if(gDeferredDealFallbackCount<MAX_TRADE_RECORDS)
     gDeferredDealFallback[gDeferredDealFallbackCount++]=ticket;
  else
  {
     gDeferredDealOverflow=true;
     MarkInfrastructureIdentityLoss();
  }
}

void ReconcileDeferredDeals()
{
  for(int i=ArraySize(gDeferredDeals)-1;i>=0;i--)
   if(ProcessAccountingDeal(gDeferredDeals[i]))
    {
       int n=ArraySize(gDeferredDeals);
       for(int j=i+1;j<n;j++) gDeferredDeals[j-1]=gDeferredDeals[j];
       ArrayResize(gDeferredDeals,n-1);
     }
    for(int i=gDeferredDealFallbackCount-1;i>=0;i--)
     if(ProcessAccountingDeal(gDeferredDealFallback[i]))
     {
        for(int j=i+1;j<gDeferredDealFallbackCount;j++)
         gDeferredDealFallback[j-1]=gDeferredDealFallback[j];
        gDeferredDealFallbackCount--;
     }
}

string EconomicMarkerPrefix()
{
  return StringFormat("Scalper1995_%I64d_%s_%I64d_",
    AccountInfoInteger(ACCOUNT_LOGIN),Symbol(),(long)gMagicCore);
}

string EconomicMarkerPath(ulong pid)
{ return EconomicMarkerPrefix()+(string)pid+".econ.partial"; }

string IdentityLossMarkerPath()
{ return EconomicMarkerPrefix()+"identity.loss"; }

void PersistInfrastructureIdentityLoss()
{
  string path=IdentityLossMarkerPath();
  if(FileIsExist(path)) { gIdentityLossPersistPending=false; return; }
  gIdentityLossPersistPending=true;
  int h=FileOpen(path,FILE_WRITE|FILE_TXT|FILE_ANSI);
  if(h==INVALID_HANDLE) return;
  string message="S1995_IDENTITY_EVIDENCE_LOST\r\n";
  ResetLastError();
  uint written=FileWriteString(h,message);
  bool ok=(written==(uint)StringLen(message) && GetLastError()==0);
  ResetLastError(); FileFlush(h);
  if(GetLastError()!=0) ok=false;
  FileClose(h);
  gIdentityLossPersistPending=!ok;
}

void MarkInfrastructureIdentityLoss()
{
  // If even the emergency identity registry is exhausted, restart cannot
  // prove that the forgotten evidence was resolved. Persist that obligation.
  gIdentityLossUnresolved=true;
    PersistInfrastructureIdentityLoss();
}

bool PersistEconomicMarker(ulong pid)
{
  string path=EconomicMarkerPath(pid);
  // Presence is an unresolved obligation, not proof of economic resolution.
  // Even an interrupted marker write must be rebuilt by its exact PID.
  if(FileIsExist(path)) return true;
  int h=FileOpen(path,FILE_WRITE|FILE_TXT|FILE_ANSI);
  if(h==INVALID_HANDLE) return false;
  ResetLastError();
  uint written=FileWriteString(h,"S1995_ECONOMIC_OBLIGATION\r\n");
  bool ok=(written==25 && GetLastError()==0);
  ResetLastError(); FileFlush(h);
  if(GetLastError()!=0) ok=false;
  FileClose(h);
  return ok;
}

void RestoreUnresolvedEconomicMarkers()
{
  // PID0 is a sentinel: a successful scan must find it. Thus enumeration
  // failure cannot masquerade as an empty registry and release the blocker.
  gEconomicMarkerScanUnresolved=false;
  if(!PersistEconomicMarker(0)) { gEconomicMarkerScanUnresolved=true; return; }
  string name, prefix=EconomicMarkerPrefix(), suffix=".econ.partial";
  long search=FileFindFirst(prefix+"*"+suffix,name);
  if(search==INVALID_HANDLE) { gEconomicMarkerScanUnresolved=true; return; }
  bool sentinel=false;
  ulong markerPIDs[]; int markerCount=0;
  bool more=true;
  while(more)
  {
     if(name==prefix+"0"+suffix) sentinel=true;
     else
     {
        int length=StringLen(name)-StringLen(prefix)-StringLen(suffix);
        ulong pid=0;
        if(length<=0 || StringSubstr(name,0,StringLen(prefix))!=prefix ||
           StringSubstr(name,StringLen(name)-StringLen(suffix))!=suffix ||
           !CsvParsePID(StringSubstr(name,StringLen(prefix),length),pid))
           gEconomicMarkerScanUnresolved=true;
        else if(ArrayResize(markerPIDs,markerCount+1)!=markerCount+1)
           gEconomicMarkerScanUnresolved=true;
        else markerPIDs[markerCount++]=pid;
     }
     ResetLastError();
     more=FileFindNext(search,name);
     // No guessed EOF error code: an explicit enumeration error cannot
     // certify a complete registry. Retry later rather than release it.
     if(!more && GetLastError()!=0) gEconomicMarkerScanUnresolved=true;
    }
    FileFindClose(search);
    if(!sentinel) gEconomicMarkerScanUnresolved=true;
    // Snapshot filenames before rebuild can remove an authoritatively resolved marker.
    for(int i=0;i<markerCount;i++)
    {
       ulong pid=markerPIDs[i];
       int idx=FindTrackedTrade(pid); bool existing=(idx>=0);
       if(idx<0) idx=NewTrackedTrade(pid);
       if(idx<0) { gEconomicMarkerScanUnresolved=true; continue; }
       if(!existing) LoadTradeMetadata(gTradeRecords[idx]);
       gTradeRecords[idx].economicMarkerPending=true;
       if(!RebuildTrackedHistory(idx,false))
       { gEconomicMarkerScanUnresolved=true; continue; }
       if(!gTradeRecords[idx].volumeClosedComplete)
       {
          gTradeRecords[idx].historyRefreshPending=true;
          MarkTemporaryAccountingHistory();
       }
       TryFinalizeTrackedTrade(pid);
    }
}

void SyncEconomicMarker(int idx)
{
   TradeRecord r=gTradeRecords[idx];
   // A prior administrative classification is invalidated by any fresh rebuild.
   if(r.economicMarkerCleanupPending) gTradeRecords[idx].economicMarkerPending=true;
   if(r.inoutCostsUnresolved || (r.totalVolumeIn>0 &&
      (!r.closed || !r.finalizationWritten)))
   {
      gTradeRecords[idx].economicMarkerCleanupPending=false;
      bool durableIdentity=PersistEconomicMarker(r.positionID);
      // Persisting an obligation is not proof that its finalization is durable.
      gTradeRecords[idx].economicMarkerPending=!durableIdentity ||
         r.inoutCostsUnresolved || (r.closed && !r.finalizationWritten);
   }
   else if(r.closed && r.finalizationWritten && r.accountingResolved &&
      r.volumeClosedComplete)
   {
      // Never remove the durable PID while its own reconstruction is uncertain.
      if(r.historyRefreshPending || r.breakEvenClassificationPending ||
         r.be.stage==BE_REQUEST_PENDING || r.be.stage==BE_ACKNOWLEDGED ||
         r.be.stage==BE_UNRESOLVED)
      {
         gTradeRecords[idx].economicMarkerPending=true;
         if(!PersistEconomicMarker(r.positionID)) gEconomicMarkerScanUnresolved=true;
         return;
      }
      string path=EconomicMarkerPath(r.positionID);
      ResetLastError(); bool present=FileIsExist(path);
      int probeError=GetLastError();
      if(!present && probeError!=0)
      {
         bool confirmed=false;
         if(EMRProbeMarker(r.positionID,confirmed))
         { present=confirmed; probeError=0; }
      }
      bool removed=false;
      int error=probeError;
      if(present)
      {
         ResetLastError(); removed=FileDelete(path);
         error=GetLastError();
      }
      if((present && !removed) || (!present && probeError!=0) ||
         (!present && r.economicMarkerCleanupPending))
      {
         gTradeRecords[idx].economicMarkerPending=true;
         gTradeRecords[idx].economicMarkerCleanupPending=true;
         gTradeRecords[idx].economicMarkerDeleteError=error;
         if(!r.economicMarkerCleanupPending || r.economicMarkerDeleteError!=error)
            PrintFormat("[SCALPER][ECONOMIC_MARKER_CLEANUP_FAILED] pid=%I64u file=%s error=%d; authoritative resolution proof required; evidence retained.",
               r.positionID,path,error);
      }
      else
      {
         gTradeRecords[idx].economicMarkerPending=false;
         gTradeRecords[idx].economicMarkerCleanupPending=false;
         gTradeRecords[idx].economicMarkerDeleteError=0;
      }
   }
}

void RecoverEconomicMarkers()
{
   if(gEconomicMarkerScanUnresolved) RestoreUnresolvedEconomicMarkers();
   for(int i=0;i<gTradeRecordCount;i++)
   {
      if(!gTradeRecords[i].economicMarkerPending &&
         !gTradeRecords[i].economicMarkerCleanupPending) continue;
      if(gTradeRecords[i].closed && gTradeRecords[i].finalizationWritten)
         EMRRecoverRecord(i);
      else SyncEconomicMarker(i);
   }
   EMRMaintainArchivedCleanup();
   EMRReleaseArchivedRecords();
}

// Economic-marker certification only; this does not authorize an order.
// Mixed/reversal/INOUT histories are deliberately outside this administrative
// exception. Their original economic and ownership protections remain active.
#define EMR_MAX_HISTORY_DEALS 4096
#define EMR_MAX_HISTORY_ORDERS 512
#define EMR_MAX_LIVE_ITEMS 4096

struct EMRDealSnapshot
{
   ulong ticket, order;
   long timeMSC, timeSec, magic, type, entry;
   double volume, price, profit, commission, fee, swap;
};
struct EMROrderSnapshot
{
   ulong ticket, pid, by;
   long state, type, magic, setupMSC, doneMSC;
   double initial, remaining, sl, tp, dealVolume, entryVolume, exitVolume;
};

bool EMRDealI(ulong ticket,ENUM_DEAL_PROPERTY_INTEGER property,long &value)
{
   ResetLastError();
   return HistoryDealGetInteger(ticket,property,value) && GetLastError()==0;
}
bool EMRDealD(ulong ticket,ENUM_DEAL_PROPERTY_DOUBLE property,double &value)
{
   ResetLastError();
   return HistoryDealGetDouble(ticket,property,value) && GetLastError()==0 &&
      MathIsValidNumber(value) && value!=EMPTY_VALUE;
}
bool EMRDealS(ulong ticket,ENUM_DEAL_PROPERTY_STRING property,string &value)
{
   ResetLastError();
   return HistoryDealGetString(ticket,property,value) && GetLastError()==0;
}
bool EMROrderI(ulong ticket,ENUM_ORDER_PROPERTY_INTEGER property,long &value)
{
   ResetLastError();
   return HistoryOrderGetInteger(ticket,property,value) && GetLastError()==0;
}
bool EMROrderD(ulong ticket,ENUM_ORDER_PROPERTY_DOUBLE property,double &value)
{
   ResetLastError();
   return HistoryOrderGetDouble(ticket,property,value) && GetLastError()==0 &&
      MathIsValidNumber(value) && value!=EMPTY_VALUE;
}
bool EMROrderS(ulong ticket,ENUM_ORDER_PROPERTY_STRING property,string &value)
{
   ResetLastError();
   return HistoryOrderGetString(ticket,property,value) && GetLastError()==0;
}
bool EMRFinite(double value)
{ return MathIsValidNumber(value) && value!=EMPTY_VALUE; }
bool EMRNear(double first,double second,double tolerance)
{
   return EMRFinite(first) && EMRFinite(second) &&
      MathAbs(first-second)<=MathMax(tolerance,
         MathMax(MathAbs(first),MathAbs(second))*1e-11);
}
string EMRD(double value) { return DoubleToString(value,16); }

bool EMRReadDeal(ulong ticket,ulong positionID,EMRDealSnapshot &d)
{
   string symbol; long pid, order;
   d.ticket=ticket;
   if(ticket==0 || !EMRDealS(ticket,DEAL_SYMBOL,symbol) || symbol!=Symbol() ||
      !EMRDealI(ticket,DEAL_POSITION_ID,pid) || (ulong)pid!=positionID ||
      !EMRDealI(ticket,DEAL_ORDER,order) || order<=0 ||
      !EMRDealI(ticket,DEAL_TIME_MSC,d.timeMSC) || d.timeMSC<=0 ||
      !EMRDealI(ticket,DEAL_TIME,d.timeSec) || d.timeSec<=0 ||
      d.timeMSC/1000!=d.timeSec ||
      !EMRDealI(ticket,DEAL_MAGIC,d.magic) ||
      !EMRDealI(ticket,DEAL_TYPE,d.type) ||
      (d.type!=DEAL_TYPE_BUY && d.type!=DEAL_TYPE_SELL) ||
      !EMRDealI(ticket,DEAL_ENTRY,d.entry) ||
      (d.entry!=DEAL_ENTRY_IN && d.entry!=DEAL_ENTRY_OUT &&
       d.entry!=DEAL_ENTRY_OUT_BY) ||
      !EMRDealD(ticket,DEAL_VOLUME,d.volume) || d.volume<=0 ||
      !EMRDealD(ticket,DEAL_PRICE,d.price) || d.price<=0 ||
      !EMRDealD(ticket,DEAL_PROFIT,d.profit) ||
      !EMRDealD(ticket,DEAL_COMMISSION,d.commission) ||
      !EMRDealD(ticket,DEAL_FEE,d.fee) ||
      !EMRDealD(ticket,DEAL_SWAP,d.swap)) return false;
   d.order=(ulong)order;
   return d.entry!=DEAL_ENTRY_IN || d.magic==(long)gMagicCore;
}

string EMRDealEvidence(const EMRDealSnapshot &d)
{
   return (string)d.ticket+"|"+(string)d.order+"|"+(string)d.timeMSC+"|"+
      (string)d.timeSec+"|"+(string)d.magic+"|"+(string)d.type+"|"+
      (string)d.entry+"|"+EMRD(d.volume)+"|"+EMRD(d.price)+"|"+
      EMRD(d.profit)+"|"+EMRD(d.commission)+"|"+EMRD(d.fee)+"|"+EMRD(d.swap);
}

bool EMRReadOrder(ulong ticket,ulong positionID,EMROrderSnapshot &o)
{
   string symbol; long pid, by;
   ZeroMemory(o); o.ticket=ticket;
   if(ticket==0 || !EMROrderS(ticket,ORDER_SYMBOL,symbol) || symbol!=Symbol() ||
      !EMROrderI(ticket,ORDER_POSITION_ID,pid) || pid<0 ||
      !EMROrderI(ticket,ORDER_POSITION_BY_ID,by) || by<0 ||
      ((ulong)pid!=positionID && (ulong)by!=positionID) ||
      !EMROrderI(ticket,ORDER_STATE,o.state) ||
      (o.state!=ORDER_STATE_FILLED && o.state!=ORDER_STATE_CANCELED &&
       o.state!=ORDER_STATE_REJECTED && o.state!=ORDER_STATE_EXPIRED) ||
      !EMROrderI(ticket,ORDER_TYPE,o.type) ||
      (o.type!=ORDER_TYPE_BUY && o.type!=ORDER_TYPE_SELL &&
       o.type!=ORDER_TYPE_CLOSE_BY) ||
      !EMROrderI(ticket,ORDER_MAGIC,o.magic) ||
      !EMROrderI(ticket,ORDER_TIME_SETUP_MSC,o.setupMSC) || o.setupMSC<=0 ||
      !EMROrderI(ticket,ORDER_TIME_DONE_MSC,o.doneMSC) || o.doneMSC<=0 ||
      o.doneMSC<o.setupMSC ||
      !EMROrderD(ticket,ORDER_VOLUME_INITIAL,o.initial) || o.initial<=0 ||
      !EMROrderD(ticket,ORDER_VOLUME_CURRENT,o.remaining) || o.remaining<0 ||
      !EMROrderD(ticket,ORDER_SL,o.sl) || o.sl<0 ||
      !EMROrderD(ticket,ORDER_TP,o.tp) || o.tp<0) return false;
   o.pid=(ulong)pid; o.by=(ulong)by;
   return true;
}

string EMROrderEvidence(const EMROrderSnapshot &o)
{
   return (string)o.ticket+"|"+(string)o.pid+"|"+(string)o.by+"|"+
      (string)o.state+"|"+(string)o.type+"|"+(string)o.magic+"|"+
      (string)o.setupMSC+"|"+(string)o.doneMSC+"|"+EMRD(o.initial)+"|"+
      EMRD(o.remaining)+"|"+EMRD(o.sl)+"|"+EMRD(o.tp);
}

bool EMRConnected()
{
   ResetLastError();
   long connected=TerminalInfoInteger(TERMINAL_CONNECTED);
   return connected!=0 && GetLastError()==0;
}

// All selections must succeed, including foreign items. Foreign Hedging
// positions/orders with another PID and Magic are independent and permitted.
bool EMRStrictLiveSnapshot(ulong positionID)
{
   ResetLastError(); int positions=PositionsTotal();
   if(GetLastError()!=0 || positions<0 || positions>EMR_MAX_LIVE_ITEMS) return false;
   ResetLastError(); int orders=OrdersTotal();
   if(GetLastError()!=0 || orders<0 || orders>EMR_MAX_LIVE_ITEMS) return false;
   ulong positionTickets[],orderTickets[];
   if(ArrayResize(positionTickets,positions)!=positions ||
      ArrayResize(orderTickets,orders)!=orders) return false;
   for(int i=0;i<positions;i++)
   {
      ResetLastError(); ulong ticket=PositionGetTicket(i);
      if(ticket==0 || GetLastError()!=0) return false;
      positionTickets[i]=ticket;
      string symbol; long pid,magic; double volume;
      ResetLastError();
      if(!PositionGetString(POSITION_SYMBOL,symbol) || GetLastError()!=0) return false;
      ResetLastError();
      if(!PositionGetInteger(POSITION_IDENTIFIER,pid) || GetLastError()!=0 || pid<=0)
         return false;
      ResetLastError();
      if(!PositionGetInteger(POSITION_MAGIC,magic) || GetLastError()!=0) return false;
      ResetLastError();
      if(!PositionGetDouble(POSITION_VOLUME,volume) || GetLastError()!=0 ||
         !EMRFinite(volume) || volume<=0) return false;
      if(symbol==Symbol() && (ulong)pid==positionID) return false;
   }
   for(int i=0;i<orders;i++)
   {
      ResetLastError(); ulong ticket=OrderGetTicket(i);
      if(ticket==0 || GetLastError()!=0) return false;
      orderTickets[i]=ticket;
      string symbol; long magic,pid,by;
      ResetLastError();
      if(!OrderGetString(ORDER_SYMBOL,symbol) || GetLastError()!=0) return false;
      ResetLastError();
      if(!OrderGetInteger(ORDER_MAGIC,magic) || GetLastError()!=0) return false;
      ResetLastError();
      if(!OrderGetInteger(ORDER_POSITION_ID,pid) || GetLastError()!=0 || pid<0)
         return false;
      ResetLastError();
      if(!OrderGetInteger(ORDER_POSITION_BY_ID,by) || GetLastError()!=0 || by<0)
         return false;
      if(symbol==Symbol() && (magic==(long)gMagicCore ||
         (ulong)pid==positionID || (ulong)by==positionID)) return false;
   }
   ResetLastError(); int positionsAfter=PositionsTotal();
   if(GetLastError()!=0 || positionsAfter!=positions) return false;
   ResetLastError(); int ordersAfter=OrdersTotal();
   if(GetLastError()!=0 || ordersAfter!=orders) return false;
   for(int i=0;i<positions;i++)
   {
      ResetLastError(); ulong ticket=PositionGetTicket(i);
      if(GetLastError()!=0 || ticket!=positionTickets[i]) return false;
   }
   for(int i=0;i<orders;i++)
   {
      ResetLastError(); ulong ticket=OrderGetTicket(i);
      if(GetLastError()!=0 || ticket!=orderTickets[i]) return false;
   }
   return true;
}

bool EMRStrictSnapshot(const TradeRecord &r,string &evidence)
{
   evidence="";
   if(r.positionID==0 || !EMRConnected()) return false;
   ResetLastError(); long account=AccountInfoInteger(ACCOUNT_LOGIN);
   if(GetLastError()!=0 || account<=0) return false;
   ResetLastError(); string server=AccountInfoString(ACCOUNT_SERVER);
   if(GetLastError()!=0 || server=="") return false;
   ResetLastError();
   if(!HistorySelectByPosition(r.positionID) || GetLastError()!=0) return false;
   ResetLastError(); int dealCount=HistoryDealsTotal();
   if(GetLastError()!=0 || dealCount<=0 || dealCount>EMR_MAX_HISTORY_DEALS)
      return false;
   ResetLastError(); int orderCount=HistoryOrdersTotal();
   if(GetLastError()!=0 || orderCount<=0 || orderCount>EMR_MAX_HISTORY_ORDERS)
      return false;
   EMRDealSnapshot deals[]; EMROrderSnapshot historyOrders[];
   ulong dealTickets[],historyOrderTickets[];
   if(ArrayResize(deals,dealCount)!=dealCount ||
      ArrayResize(historyOrders,orderCount)!=orderCount ||
      ArrayResize(dealTickets,dealCount)!=dealCount ||
      ArrayResize(historyOrderTickets,orderCount)!=orderCount) return false;
   for(int i=0;i<dealCount;i++)
   {
      ResetLastError(); ulong ticket=HistoryDealGetTicket(i);
      if(ticket==0 || GetLastError()!=0) return false;
      dealTickets[i]=ticket;
      if(!EMRReadDeal(ticket,r.positionID,deals[i])) return false;
   }
   for(int i=0;i<orderCount;i++)
   {
      ResetLastError(); ulong ticket=HistoryOrderGetTicket(i);
      if(ticket==0 || GetLastError()!=0) return false;
      historyOrderTickets[i]=ticket;
      if(!EMRReadOrder(ticket,r.positionID,historyOrders[i])) return false;
   }
   // Independent ordering makes the receipt deterministic across terminal restarts.
   for(int i=1;i<dealCount;i++)
   {
      EMRDealSnapshot value=deals[i]; int j=i-1;
      while(j>=0 && (deals[j].timeMSC>value.timeMSC ||
         (deals[j].timeMSC==value.timeMSC && deals[j].ticket>value.ticket)))
      { deals[j+1]=deals[j]; j--; }
      deals[j+1]=value;
   }
   for(int i=1;i<orderCount;i++)
   {
      EMROrderSnapshot value=historyOrders[i]; int j=i-1;
      while(j>=0 && historyOrders[j].ticket>value.ticket)
      { historyOrders[j+1]=historyOrders[j]; j--; }
      historyOrders[j+1]=value;
   }
   for(int i=1;i<dealCount;i++)
      if(deals[i-1].ticket==deals[i].ticket) return false;
   for(int i=1;i<orderCount;i++)
      if(historyOrders[i-1].ticket==historyOrders[i].ticket) return false;
   double tolerance=AccountingVolumeTolerance();
   if(!EMRFinite(tolerance) || tolerance<=0) return false;
   double volumeIn=0,volumeOut=0,entryMean=0,exitMean=0;
   double gross=0,commission=0,fee=0,swap=0;
   long firstEntryTime=0,lastExitTime=0,lastExitMSC=0;
   ulong firstEntryOrder=0,lastExitDeal=0;
   int direction=0;
   bool ownStarted=false,ownFinished=false;
   string dealDigest="EMR_DEALS_V1",orderDigest="EMR_ORDERS_V1";
   for(int i=0;i<dealCount;i++)
   {
      EMRDealSnapshot d=deals[i]; int index=-1;
      for(int j=0;j<orderCount;j++)
         if(historyOrders[j].ticket==d.order) { index=j; break; }
      if(index<0 || historyOrders[index].magic!=d.magic ||
         d.timeMSC<historyOrders[index].setupMSC ||
         d.timeMSC>historyOrders[index].doneMSC) return false;
      if((historyOrders[index].type==ORDER_TYPE_BUY && d.type!=DEAL_TYPE_BUY) ||
         (historyOrders[index].type==ORDER_TYPE_SELL && d.type!=DEAL_TYPE_SELL))
         return false;
      int dealDirection=(d.type==DEAL_TYPE_BUY?1:-1);
      historyOrders[index].dealVolume+=d.volume;
      if(d.entry==DEAL_ENTRY_IN)
      {
         if(ownFinished || historyOrders[index].type==ORDER_TYPE_CLOSE_BY ||
            historyOrders[index].magic!=(long)gMagicCore) return false;
         if(!ownStarted)
         {
            ownStarted=true; direction=dealDirection;
            firstEntryTime=d.timeSec; firstEntryOrder=d.order;
         }
         if(dealDirection!=direction) return false;
         entryMean=(entryMean*volumeIn+d.price*d.volume)/(volumeIn+d.volume);
         volumeIn+=d.volume;
         historyOrders[index].entryVolume+=d.volume;
      }
      else
      {
         if(!ownStarted || ownFinished || dealDirection==direction ||
            d.volume>volumeIn-volumeOut+tolerance) return false;
         exitMean=(exitMean*volumeOut+d.price*d.volume)/(volumeOut+d.volume);
         volumeOut+=d.volume;
         historyOrders[index].exitVolume+=d.volume;
         lastExitTime=d.timeSec; lastExitMSC=d.timeMSC; lastExitDeal=d.ticket;
         if(volumeIn-volumeOut<=tolerance) ownFinished=true;
      }
      gross+=d.profit; commission+=d.commission; fee+=d.fee; swap+=d.swap;
      if(!EMRFinite(volumeIn) || !EMRFinite(volumeOut) || !EMRFinite(entryMean) ||
         !EMRFinite(exitMean) || !EMRFinite(gross) || !EMRFinite(commission) ||
         !EMRFinite(fee) || !EMRFinite(swap)) return false;
      dealDigest=RJChecksum(dealDigest+"|"+EMRDealEvidence(d));
   }
   if(!ownStarted || !ownFinished || volumeIn<=tolerance ||
      !EMRNear(volumeIn,volumeOut,tolerance)) return false;
   bool entryOrderProven=false;
   for(int i=0;i<orderCount;i++)
   {
      EMROrderSnapshot o=historyOrders[i];
      double filled=o.initial-o.remaining;
      if(filled < -tolerance || !EMRNear(filled,o.dealVolume,tolerance) ||
         (o.state==ORDER_STATE_FILLED && o.remaining>tolerance) ||
         (o.entryVolume>tolerance && o.exitVolume>tolerance)) return false;
      if(o.entryVolume>tolerance &&
         (!EMRNear(o.sl,r.slPrice,1e-8) || !EMRNear(o.tp,r.tpPrice,1e-8)))
         return false;
      if(o.ticket==firstEntryOrder && o.ticket==r.entryOrderTicket)
      {
         if(r.expectedEntryVolume<=0 ||
            (!EMRNear(r.expectedEntryVolume,o.initial,tolerance) &&
             !EMRNear(r.expectedEntryVolume,filled,tolerance))) return false;
         entryOrderProven=true;
      }
      orderDigest=RJChecksum(orderDigest+"|"+EMROrderEvidence(o));
   }
   double net=gross+commission+fee+swap;
   if(!entryOrderProven || direction!=r.direction ||
      firstEntryTime!=(long)r.entryTime || lastExitTime!=(long)r.exitTime ||
      lastExitMSC!=r.exitTimeMSC || lastExitDeal!=r.lastExitDealTicket ||
      !EMRNear(volumeIn,r.totalVolumeIn,tolerance) ||
      !EMRNear(volumeOut,r.totalVolumeOut,tolerance) ||
      !EMRNear(volumeIn,r.volume,tolerance) ||
      !EMRNear(entryMean,r.weightedEntryPrice,1e-8) ||
      !EMRNear(exitMean,r.weightedExitPrice,1e-8) ||
      !EMRNear(entryMean,r.entryPrice,1e-8) ||
      !EMRNear(exitMean,r.exitPrice,1e-8) ||
      !EMRNear(gross,r.grossProfit,1e-8) ||
      !EMRNear(commission,r.commission,1e-8) ||
      !EMRNear(fee,r.fee,1e-8) || !EMRNear(swap,r.swap,1e-8) ||
      !EMRNear(net,r.netProfit,1e-8)) return false;
   if(r.riskValid)
   {
      if(!r.initialStopsProven || r.slPrice<=0 || r.initialRiskMoney<=0 ||
         (double)direction*(entryMean-r.slPrice)<=0) return false;
      double initialProfit=0;
      ResetLastError();
      if(!OrderCalcProfit(direction==1?ORDER_TYPE_BUY:ORDER_TYPE_SELL,Symbol(),
         volumeIn,entryMean,r.slPrice,initialProfit) || GetLastError()!=0 ||
         !EMRFinite(initialProfit) || initialProfit>=0 ||
         !EMRNear(-initialProfit,r.initialRiskMoney,1e-8)) return false;
      if(!r.pnlRValid || !EMRNear(net/r.initialRiskMoney,r.PnL_R,1e-8)) return false;
   }
   else if(r.pnlRValid || r.initialRiskMoney!=0) return false;
   // The selected history must remain identical across a second fresh selection.
   // No HistoryOrderSelect/HistoryDealSelect is used: those truncate selection lists.
   ResetLastError();
   if(!HistorySelectByPosition(r.positionID) || GetLastError()!=0) return false;
   ResetLastError(); int dealsAfter=HistoryDealsTotal();
   if(GetLastError()!=0 || dealsAfter!=dealCount) return false;
   ResetLastError(); int historyOrdersAfter=HistoryOrdersTotal();
   if(GetLastError()!=0 || historyOrdersAfter!=orderCount) return false;
   for(int i=0;i<dealCount;i++)
   {
      ResetLastError(); ulong ticket=HistoryDealGetTicket(i);
      if(GetLastError()!=0 || ticket!=dealTickets[i]) return false;
   }
   for(int i=0;i<orderCount;i++)
   {
      ResetLastError(); ulong ticket=HistoryOrderGetTicket(i);
      if(GetLastError()!=0 || ticket!=historyOrderTickets[i]) return false;
   }
   for(int i=0;i<dealCount;i++)
   {
      EMRDealSnapshot again;
      if(!EMRReadDeal(deals[i].ticket,r.positionID,again) ||
         EMRDealEvidence(again)!=EMRDealEvidence(deals[i])) return false;
   }
   for(int i=0;i<orderCount;i++)
   {
      EMROrderSnapshot again;
      if(!EMRReadOrder(historyOrders[i].ticket,r.positionID,again) ||
         EMROrderEvidence(again)!=EMROrderEvidence(historyOrders[i])) return false;
   }
   if(!EMRStrictLiveSnapshot(r.positionID) || !EMRConnected()) return false;
   ResetLastError(); long accountAfter=AccountInfoInteger(ACCOUNT_LOGIN);
   if(GetLastError()!=0 || accountAfter!=account) return false;
   ResetLastError(); string serverAfter=AccountInfoString(ACCOUNT_SERVER);
   if(GetLastError()!=0 || serverAfter!=server) return false;
   evidence="EMR_STRICT_SNAPSHOT_V1|"+(string)account+"|"+RJEncode(server)+"|"+
      RJEncode(Symbol())+"|"+(string)(ulong)gMagicCore+"|"+(string)r.positionID+"|"+
      (string)direction+"|"+(string)firstEntryOrder+"|"+(string)firstEntryTime+"|"+
      (string)lastExitTime+"|"+(string)lastExitMSC+"|"+(string)lastExitDeal+"|"+
      EMRD(volumeIn)+"|"+EMRD(volumeOut)+"|"+EMRD(entryMean)+"|"+EMRD(exitMean)+"|"+
      EMRD(gross)+"|"+EMRD(commission)+"|"+EMRD(fee)+"|"+EMRD(swap)+"|"+EMRD(net)+"|"+
      EMRD(r.slPrice)+"|"+EMRD(r.tpPrice)+"|"+EMRD(r.expectedEntryVolume)+"|"+
      (string)(int)r.riskValid+"|"+EMRD(r.initialRiskMoney)+"|"+
      (string)(int)r.pnlRValid+"|"+(r.pnlRValid?EMRD(r.PnL_R):"NA")+"|"+
      (string)(int)r.breakEvenExit+"|"+(string)(int)r.breakEvenClassificationPending+"|"+
      (string)r.be.stage+"|"+(string)(int)r.be.durable+"|"+
      (string)r.be.confirmedMSC+"|"+EMRD(r.be.price)+"|"+
      (string)dealCount+"|"+(string)orderCount+"|"+dealDigest+"|"+orderDigest;
   return true;
}

// EMR storage only. A receipt never replaces fresh authoritative economic proof.
string EMRResolutionPath(ulong pid)
{ return EconomicMarkerPrefix()+(string)pid+".econ.resolved"; }

bool EMRHasSuffix(string value,string suffix)
{
   int offset=StringLen(value)-StringLen(suffix);
   return offset>=0 && StringSubstr(value,offset)==suffix;
}

bool EMRNamePID(string tail,string suffix,ulong &pid)
{
   pid=0;
   int count=StringLen(tail)-StringLen(suffix);
   if(count<=0 || !EMRHasSuffix(tail,suffix)) return false;
   string digits=StringSubstr(tail,0,count);
   return CsvParsePID(digits,pid) && digits==(string)pid;
}

// FileIsExist(false) with an error is not proof of absence. Confirm the exact
// namespace through a complete enumeration containing the positive sentinel.
bool EMRProbeMarker(ulong pid,bool &present)
{
   present=false;
   if(pid==0 || !PersistEconomicMarker(0)) return false;
   string prefix=EconomicMarkerPrefix(),suffix=".econ.partial",name;
   ResetLastError(); long search=FileFindFirst(prefix+"*"+suffix,name);
   if(search==INVALID_HANDLE || GetLastError()!=0)
   {
      if(search!=INVALID_HANDLE) FileFindClose(search);
      return false;
   }
   bool more=true,sentinel=false,ok=true;
   int visited=0;
   while(more)
   {
      if(++visited>100000) { ok=false; break; }
      if(name==EconomicMarkerPath(0)) sentinel=true;
      else
      {
         ulong found=0;
         if(StringSubstr(name,0,StringLen(prefix))!=prefix ||
            !EMRNamePID(StringSubstr(name,StringLen(prefix)),suffix,found))
         { ok=false; break; }
         if(found==pid) present=true;
      }
      ResetLastError(); more=FileFindNext(search,name);
      if(!more && GetLastError()!=0) ok=false;
   }
   ResetLastError(); FileFindClose(search);
   if(GetLastError()!=0) ok=false;
   return ok && sentinel && !more;
}

bool EMRInspectFiles(ulong pid,bool &markerPresent,bool &receiptPresent,bool &bePresent)
{
   markerPresent=false; receiptPresent=false; bePresent=false;
   if(pid==0 || !PersistEconomicMarker(0)) return false;
   string prefix=EconomicMarkerPrefix(),name;
   ResetLastError();
   long search=FileFindFirst(prefix+"*",name);
   if(search==INVALID_HANDLE || GetLastError()!=0)
   {
      if(search!=INVALID_HANDLE) FileFindClose(search);
      return false;
   }
   bool sentinel=false,ok=true,more=true;
   int visited=0;
   while(more)
   {
      if(++visited>100000 || StringSubstr(name,0,StringLen(prefix))!=prefix)
      { ok=false; break; }
      string tail=StringSubstr(name,StringLen(prefix));
      ulong foundPID=0;
      if(name==EconomicMarkerPath(0)) sentinel=true;
      else if(tail=="identity.loss" || tail=="request.entry.intent" ||
              tail=="request.exit.intent")
      { ok=false; break; }
      else if(tail=="0.order.unresolved") { /* Existing registry sentinel only. */ }
      else if(EMRNamePID(tail,".order.unresolved",foundPID))
      { ok=false; break; } // Includes other PIDs: request/order cleanup is unchanged.
      else if(EMRNamePID(tail,".econ.partial",foundPID))
      { if(foundPID==pid) markerPresent=true; }
      else if(EMRNamePID(tail,".econ.resolved",foundPID))
      { if(foundPID==pid) receiptPresent=true; }
      else if(EMRNamePID(tail,".meta.csv.be.journal",foundPID))
      { if(foundPID==pid) bePresent=true; }
      else if(!EMRNamePID(tail,".meta.csv",foundPID))
      { ok=false; break; } // Malformed/truncated same-identity evidence is ambiguous.
      ResetLastError();
      more=FileFindNext(search,name);
      if(!more && GetLastError()!=0) ok=false;
   }
   ResetLastError(); FileFindClose(search);
   if(GetLastError()!=0) ok=false;
   return ok && sentinel && !more;
}

bool EMRPayloadBytes(string payload,uchar &bytes[])
{
   int length=StringLen(payload);
   if(length<=0 || length>16384) return false;
   for(int i=0;i<length;i++)
   {
      ushort c=StringGetCharacter(payload,i);
      if(c>126 || (c<32 && c!=13 && c!=10)) return false;
   }
   int encoded=StringToCharArray(payload,bytes,0,WHOLE_ARRAY,CP_UTF8);
   if(encoded!=length+1 || ArraySize(bytes)!=encoded || bytes[encoded-1]!=0)
      return false;
   return ArrayResize(bytes,encoded-1)==length;
}

bool EMRReadExact(string path,string payload)
{
   uchar expected[];
   if(!EMRPayloadBytes(payload,expected)) return false;
   ResetLastError();
   int h=FileOpen(path,FILE_READ|FILE_BIN);
   if(h==INVALID_HANDLE) return false;
   bool ok=(GetLastError()==0);
   ResetLastError(); ulong size=FileSize(h);
   if(GetLastError()!=0 || size==0 || size>16384 || size!=(ulong)ArraySize(expected))
      ok=false;
   uchar actual[];
   int count=ArraySize(expected);
   if(ok && ArrayResize(actual,count)!=count) ok=false;
   if(ok)
   {
      ResetLastError(); uint got=FileReadArray(h,actual,0,count);
      if(got!=(uint)count || GetLastError()!=0) ok=false;
   }
   if(ok)
      for(int i=0;i<count;i++)
         if(actual[i]!=expected[i]) { ok=false; break; }
   ResetLastError(); ulong finalSize=FileSize(h);
   if(GetLastError()!=0 || finalSize!=size) ok=false;
   ResetLastError(); FileClose(h);
   if(GetLastError()!=0) ok=false;
   return ok;
}

bool EMRConfirmExisting(string path,string payload)
{
   if(!EMRReadExact(path,payload)) return false;
   ResetLastError();
   int h=FileOpen(path,FILE_READ|FILE_WRITE|FILE_BIN);
   if(h==INVALID_HANDLE) return false;
   bool ok=(GetLastError()==0);
   ResetLastError(); FileFlush(h);
   if(GetLastError()!=0) ok=false;
   ResetLastError(); FileClose(h);
   if(GetLastError()!=0) ok=false;
   return ok && EMRReadExact(path,payload);
}

bool EMRCommitResolution(ulong pid,string evidence)
{
   if(pid==0 || StringLen(evidence)==0 || StringLen(evidence)>16300) return false;
   // Canonical evidence is printable ASCII; symbol/route text must be RJEncode'd.
   for(int i=0;i<StringLen(evidence);i++)
   {
      ushort c=StringGetCharacter(evidence,i);
      if(c<32 || c>126) return false;
   }
   string prefix="SCALPER_EMR1|"+evidence;
   string payload=prefix+"|"+(string)BEChecksum(prefix)+"|COMPLETE_EMR1\r\n";
   uchar expected[];
   if(!EMRPayloadBytes(payload,expected)) return false;
   bool markerPresent=false,receiptPresent=false,bePresent=false;
   if(!EMRInspectFiles(pid,markerPresent,receiptPresent,bePresent)) return false;
   string path=EMRResolutionPath(pid);
   // Existing invalid, partial or different evidence is never overwritten.
   if(receiptPresent) return EMRConfirmExisting(path,payload);
   // READ|WRITE preserves an existing file if another writer appeared after
   // enumeration. Never use WRITE-only truncation or delete/rename evidence.
   ResetLastError();
   int h=FileOpen(path,FILE_READ|FILE_WRITE|FILE_BIN);
   if(h==INVALID_HANDLE) return false;
   bool ok=(GetLastError()==0);
   ResetLastError(); ulong size=FileSize(h);
   if(GetLastError()!=0) ok=false;
   if(ok && size>0)
   {
      ResetLastError(); FileClose(h);
      if(GetLastError()!=0) return false;
      return EMRConfirmExisting(path,payload);
   }
   if(ok)
   {
      ResetLastError(); uint written=FileWriteArray(h,expected,0,ArraySize(expected));
      if(written!=(uint)ArraySize(expected) || GetLastError()!=0) ok=false;
      ResetLastError(); FileFlush(h);
      if(GetLastError()!=0) ok=false;
      ResetLastError(); ulong writtenSize=FileSize(h);
      if(GetLastError()!=0 || writtenSize!=(ulong)ArraySize(expected)) ok=false;
   }
   ResetLastError(); FileClose(h);
   if(GetLastError()!=0) ok=false;
   return ok && EMRReadExact(path,payload);
}

// Only failed economic-marker cleanup uses this proof. No strategy gate is added.
bool EMRReady(const TradeRecord &r)
{
   if(r.positionID==0 || !r.closed || !r.finalizationWritten || !r.accountingResolved ||
      !r.volumeClosedComplete || !r.volumeOwnershipResolved || r.historyRefreshPending ||
      r.inoutCostsUnresolved || r.residualForeignDetected || r.breakEvenClassificationPending ||
      !r.riskValid || !r.pnlRValid || !r.initialStopsProven ||
      r.be.stage==BE_REQUEST_PENDING || r.be.stage==BE_ACKNOWLEDGED ||
      r.be.stage==BE_UNRESOLVED) return false;
   if(r.exitTime>=AccountingDayStart() && !r.dailyApplied) return false;
   if(gPendingExec.active || gPendingExit.active || gPendingOrderClassificationUnresolved ||
      !gQuotaHistoryValid || gLiveOwnershipUnresolved || gAccountingCapacityUnresolved ||
      gMultipleOwnOrdersActive || gOrderRegistryUnavailable || gOrderObligationScanUnresolved ||
      !gDailyEconomicsValid || !gDailyPnLRValid || gDailyHistoryRetryRequired ||
      gEconomicMarkerScanUnresolved || gIdentityLossUnresolved || gIdentityLossPersistPending ||
      gRequestJournalUnresolved || gRequestJournalWritePending ||
      gEntryJournalCleanupPending || gExitJournalCleanupPending ||
      gEntryJournalInvalid || gExitJournalInvalid || gEntryJournalWritePending ||
      gExitJournalWritePending || gDeferredRegistryUnavailable ||
      ArraySize(gDeferredAccountingPIDs)>0 || ArraySize(gDeferredDeals)>0 ||
      gDeferredDealFallbackCount>0 || gDeferredDealOverflow) return false;
   for(int i=0;i<ArraySize(gUnresolvedOrders);i++)
      if(gUnresolvedOrders[i].active) return false;
   return true;
}

bool EMRBreakEvenEvidence(const TradeRecord &r,bool journalPresent)
{
   if(!journalPresent) return r.be.stage==BE_NONE && !r.breakEvenExit;
   if(r.be.stage!=BE_TRIGGERED && r.be.stage!=BE_CONFIRMED) return false;
   // Bound both bytes and iterations. A failed read can never become EOF.
   ResetLastError();
   int h=FileOpen(BEJournalPath(r.positionID),FILE_READ|FILE_BIN|FILE_SHARE_READ);
   if(h==INVALID_HANDLE) return false;
   ResetLastError(); ulong size=FileSize(h);
   bool ok=(GetLastError()==0 && size>0 && size<=1048576);
   uchar bytes[4096];
   ulong offset=0;
   string row="";
   bool cr=false,found=false;
   BreakEvenState verified = {};
   while(ok && offset<size)
   {
      int want=(size-offset>4096)?4096:(int)(size-offset);
      ResetLastError(); uint got=FileReadArray(h,bytes,0,want);
      if(got!=(uint)want || GetLastError()!=0) { ok=false; break; }
      offset+=got;
      for(int i=0;i<want;i++)
      {
         uchar b=bytes[i];
         if(b==10 && cr)
         {
            if(row!="")
            {
               BreakEvenState candidate;
               if(!BEParseRow(row,r.positionID,candidate) ||
                  (found && !ProtectionStateFollows(verified,candidate))) { ok=false; break; }
               verified=candidate; found=true;
            }
            row=""; cr=false; continue;
         }
         if(cr) { ok=false; break; }
         if(b==13) { cr=true; continue; }
         if(b<32 || b>126 || StringLen(row)>=32768) { ok=false; break; }
         row+=ShortToString((ushort)b);
      }
   }
   if(row!="" || cr || !found) ok=false;
   ResetLastError(); ulong finalSize=FileSize(h);
   if(GetLastError()!=0 || finalSize!=size) ok=false;
   ResetLastError(); FileClose(h);
   if(GetLastError()!=0 || !ok) return false;
   return r.be.durable && verified.durable &&
      BEJournalRow(r.positionID,verified)==BEJournalRow(r.positionID,r.be);
}

void EMRRecoverRecord(int idx)
{
   bool wasAdministrative=(gTradeRecords[idx].economicMarkerCleanupPending &&
                            !gTradeRecords[idx].economicMarkerPending);
   gTradeRecords[idx].economicMarkerPending=true;
   if(!RebuildTrackedHistory(idx,false)) return;
   // Rebuild calls SyncEconomicMarker. Successful physical cleanup keeps the
   // original behavior; only a residual/error needs the additional proof.
   if(!gTradeRecords[idx].economicMarkerPending) return;
   TradeRecord r=gTradeRecords[idx];
   bool markerPresent=false,receiptPresent=false,bePresent=false;
   if(!EMRReady(r) || !EMRInspectFiles(r.positionID,markerPresent,receiptPresent,bePresent) ||
      !EMRBreakEvenEvidence(r,bePresent)) return;
   string evidence="";
   if(!EMRStrictSnapshot(r,evidence)) return;
   if(r.be.stage!=BE_NONE) evidence+="|BE_JOURNAL|"+BEJournalRow(r.positionID,r.be);
   if(!EMRCommitResolution(r.positionID,evidence)) return;
   // Recheck authoritative data after persistence, before publishing RAM state.
   // The receipt is a durable finalization record, never a substitute for history.
   string verified="";
   if(!EMRReady(gTradeRecords[idx]) || !EMRStrictSnapshot(gTradeRecords[idx],verified)) return;
   if(gTradeRecords[idx].be.stage!=BE_NONE)
      verified+="|BE_JOURNAL|"+BEJournalRow(r.positionID,gTradeRecords[idx].be);
   if(verified!=evidence ||
      !EMRInspectFiles(r.positionID,markerPresent,receiptPresent,bePresent) ||
      !receiptPresent || !EMRBreakEvenEvidence(gTradeRecords[idx],bePresent)) return;
   gTradeRecords[idx].economicMarkerPending=false;
   gTradeRecords[idx].economicMarkerCleanupPending=markerPresent;
   if(!wasAdministrative)
      PrintFormat("[SCALPER][ECONOMIC_RESOLUTION_VERIFIED] pid=%I64u cleanup_only=%d; exact history, orders, positions and durable receipt revalidated.",
         r.positionID,(int)markerPresent);
}

// A constant-size cursor replaces retention of old resolved PIDs in RAM.
// One archived PID at most is rebuilt per existing ten-second recovery pass.
void EMRMaintainArchivedCleanup()
{
   if(!gEMRMaintenanceNeeded) return;
   string prefix=EconomicMarkerPrefix(),suffix=".econ.partial",name,chosen="",first="";
   ResetLastError(); long search=FileFindFirst(prefix+"*"+suffix,name);
   if(search==INVALID_HANDLE || GetLastError()!=0)
   {
      if(search!=INVALID_HANDLE) FileFindClose(search);
      gEconomicMarkerScanUnresolved=true; return;
   }
   bool more=true,sentinel=false,ok=true;
   int visited=0;
   while(more)
   {
      if(++visited>100000) { ok=false; break; }
      if(name==EconomicMarkerPath(0)) sentinel=true;
      else
      {
         ulong pid=0;
         if(StringSubstr(name,0,StringLen(prefix))!=prefix ||
            !EMRNamePID(StringSubstr(name,StringLen(prefix)),suffix,pid))
         { ok=false; break; }
         if(FindTrackedTrade(pid)<0)
         {
            if(first=="" || StringCompare(name,first)<0) first=name;
            if(StringCompare(name,gEMRMaintenanceCursor)>0 &&
               (chosen=="" || StringCompare(name,chosen)<0)) chosen=name;
         }
      }
      ResetLastError(); more=FileFindNext(search,name);
      if(!more && GetLastError()!=0) ok=false;
   }
   ResetLastError(); FileFindClose(search);
   if(GetLastError()!=0 || !ok || !sentinel || more)
   { gEconomicMarkerScanUnresolved=true; return; }
   if(first=="")
   { gEMRMaintenanceNeeded=false; gEMRMaintenanceCursor=""; return; }
   if(chosen=="") chosen=first;
   gEMRMaintenanceCursor=chosen;
   ulong pid=0;
   if(!EMRNamePID(StringSubstr(chosen,StringLen(prefix)),suffix,pid))
   { gEconomicMarkerScanUnresolved=true; return; }
   int idx=NewTrackedTrade(pid);
   if(idx<0) { gEconomicMarkerScanUnresolved=true; return; }
   LoadTradeMetadata(gTradeRecords[idx]);
   gTradeRecords[idx].economicMarkerPending=true;
   if(!RebuildTrackedHistory(idx,false)) return;
   TryFinalizeTrackedTrade(pid);
   if(gTradeRecords[idx].closed && gTradeRecords[idx].finalizationWritten &&
      gTradeRecords[idx].economicMarkerPending) EMRRecoverRecord(idx);
   // This slot was allocated solely for one archived maintenance revisit.
   // Successful eventual deletion must not retain an old, dailyApplied=false PID.
   EMRReleaseArchivedRecord(idx);
}

bool EMRReleaseArchivedRecord(int idx)
{
   if(idx<0 || idx>=gTradeRecordCount) return false;
   TradeRecord r=gTradeRecords[idx];
   if(!r.closed || !r.finalizationWritten || !r.accountingResolved ||
      !r.volumeClosedComplete || !r.volumeOwnershipResolved ||
      r.economicMarkerPending || r.historyRefreshPending || r.inoutCostsUnresolved ||
      r.residualForeignDetected || r.breakEvenClassificationPending ||
      r.be.stage==BE_REQUEST_PENDING || r.be.stage==BE_ACKNOWLEDGED ||
      r.be.stage==BE_UNRESOLVED || r.exitTime>=AccountingDayStart()) return false;
   // No financial aggregate is modified. Exact residual evidence stays on disk.
   int tail=gTradeRecordCount-1;
   TradeRecord moved=gTradeRecords[tail];
   if(gOpenPos.active && gOpenPos.tradeRecordIdx==idx) return false;
   if(ArrayResize(gTradeRecords,tail)!=tail) return false;
   if(idx<tail) gTradeRecords[idx]=moved;
   if(gOpenPos.active && gOpenPos.tradeRecordIdx==tail) gOpenPos.tradeRecordIdx=idx;
   gTradeRecordCount=tail;
   if(r.economicMarkerCleanupPending) gEMRMaintenanceNeeded=true;
   return true;
}

void EMRReleaseArchivedRecords()
{
   for(int i=gTradeRecordCount-1;i>=0;i--)
      if(gTradeRecords[i].economicMarkerCleanupPending) EMRReleaseArchivedRecord(i);
}

void EMRInvalidateTransaction(const MqlTradeTransaction &trans)
{
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD &&
      trans.type!=TRADE_TRANSACTION_DEAL_UPDATE &&
      trans.type!=TRADE_TRANSACTION_DEAL_DELETE) return;
   if(trans.symbol!="" && trans.symbol!=Symbol()) return;
   ulong pid=0; long magic=0; bool identified=false;
   if(trans.type!=TRADE_TRANSACTION_DEAL_DELETE && trans.deal>0)
   {
      ResetLastError();
      long id=HistoryDealGetInteger(trans.deal,DEAL_POSITION_ID);
      magic=HistoryDealGetInteger(trans.deal,DEAL_MAGIC);
      string symbol=HistoryDealGetString(trans.deal,DEAL_SYMBOL);
      identified=(GetLastError()==0 && id>0 && symbol==Symbol());
      if(identified) pid=(ulong)id;
   }
   bool matched=false;
   for(int i=0;i<gTradeRecordCount;i++)
   {
      if(!gTradeRecords[i].economicMarkerCleanupPending ||
         (identified && gTradeRecords[i].positionID!=pid)) continue;
      gTradeRecords[i].economicMarkerPending=true;
      gTradeRecords[i].historyRefreshPending=true;
      matched=true;
   }
   if(matched)
   {
      // A changed closed cycle requires a fresh daily reconstruction too.
      // Never increment the financial result here.
      MarkTemporaryAccountingHistory();
   }
   if(gEMRMaintenanceNeeded && (!identified ||
      (!matched && (trans.type!=TRADE_TRANSACTION_DEAL_ADD ||
                    (magic==(long)gMagicCore && !gPendingExec.active)))))
      gEconomicMarkerScanUnresolved=true;
}


// Durable request obligations, RC1.2.
void RecomputeRequestJournalFlags()
{
   gRequestJournalUnresolved=gEntryJournalInvalid || gExitJournalInvalid;
   gRequestJournalWritePending=gEntryJournalWritePending || gExitJournalWritePending;
}

string RequestJournalPath(bool exitRequest)
{ return EconomicMarkerPrefix()+(exitRequest?"request.exit.intent":"request.entry.intent"); }

bool RJUnsigned(string text,ulong &value)
{
  if(text=="0") { value=0; return true; }
  return CsvParsePID(text,value); // Exact ulong; rejects overflow and non-digits.
}

bool RJBoolean(string text,bool &value)
{
  if(text!="0" && text!="1") return false;
  value=(text=="1"); return true;
}

bool RJDouble(string text,double &value)
{
  bool digit=false,point=false;
  for(int i=0;i<StringLen(text);i++)
  {
     ushort c=StringGetCharacter(text,i);
     if(c>=48 && c<=57) digit=true;
     else if(c==46 && !point) point=true;
     else return false;
  }
  if(!digit) return false;
  value=StringToDouble(text);
  return MathIsValidNumber(value) && value>=0;
}

string RJEncode(string value)
{
  string out="";
  for(int i=0;i<StringLen(value);i++)
    out+=StringFormat("%04X",(uint)StringGetCharacter(value,i));
  return out;
}
bool RJDecode(string text,string &value)
{
    value="";
    if(StringLen(text)%4!=0 || StringLen(text)>8192) return false;
    for(int i=0;i<StringLen(text);i+=4)
    {
       uint code=0;
       for(int j=0;j<4;j++)
       {
          ushort c=StringGetCharacter(text,i+j); uint digit=0;
          if(c>=48 && c<=57) digit=(uint)(c-48);
          else if(c>=65 && c<=70) digit=(uint)(c-55);
          else return false;
          code=code*16+digit;
       }
       if(code==0) return false;
       value+=ShortToString((ushort)code);
    }
    return true;
}

bool RJRoute(string route,string mode)
{
  return (route=="ABS" && (mode=="BASE" || mode=="TURBO")) ||
   (route=="CONT" && (mode=="BASE_CONT" || mode=="TURBO_CONT")) ||
   (route=="UNAVAILABLE" && mode=="UNAVAILABLE");
}

string RJChecksum(string text)
{
  // ASCII journal fields only. Integrity check, not authentication.
  uint hash=2166136261;
  for(int i=0;i<StringLen(text);i++)
     hash=(hash^(uint)StringGetCharacter(text,i))*(uint)16777619;
  return StringFormat("%08X",hash);
}

bool RJParse(string row,bool exitRequest,bool &resolved,
          PendingExecContext &entry,PendingExitIntent &exitIntent)
{
  string f[];
  int fields=StringSplit(row,'|',f);
  bool legacy=(fields==38 && f[0]=="S1995_REQUEST_JOURNAL_V1");
  bool current=(fields==40 && f[0]=="S1995_REQUEST_JOURNAL_V2");
  if((!legacy && !current) ||
     f[37]!="COMPLETE" || f[4]!=(exitRequest?"EXIT":"ENTRY") ||
     (f[5]!="ACTIVE" && f[5]!="RESOLVED")) return false;
  ENUM_REQUEST_DISPATCH_PHASE phase=REQUEST_MAY_HAVE_DISPATCHED;
  if(current)
  {
 if(f[38]!="0" && f[38]!="1") return false;
 string checked=f[0];
 for(int i=1;i<39;i++) checked+="|"+f[i];
 if(f[39]!=RJChecksum(checked)) return false;
 phase=(f[38]=="1"?REQUEST_PREPARED:REQUEST_MAY_HAVE_DISPATCHED);
}
ulong account,magic;
string symbol;
if(!RJUnsigned(f[1],account) || account!=(ulong)AccountInfoInteger(ACCOUNT_LOGIN) ||
   !RJDecode(f[2],symbol) || symbol!=Symbol() ||
   !RJUnsigned(f[3],magic) || magic!=(ulong)gMagicCore) return false;
resolved=(f[5]=="RESOLVED");
ZeroMemory(entry); ZeroMemory(exitIntent);
entry.dispatchPhase=phase; exitIntent.dispatchPhase=phase;
bool active;
if(!RJBoolean(f[6],active) || (!resolved && !active)) return false;
entry.active=active; exitIntent.active=active;
if(f[7]!="-1" && f[7]!="0" && f[7]!="1") return false;
entry.direction=(int)StringToInteger(f[7]);
if(!RJDecode(f[8],entry.route) || !RJDecode(f[9],entry.mode) ||
   !RJRoute(entry.route,entry.mode) ||
   !RJDouble(f[10],entry.requestPrice) || !RJDouble(f[11],entry.requestedLots) ||
   !RJDouble(f[12],entry.slPrice) || !RJDouble(f[13],entry.tpPrice)) return false;
ulong sentAt,order,deal,requestID,pid,ticket,action,type,position,byPosition,requestMagic;
if(!RJUnsigned(f[14],sentAt) || (long)sentAt<0 ||
   !RJUnsigned(f[15],order) || !RJUnsigned(f[16],deal) ||
   !RJUnsigned(f[17],requestID) || requestID>(ulong)4294967295 ||
   !RJBoolean(f[18],entry.accepted) || !RJBoolean(f[19],entry.requestPriceAvailable) ||
   !RJDouble(f[20],entry.breakoutPrice) || !RJBoolean(f[21],entry.breakoutPriceAvailable) ||
   !RJUnsigned(f[22],pid) || !RJUnsigned(f[23],ticket) ||
   !RJDecode(f[24],exitIntent.reason) || !RJBoolean(f[25],exitIntent.uncertain) ||
   !RJUnsigned(f[26],action) || action>100 ||
   !RJUnsigned(f[27],type) || type>100 ||
   !RJDouble(f[28],exitIntent.requestSnapshot.volume) ||
   !RJDouble(f[29],exitIntent.requestSnapshot.price) ||
   !RJDouble(f[30],exitIntent.requestSnapshot.sl) ||
   !RJDouble(f[31],exitIntent.requestSnapshot.tp) ||
   !RJUnsigned(f[32],position) || !RJUnsigned(f[33],byPosition) ||
   !RJUnsigned(f[34],requestMagic) ||
   !RJDecode(f[35],exitIntent.requestSnapshot.symbol) ||
   !RJDecode(f[36],exitIntent.requestSnapshot.comment)) return false;
entry.sentAt=(datetime)sentAt; entry.orderTicket=order; entry.resultDeal=deal;
entry.requestID=(uint)requestID;
exitIntent.sentAt=entry.sentAt; exitIntent.orderTicket=order;
exitIntent.resultDeal=deal; exitIntent.requestID=entry.requestID;
exitIntent.accepted=entry.accepted; exitIntent.positionID=pid;
exitIntent.positionTicket=ticket;
exitIntent.requestSnapshot.action=(ENUM_TRADE_REQUEST_ACTIONS)action;
  exitIntent.requestSnapshot.type=(ENUM_ORDER_TYPE)type;
  exitIntent.requestSnapshot.position=position;
  exitIntent.requestSnapshot.position_by=byPosition;
  exitIntent.requestSnapshot.magic=requestMagic;
  if(phase==REQUEST_PREPARED &&
     (order>0 || deal>0 || requestID>0 || entry.accepted || exitIntent.uncertain))
     return false;
  if(resolved) return true; // Tombstone itself is the caller's durable proof.
  if(sentAt==0) return false;
  if(!exitRequest)
     return (entry.direction==1 || entry.direction==-1) && entry.requestedLots>0 &&
        (!entry.requestPriceAvailable || entry.requestPrice>0) &&
        (!entry.breakoutPriceAvailable || entry.breakoutPrice>0);
  if(pid==0 || (exitIntent.reason!="EOD" && exitIntent.reason!="RECOVERED_EXIT")) return
false;
  // A pre-dispatch/recovered close can lack the CTrade request snapshot.
  // Its PID/ticket/intent still protects it; no success/failure is inferred.
  if(exitIntent.requestSnapshot.symbol=="")
     return action==0 && type==0 && exitIntent.requestSnapshot.volume==0 &&
        requestMagic==0 && position==0 && byPosition==0;
  return exitIntent.requestSnapshot.symbol==Symbol() &&
requestMagic==(ulong)gMagicCore &&
    (action==(ulong)TRADE_ACTION_DEAL ||
action==(ulong)TRADE_ACTION_CLOSE_BY) &&
    (type==(ulong)ORDER_TYPE_BUY || type==(ulong)ORDER_TYPE_SELL ||
type==(ulong)ORDER_TYPE_CLOSE_BY) &&
    exitIntent.requestSnapshot.volume>0 && (ticket==0 || position==ticket);
}

string RJRow(bool exitRequest,bool resolved)
{
  PendingExecContext e=gPendingExec;
  PendingExitIntent x=gPendingExit;
  if(exitRequest)
  {
     ZeroMemory(e); e.route="UNAVAILABLE"; e.mode="UNAVAILABLE";
     e.active=x.active; e.sentAt=x.sentAt; e.orderTicket=x.orderTicket;
     e.resultDeal=x.resultDeal; e.requestID=x.requestID; e.accepted=x.accepted;
     e.dispatchPhase=x.dispatchPhase;
  }
  else ZeroMemory(x);
  string f[];
  if(ArrayResize(f,40)!=40) return "";
  f[0]="S1995_REQUEST_JOURNAL_V2";
f[1]=(string)AccountInfoInteger(ACCOUNT_LOGIN);
  f[2]=RJEncode(Symbol()); f[3]=(string)(ulong)gMagicCore;
  f[4]=exitRequest?"EXIT":"ENTRY"; f[5]=resolved?"RESOLVED":"ACTIVE";
  f[6]=e.active?"1":"0"; f[7]=(string)e.direction;
  f[8]=RJEncode(e.route); f[9]=RJEncode(e.mode);
  f[10]=DoubleToString(e.requestPrice,16); f[11]=DoubleToString(e.requestedLots,16);
  f[12]=DoubleToString(e.slPrice,16); f[13]=DoubleToString(e.tpPrice,16);
  f[14]=(string)(ulong)e.sentAt; f[15]=(string)e.orderTicket; f[16]=(string)e.resultDeal;
  f[17]=(string)e.requestID; f[18]=e.accepted?"1":"0";
  f[19]=e.requestPriceAvailable?"1":"0"; f[20]=DoubleToString(e.breakoutPrice,16);
  f[21]=e.breakoutPriceAvailable?"1":"0"; f[22]=(string)x.positionID;
  f[23]=(string)x.positionTicket; f[24]=RJEncode(x.reason); f[25]=x.uncertain?"1":"0";
  f[26]=(string)(int)x.requestSnapshot.action; f[27]=(string)(int)x.requestSnapshot.type;
  f[28]=DoubleToString(x.requestSnapshot.volume,16);
f[29]=DoubleToString(x.requestSnapshot.price,16);
  f[30]=DoubleToString(x.requestSnapshot.sl,16);
f[31]=DoubleToString(x.requestSnapshot.tp,16);
  f[32]=(string)x.requestSnapshot.position; f[33]=(string)x.requestSnapshot.position_by;
  f[34]=(string)x.requestSnapshot.magic; f[35]=RJEncode(x.requestSnapshot.symbol);
  f[36]=RJEncode(x.requestSnapshot.comment); f[37]="COMPLETE";
  f[38]=(string)(int)e.dispatchPhase;
  string row=f[0];
  for(int i=1;i<39;i++) row+="|"+f[i];
  f[39]=RJChecksum(row); row+="|"+f[39];
  bool checkResolved; PendingExecContext checkEntry; PendingExitIntent checkExit;
  if(!RJParse(row,exitRequest,checkResolved,checkEntry,checkExit)) return "";
  return row;
}
bool PersistRequestJournal(bool exitRequest,bool resolved=false)
{
  // Never turn an older PREPARED snapshot plus torn MAY tail into negative proof.
  if(!resolved &&
     ((exitRequest && gExitJournalInvalid &&
gPendingExit.dispatchPhase==REQUEST_PREPARED) ||
      (!exitRequest && gEntryJournalInvalid &&
gPendingExec.dispatchPhase==REQUEST_PREPARED)))
     return false;
  string row=RJRow(exitRequest,resolved);
  bool ok=false;
  if(row!="")
  {
     int h=FileOpen(RequestJournalPath(exitRequest),
        FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
     if(h!=INVALID_HANDLE)
     {
        if(FileSeek(h,0,SEEK_END))
        {
           // Leading CRLF separates a torn previous tail from this snapshot.
           string payload="\r\n"+row+"\r\n";
           ResetLastError(); uint written=FileWriteString(h,payload);
           ok=(written==(uint)StringLen(payload) && GetLastError()==0);
           ResetLastError(); FileFlush(h);
          if(GetLastError()!=0) ok=false;
         }
         FileClose(h);
     }
    }
    if(exitRequest)
    { gExitJournalWritePending=!ok; if(ok) gExitJournalInvalid=false; }
    else
    { gEntryJournalWritePending=!ok; if(ok) gEntryJournalInvalid=false; }
    RecomputeRequestJournalFlags();
    return ok;
}

bool MarkRequestDispatchPossible(bool exitRequest)
{
  if(exitRequest)
  {
     if(!gPendingExit.active || gPendingExit.dispatchPhase!=REQUEST_PREPARED ||
        gExitJournalInvalid || gExitJournalCleanupPending) return false;
     gPendingExit.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  }
  else
  {
     if(!gPendingExec.active || gPendingExec.dispatchPhase!=REQUEST_PREPARED ||
        gEntryJournalInvalid || gEntryJournalCleanupPending) return false;
     gPendingExec.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
  }
  // Once this flush succeeds, a crash is ambiguous even before the API call.
  return PersistRequestJournal(exitRequest);
}

bool ResolveRequestJournal(bool exitRequest)
{
  if(exitRequest) gExitJournalCleanupPending=true;
  else gEntryJournalCleanupPending=true;
  PersistRequestJournal(exitRequest,true);
  string path=RequestJournalPath(exitRequest);
  // The caller supplies terminal proof. Successful whole-file deletion is
  // also a durable resolution even if appending the tombstone failed.
  bool gone=!FileIsExist(path);
  if(!gone && FileDelete(path)) gone=!FileIsExist(path);
  if(exitRequest)
  {
     gExitJournalCleanupPending=!gone;
     if(gone) { gExitJournalWritePending=false; gExitJournalInvalid=false; }
  }
  else
  {
     gEntryJournalCleanupPending=!gone;
     if(gone) { gEntryJournalWritePending=false; gEntryJournalInvalid=false; }
    }
    RecomputeRequestJournalFlags();
    return gone;
}

bool ReleasePreparedRequest(bool exitRequest)
{
  // Caller must supply a pristine restored snapshot, or retained local cleanup proof.
  if(exitRequest)
  {
     if(!gPendingExit.active || gPendingExit.dispatchPhase!=REQUEST_PREPARED ||
        gPendingExit.orderTicket>0 || gPendingExit.resultDeal>0 ||
        gPendingExit.requestID>0 || gPendingExit.accepted || gPendingExit.uncertain ||
        (gExitJournalInvalid && !gExitJournalCleanupPending)) return false;
  }
  else
  {
     if(!gPendingExec.active || gPendingExec.dispatchPhase!=REQUEST_PREPARED ||
        gPendingExec.orderTicket>0 || gPendingExec.resultDeal>0 ||
        gPendingExec.requestID>0 || gPendingExec.accepted ||
        (gEntryJournalInvalid && !gEntryJournalCleanupPending)) return false;
  }
  if(!ResolveRequestJournal(exitRequest)) return false;
  if(exitRequest) ClearPendingExitIntent();
  else ResetPendingExec(false);
  return true;
}

bool RJRead(bool exitRequest,bool &exists,bool &resolved,
         PendingExecContext &entry,PendingExitIntent &exitIntent,bool &hasSnapshot)
{
  exists=FileIsExist(RequestJournalPath(exitRequest)); resolved=false; hasSnapshot=false;
  if(!exists) return true;
  int
h=FileOpen(RequestJournalPath(exitRequest),FILE_READ|FILE_BIN|FILE_SHARE_READ)
;
  if(h==INVALID_HANDLE) return false;
  ResetLastError(); ulong size=FileSize(h);
  if(GetLastError()!=0) { FileClose(h); return false; }
  uchar bytes[4096]; string row=""; bool cr=false,malformed=false,tailInvalid=false;
  ulong offset=0;
  while(offset<size)
  {
     int want=(size-offset>4096)?4096:(int)(size-offset);
     ResetLastError(); uint got=FileReadArray(h,bytes,0,want);
     if(got!=(uint)want || GetLastError()!=0) { FileClose(h); return false; }
   offset+=got;
   for(int i=0;i<want;i++)
   {
     uchar b=bytes[i];
     if(b==10 && cr)
     {
        if(row!="" || malformed)
        {
           bool terminal; PendingExecContext candidateEntry; PendingExitIntent
candidateExit;
           if(!malformed && RJParse(row,exitRequest,terminal,candidateEntry,candidateExit))
           {
              // An earlier ambiguous dispatch cannot become negative proof.
              if(!terminal &&

(exitRequest?candidateExit.dispatchPhase:candidateEntry.dispatchPhase)==REQUEST_PREPARED &&
            (tailInvalid || (hasSnapshot && !resolved &&

(exitRequest?exitIntent.dispatchPhase:entry.dispatchPhase)==REQUEST_MAY_HAVE_DISPATCHED)))
              { FileClose(h); return false; }
              if(hasSnapshot && !resolved && !terminal &&
                 ((exitRequest && exitIntent.positionID!=candidateExit.positionID) ||
                  ((exitRequest?exitIntent.orderTicket:entry.orderTicket)>0 &&
                   (exitRequest?exitIntent.orderTicket:entry.orderTicket)!=
                   (exitRequest?candidateExit.orderTicket:candidateEntry.orderTicket))))
              { FileClose(h); return false; }
              entry=candidateEntry; exitIntent=candidateExit;
              resolved=terminal; hasSnapshot=true; tailInvalid=false;
           }
           else tailInvalid=true;
         }
         row=""; malformed=false; cr=false; continue;
      }
      if(cr) { malformed=true; cr=false; }
      if(b==13) { cr=true; continue; }
      if(b<32 || b>126) malformed=true;
      if(StringLen(row)<32768) row+=ShortToString((ushort)b);
      else malformed=true;
   }
  }
  FileClose(h);
  if(row!="" || malformed || cr) tailInvalid=true;
  // A later torn row never turns an older ACTIVE snapshot into absence.
  // With no usable snapshot, or after a tombstone, ambiguity stays explicit.
  return hasSnapshot && !tailInvalid;
}
bool RJCompatibleEntry(const PendingExecContext &a,const PendingExecContext &b)
{
  if(a.orderTicket>0 && b.orderTicket>0) return a.orderTicket==b.orderTicket;
  if(a.requestID>0 && b.requestID>0) return a.requestID==b.requestID;
  if(a.resultDeal>0 && b.resultDeal>0) return a.resultDeal==b.resultDeal;
  return a.sentAt==b.sentAt && a.direction==b.direction && a.route==b.route &&
     a.mode==b.mode &&
MathAbs(a.requestedLots-b.requestedLots)<=AccountingVolumeTolerance() &&
     MathAbs(a.requestPrice-b.requestPrice)<=gTickSize*0.000001 &&
     MathAbs(a.slPrice-b.slPrice)<=gTickSize*0.000001 &&
     MathAbs(a.tpPrice-b.tpPrice)<=gTickSize*0.000001;
}

bool RJCompatibleExit(const PendingExitIntent &a,const PendingExitIntent &b)
{
  if(a.positionID!=b.positionID) return false;
  if(a.orderTicket>0 && b.orderTicket>0) return a.orderTicket==b.orderTicket;
  if(a.requestID>0 && b.requestID>0) return a.requestID==b.requestID;
  if(a.resultDeal>0 && b.resultDeal>0) return a.resultDeal==b.resultDeal;
  return a.sentAt==b.sentAt && a.reason==b.reason &&
     (a.positionTicket==0 || b.positionTicket==0 || a.positionTicket==b.positionTicket);
}

bool RestoreRequestJournals()
{
  gRequestJournalRestoring=true;
  for(int side=0;side<2;side++)
  {
    bool isExit=(side==1),exists,resolved,snapshot;
    PendingExecContext entry; PendingExitIntent exitIntent;
    bool valid=RJRead(isExit,exists,resolved,entry,exitIntent,snapshot);
    if(isExit) gExitJournalInvalid=!valid;
    else gEntryJournalInvalid=!valid;
    if(!exists) continue;
    if(snapshot && !resolved)
    {
       if(isExit)
       {
          if(!gPendingExit.active) gPendingExit=exitIntent;
          else if(!RJCompatibleExit(gPendingExit,exitIntent)) gExitJournalInvalid=true;
          else if(gPendingExit.dispatchPhase==REQUEST_MAY_HAVE_DISPATCHED &&
                 exitIntent.dispatchPhase==REQUEST_PREPARED) gExitJournalInvalid=true;
          else if(exitIntent.dispatchPhase==REQUEST_MAY_HAVE_DISPATCHED)
             gPendingExit.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
          if(valid && !gExitJournalInvalid &&
exitIntent.dispatchPhase==REQUEST_PREPARED)
             ReleasePreparedRequest(true);
     }
     else
     {
       if(!gPendingExec.active) gPendingExec=entry;
       else if(!RJCompatibleEntry(gPendingExec,entry)) gEntryJournalInvalid=true;
       else if(gPendingExec.dispatchPhase==REQUEST_MAY_HAVE_DISPATCHED &&
              entry.dispatchPhase==REQUEST_PREPARED) gEntryJournalInvalid=true;
       else if(entry.dispatchPhase==REQUEST_MAY_HAVE_DISPATCHED)
          gPendingExec.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
       if(valid && !gEntryJournalInvalid && entry.dispatchPhase==REQUEST_PREPARED)
          ReleasePreparedRequest(false);
     }
     }
     else if(valid && resolved)
     {
       // A committed tombstone is proof for deletion retry, never ACTIVE.
       // Do not remove a conflicting live request's obligation on recovery.
       if((isExit && gPendingExit.active) || (!isExit && gPendingExec.active))
       {
          if(isExit) gExitJournalInvalid=true;
          else gEntryJournalInvalid=true;
       }
       else
       {
          if(isExit) gExitJournalCleanupPending=true;
          else gEntryJournalCleanupPending=true;
          ResolveRequestJournal(isExit);
       }
     }
    }
    gRequestJournalRestoring=false;
    RecomputeRequestJournalFlags();
    return !gRequestJournalUnresolved && !gRequestJournalWritePending &&
      !gEntryJournalCleanupPending && !gExitJournalCleanupPending;
}

void RecoverRequestJournals()
{
  datetime now=TimeTradeServer();
  if(now<gNextRequestJournalRecovery) return;
  gNextRequestJournalRecovery=now+10;
  if(gEntryJournalCleanupPending)
  {
     if(gPendingExec.active && gPendingExec.dispatchPhase==REQUEST_PREPARED)
        ReleasePreparedRequest(false);
     else ResolveRequestJournal(false);
  }
  if(gExitJournalCleanupPending)
 {
     if(gPendingExit.active && gPendingExit.dispatchPhase==REQUEST_PREPARED)
        ReleasePreparedRequest(true);
     else ResolveRequestJournal(true);
  }
  if(gEntryJournalInvalid || gExitJournalInvalid) RestoreRequestJournals();
  if(gEntryJournalWritePending && !gEntryJournalCleanupPending &&
gPendingExec.active)
     PersistRequestJournal(false);
  if(gExitJournalWritePending && !gExitJournalCleanupPending && gPendingExit.active)
     PersistRequestJournal(true);
  RecomputeRequestJournalFlags();
}

// Durable exact-order obligations; metadata is never terminal proof.
string OrderObligationPath(ulong ticket)
{
  return EconomicMarkerPrefix()+(string)ticket+".order.unresolved";
}

void UnknownOrderObligationContext(ulong ticket,UnresolvedOrderContext &c)
{
  ZeroMemory(c);
  c.active=true; c.classificationPending=true; c.orderTicket=ticket;
  c.nature=PENDING_ORDER_UNKNOWN; c.lastState=ORDER_STATE_STARTED;
  c.orderType=-1; c.orderReason=-1;
  c.route="UNAVAILABLE"; c.mode="UNAVAILABLE";
  c.persistencePending=true; c.persistenceSnapshot="";
  // Unknown/corrupt metadata cannot invent a setup lower bound or firstSeen.
  c.firstSeen=0; c.setupTime=0; c.doneTime=0;
}

bool EnsureOrderObligationIdentity(ulong ticket)
{
  string path=OrderObligationPath(ticket);
  // Filename presence alone is an unresolved identity, even if body is torn.
  // Ticket zero is the enumeration sentinel and never an operational order.
  if(FileIsExist(path)) return true;
  int h=FileOpen(path,FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
  if(h==INVALID_HANDLE) return false;
  string payload="S1995_ORDER_IDENTITY_V1\r\n";
  ResetLastError(); uint written=FileWriteString(h,payload);
  bool ok=(written==(uint)StringLen(payload) && GetLastError()==0);
  ResetLastError(); FileFlush(h);
  if(GetLastError()!=0) ok=false;
  FileClose(h);
  return ok && FileIsExist(path);
}
bool OrderObligationOptionalEnum(string text,long maximum,long &value)
{
  if(text=="-1") { value=-1; return true; }
  ulong parsed;
  if(!RJUnsigned(text,parsed) || parsed>(ulong)maximum) return false;
  value=(long)parsed;
  return true;
}

bool ParseOrderObligationSnapshot(string row,ulong filenameTicket,
                UnresolvedOrderContext &c)
{
  string f[];
  if(filenameTicket==0 || StringSplit(row,'|',f)!=20 ||
     f[0]!="S1995_ORDER_OBLIGATION_V1" || f[19]!="COMPLETE") return false;
  ulong account,magic,ticket,firstSeen,setup,done,pid,by,nature,state;
  string symbol;
  if(!RJUnsigned(f[1],account) || account!=(ulong)AccountInfoInteger(ACCOUNT_LOGIN) ||
     !RJDecode(f[2],symbol) || symbol!=Symbol() ||
     !RJUnsigned(f[3],magic) || magic!=(ulong)gMagicCore ||
     !RJUnsigned(f[4],ticket) || ticket!=filenameTicket ||
     !RJUnsigned(f[5],firstSeen) || (long)firstSeen<0 ||
     !RJUnsigned(f[6],setup) || (long)setup<0 ||
     !RJUnsigned(f[7],done) || (long)done<0 ||
     !RJUnsigned(f[8],pid) || !RJUnsigned(f[9],by) ||
     !RJUnsigned(f[10],nature) || nature>(ulong)PENDING_ORDER_EXIT ||
     !RJUnsigned(f[11],state) || state>(ulong)ORDER_STATE_REQUEST_CANCEL)
     return false;
  UnknownOrderObligationContext(ticket,c);
  if(!OrderObligationOptionalEnum(f[12],(long)ORDER_TYPE_CLOSE_BY,c.orderType) ||
     !OrderObligationOptionalEnum(f[13],(long)ORDER_REASON_SO,c.orderReason) ||
     !RJDouble(f[14],c.initialVolume) || !RJDouble(f[15],c.remainingVolume) ||
     !RJDecode(f[16],c.comment) || !RJDecode(f[17],c.route) ||
     !RJDecode(f[18],c.mode) || !RJRoute(c.route,c.mode)) return false;
  c.firstSeen=(datetime)firstSeen; c.setupTime=(datetime)setup;
c.doneTime=(datetime)done;
  c.positionID=pid; c.positionByID=by;
  c.nature=(PendingOrderNature)nature; c.lastState=(ENUM_ORDER_STATE)state;
  // Persisted classification/state/volumes are metadata, never terminal proof.
  c.active=true; c.classificationPending=true;
  c.persistencePending=false; c.persistenceSnapshot=row;
  return true;
}

string OrderObligationSnapshot(const UnresolvedOrderContext &c)
{
  if(c.orderTicket==0) return "";
  string f[];
  if(ArrayResize(f,20)!=20) return "";
  f[0]="S1995_ORDER_OBLIGATION_V1";
f[1]=(string)AccountInfoInteger(ACCOUNT_LOGIN);
  f[2]=RJEncode(Symbol()); f[3]=(string)(ulong)gMagicCore;
  f[4]=(string)c.orderTicket; f[5]=(string)(ulong)c.firstSeen;
  f[6]=(string)(ulong)c.setupTime; f[7]=(string)(ulong)c.doneTime;
  f[8]=(string)c.positionID; f[9]=(string)c.positionByID;
  f[10]=(string)(int)c.nature; f[11]=(string)(int)c.lastState;
  f[12]=(string)c.orderType; f[13]=(string)c.orderReason;
  f[14]=DoubleToString(c.initialVolume,16); f[15]=DoubleToString(c.remainingVolume,16);
  f[16]=RJEncode(c.comment); f[17]=RJEncode(c.route); f[18]=RJEncode(c.mode);
  f[19]="COMPLETE";
  string row=f[0];
  for(int i=1;i<20;i++) row+="|"+f[i];
    UnresolvedOrderContext check;
    if(!ParseOrderObligationSnapshot(row,c.orderTicket,check)) return "";
    return row;
}

bool PersistOrderObligationSnapshot(UnresolvedOrderContext &c)
{
  bool alreadyPresent=FileIsExist(OrderObligationPath(c.orderTicket));
  if(c.orderTicket==0 || !EnsureOrderObligationIdentity(c.orderTicket))
  { c.persistencePending=true; return false; }
  string row=OrderObligationSnapshot(c);
  if(row=="") { c.persistencePending=true; return false; }
  // An unchanged observed context never grows the file on every scan/tick.
  if(alreadyPresent && !c.persistencePending && row==c.persistenceSnapshot) return true;
  int h=FileOpen(OrderObligationPath(c.orderTicket),
     FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
  bool ok=false;
  if(h!=INVALID_HANDLE)
  {
     if(FileSeek(h,0,SEEK_END))
     {
        string payload="\r\n"+row+"\r\n";
        ResetLastError(); uint written=FileWriteString(h,payload);
        ok=(written==(uint)StringLen(payload) && GetLastError()==0);
        ResetLastError(); FileFlush(h);
        if(GetLastError()!=0) ok=false;
     }
     FileClose(h);
  }
  c.persistencePending=!ok;
  if(ok) c.persistenceSnapshot=row;
  return ok;
}
bool ReadOrderObligationSnapshot(ulong ticket,UnresolvedOrderContext &c)
{
  UnknownOrderObligationContext(ticket,c);
  int h=FileOpen(OrderObligationPath(ticket),FILE_READ|FILE_BIN|FILE_SHARE_READ);
  if(h==INVALID_HANDLE) return false;
  ResetLastError(); ulong size=FileSize(h);
  if(GetLastError()!=0) { FileClose(h); return false; }
  uchar bytes[4096]; string row="";
  bool cr=false,malformed=false,tailInvalid=false,hasSnapshot=false;
  UnresolvedOrderContext latest;
  ulong offset=0;
  while(offset<size)
  {
     int want=(size-offset>4096)?4096:(int)(size-offset);
     ResetLastError(); uint got=FileReadArray(h,bytes,0,want);
     if(got!=(uint)want || GetLastError()!=0) { FileClose(h); return false; }
     offset+=got;
     for(int i=0;i<want;i++)
     {
        uchar b=bytes[i];
        if(b==10 && cr)
        {
           if(row!="" || malformed)
           {
              UnresolvedOrderContext candidate;
              if(!malformed && ParseOrderObligationSnapshot(row,ticket,candidate))
              { latest=candidate; hasSnapshot=true; tailInvalid=false; }
              else tailInvalid=true;
           }
           row=""; malformed=false; cr=false; continue;
        }
        if(cr) { malformed=true; cr=false; }
        if(b==13) { cr=true; continue; }
        if(b<32 || b>126) malformed=true;
        if(StringLen(row)<32768) row+=ShortToString((ushort)b);
        else malformed=true;
     }
    }
    FileClose(h);
    if(row!="" || malformed || cr) tailInvalid=true;
    // Empty/identity-only/invalid-tail files retain an UNKNOWN exact ticket.
    // No prior metadata snapshot can authorize classification/terminal cleanup.
    if(!hasSnapshot || tailInvalid) return false;
    c=latest;
    return true;
}
bool ReleaseOrderObligation(UnresolvedOrderContext &c)
{
  // CALL ONLY AFTER fresh ReadOwnOrder + exact complete history/ledger proof.
  // A persisted lastState, missing live order or flat Positions is insufficient.
  if(c.orderTicket==0) return false;
  string path=OrderObligationPath(c.orderTicket);
  bool gone=!FileIsExist(path);
  if(!gone && FileDelete(path)) gone=!FileIsExist(path);
  if(!gone)
  {
     c.active=true; c.classificationPending=true; c.persistencePending=true;
     gOrderObligationScanUnresolved=true;
     return false;
  }
  c.active=false; c.classificationPending=false;
    c.persistencePending=false; c.persistenceSnapshot="";
    return true;
}

void StoreOrderObligationContext(int idx,UnresolvedOrderContext &c,bool
authoritativeOrder)
{
  if(c.active)
  {
     if(authoritativeOrder) PersistOrderObligationSnapshot(c);
     else if(!EnsureOrderObligationIdentity(c.orderTicket)) c.persistencePending=true;
  }
  // A deleted terminal obligation must not be recreated by this assignment.
  gUnresolvedOrders[idx]=c;
}

void RestoreOrderObligations()
{
  if(gOrderObligationRestoring) return;
  gOrderObligationRestoring=true;
  gOrderObligationScanUnresolved=false;
  if(!EnsureOrderObligationIdentity(0))
  {
     gOrderObligationScanUnresolved=true;
     gOrderObligationRestoring=false; return;
  }
  string prefix=EconomicMarkerPrefix(),suffix=".order.unresolved",name;
  long search=FileFindFirst(prefix+"*"+suffix,name);
  if(search==INVALID_HANDLE)
  {
     gOrderObligationScanUnresolved=true;
     gOrderObligationRestoring=false; return;
  }
    ulong tickets[]; int count=0; bool sentinel=false,more=true;
    while(more)
    {
       if(name==prefix+"0"+suffix) sentinel=true;
       else
       {
          int length=StringLen(name)-StringLen(prefix)-StringLen(suffix);
          ulong ticket=0;
          if(length<=0 || StringSubstr(name,0,StringLen(prefix))!=prefix ||
             StringSubstr(name,StringLen(name)-StringLen(suffix))!=suffix ||
             !CsvParsePID(StringSubstr(name,StringLen(prefix),length),ticket))
             gOrderObligationScanUnresolved=true;
          else if(ArrayResize(tickets,count+1)!=count+1)
             gOrderObligationScanUnresolved=true; // Exact filename remains durable.
          else tickets[count++]=ticket;
       }
       ResetLastError(); more=FileFindNext(search,name);
       // Only an explicit clean EOF (zero after ResetLastError) is accepted.
       // No guessed nonzero EOF code can turn an incomplete scan into emptiness.
       if(!more && GetLastError()!=0) gOrderObligationScanUnresolved=true;
      }
      FileFindClose(search);
      if(!sentinel) gOrderObligationScanUnresolved=true;
      // Enumeration is closed before allocation/rebuild/persistence can mutate files.
      for(int i=0;i<count;i++)
      {
         ulong ticket=tickets[i];
         int known=FindUnresolvedOrder(ticket);
         int idx=RememberUnresolvedOrder(ticket);
         if(idx<0) { gOrderObligationScanUnresolved=true; continue; }
         if(known>=0)
         {
            // A retry never overwrites a newer in-memory authoritative context.
            if(gUnresolvedOrders[idx].persistencePending)
               gOrderObligationScanUnresolved=true;
            continue;
         }
         UnresolvedOrderContext restored;
         bool valid=ReadOrderObligationSnapshot(ticket,restored);
         // Remember may have written an UNKNOWN initial snapshot; therefore the
         // integration must suppress snapshot writes while gOrderObligationRestoring.
         gUnresolvedOrders[idx]=restored;
         if(!valid) gOrderObligationScanUnresolved=true;
      }
      gOrderObligationRestoring=false;
}

void InitializeAccounting()
{
  ArrayResize(gTradeRecords,0); ArrayResize(gDeferredAccountingPIDs,0);
  gDeferredRegistryUnavailable=false;
  gTradeRecordCount=0; ResetOpenPos(); ResetPendingExec(false);
  gPendingExit.active=false; gPendingExit.positionID=0; gPendingExit.reason="";
  gPendingExit.dispatchPhase=REQUEST_MAY_HAVE_DISPATCHED;
gPendingExit.sentAt=0;
  gPendingExit.orderTicket=0; gPendingExit.resultDeal=0;
  gPendingExit.positionTicket=0; gPendingExit.requestID=0;
  gPendingExit.accepted=false; gPendingExit.uncertain=false;
  ZeroMemory(gPendingExit.requestSnapshot);
  ArrayResize(gUnresolvedOrders,0);
  gMultipleOwnOrdersActive=false; gOrderRegistryUnavailable=false;
  gOrderRegistryFallbackCount=0; gOrderRegistryOverflow=false;
  gOrderObligationScanUnresolved=false; gOrderObligationRestoring=false;
  gDeferredFallbackCount=0; gDeferredRegistryOverflow=false;
  gEconomicMarkerScanUnresolved=false;
  gEMRMaintenanceNeeded=false; gEMRMaintenanceCursor="";
  gIdentityLossUnresolved=FileIsExist(IdentityLossMarkerPath());
  gIdentityLossPersistPending=false;
  gRequestJournalUnresolved=false; gRequestJournalWritePending=false;
  gEntryJournalCleanupPending=false; gExitJournalCleanupPending=false;
  gEntryJournalInvalid=false; gExitJournalInvalid=false;
  gEntryJournalWritePending=false; gExitJournalWritePending=false;
  gRequestJournalRestoring=false; gNextRequestJournalRecovery=0;
  ArrayResize(gDeferredDeals,0); gDeferredDealFallbackCount=0;
gDeferredDealOverflow=false;
  gNextOrderReconcile=0;
  gLiveOwnershipUnresolved=false; gAccountingCapacityUnresolved=false;
  gDailyRiskLimitLatched=false; gDailyHistoryRetryRequired=false;
  gDailyEconomicsState=DAILY_ECONOMICS_VALID; gLastAccountingRecoveryTime=0;
  gPendingOrderClassificationUnresolved=false;
  requestsAcceptedToday=0; ordersEnteredToday=0; dailyNetPnL=0; dailyPnLR=0;
  consecutiveLosses=0; dailyRiskBlocked=false; lastTradeWasLoss=false;
  lastCloseConfirmedTime=0; gDailyPnLRValid=true;
  gDailyEconomicsValid=true; gQuotaHistoryValid=true;
  gNeedsAccountingSync=false; gLastPendingReconcileTime=0;
  ArrayResize(gConfirmedPositionsToday,0);
  RestoreRequestJournals();
  RestoreOrderObligations();
}

void ResetAccountingDay()
{
  // An open cycle, its exit intent and pending request survive midnight.
  requestsAcceptedToday=0; ordersEnteredToday=0; dailyNetPnL=0; dailyPnLR=0;
  consecutiveLosses=0; dailyRiskBlocked=false; lastTradeWasLoss=false;
  lastCloseConfirmedTime=0; gDailyPnLRValid=true;
  gDailyRiskLimitLatched=false; gDailyHistoryRetryRequired=true;
gLastAccountingRecoveryTime=0;
  gDailyEconomicsValid=true; gQuotaHistoryValid=true;
  ArrayResize(gConfirmedPositionsToday,0);
  for(int i=0;i<gTradeRecordCount;i++)
  {
    // Prior finalized records remain reusable; an open cycle is accounted
    // against the date on which its closure will be confirmed.
    if(!gTradeRecords[i].closed) gTradeRecords[i].dailyApplied=false;
    gTradeRecords[i].quotaCounted=false;
  }
  RestoreDailyPersistence(false);
  RecomputeAccountingBlock();
}

void OnTradeTransaction(const MqlTradeTransaction &trans,
        const MqlTradeRequest &request,const MqlTradeResult &result)
{
  EMRInvalidateTransaction(trans);
  BEHandleTransaction(trans,request,result);
  bool ownEntryRequest=(gPendingExec.active && request.position==0 &&
request.position_by==0 &&
    request.symbol==Symbol() && request.magic==gMagicCore &&
request.action==TRADE_ACTION_DEAL &&
     ((gPendingExec.direction==1 && request.type==ORDER_TYPE_BUY) ||
      (gPendingExec.direction==-1 && request.type==ORDER_TYPE_SELL)) &&
     MathAbs(request.volume-gPendingExec.requestedLots)<=AccountingVolumeTolerance()
&&
       request.comment=="S1995|"+gPendingExec.route+"|"+gPendingExec.mode &&
       MathAbs(request.price-gPendingExec.requestPrice)<=gTickSize*0.000001 &&
       MathAbs(request.sl-gPendingExec.slPrice)<=gTickSize*0.000001 &&
       MathAbs(request.tp-gPendingExec.tpPrice)<=gTickSize*0.000001 &&
       gPendingExec.requestID>0 && result.request_id==gPendingExec.requestID);
    if(trans.type==TRADE_TRANSACTION_REQUEST && ownEntryRequest)
    {
       if(result.order>0) gPendingExec.orderTicket=result.order;
       if(result.deal>0) gPendingExec.resultDeal=result.deal;
       if(IsAcceptedRetcode(result.retcode))
       { if(!gPendingExec.accepted) requestsAcceptedToday++; gPendingExec.accepted=true;
}
     else if(IsFinalRejectedRetcode(result.retcode) && !gPendingExec.accepted &&
        gPendingExec.orderTicket==0 && gPendingExec.resultDeal==0)
       ResetPendingExec();
       if(gPendingExec.active) PersistRequestJournal(false);
  }
  if(trans.type==TRADE_TRANSACTION_REQUEST &&
MatchesExitRequest(request,result))
     CompletePendingExit(result);
  if(trans.type==TRADE_TRANSACTION_DEAL_ADD && trans.deal>0)
  {
     if(!ProcessAccountingDeal(trans.deal)) RememberDeferredDeal(trans.deal);
    }
    // Every transaction may reconcile a position state that lagged DEAL_ADD.
    gNeedsAccountingSync=true;
    SyncAccountingState(true);
    // Diagnostics may select deal history, so run after all original handlers.
    if(trans.type==TRADE_TRANSACTION_REQUEST) EntryObserveRequest(request,result);
    EntryObserveFill(trans);
}


double OnTester() { return 0.0; }





