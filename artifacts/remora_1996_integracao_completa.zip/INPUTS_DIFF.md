# Inputs — base1.995 versus candidata1.996

Base: **73 inputs**. Candidata e include: **65 inputs**: 48 preservados, 25 removidos e 17 novos. Tipos e defaults dos inputs financeiros preservados. Valores novos são hipóteses de pesquisa/engenharia, não otimizados.

| Input | Estado | Tipo / default | Justificativa / semântica |
| --- | --- | --- | --- |
| `Inp_Magic_WIN` | INALTERADO | `int = 60001` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_Magic_WDO` | INALTERADO | `int = 60002` | Nome, tipo e default preservados; gestão/execução intacta. |
| `CSVFileName` | INALTERADO | `string = "Scalper1995"` | Nome, tipo e default preservados; gestão/execução intacta. |
| `BacktestStart` | INALTERADO | `datetime = D'2025.01.01'` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_ContextTF` | INALTERADO | `ENUM_TIMEFRAMES = PERIOD_M5` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_SignalTF` | INALTERADO | `ENUM_TIMEFRAMES = PERIOD_M1` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_StartHHMM` | INALTERADO | `int = 900` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_StopEntryHHMM` | INALTERADO | `int = 1530` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_EOD_CloseHHMM` | INALTERADO | `int = 1750` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_SizingMode` | INALTERADO | `SIZING_MODE = SIZING_FIXED` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_FixedLots` | INALTERADO | `double = 1.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_RiskPerTradePct` | INALTERADO | `double = 0.15` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxLots` | INALTERADO | `double = 2.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_SL_Pts_WIN` | INALTERADO | `double = 400.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_TP_Pts_WIN` | INALTERADO | `double = 2000.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_SL_Pts_WDO` | INALTERADO | `double = 10.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_TP_Pts_WDO` | INALTERADO | `double = 25.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_SpreadMaxPts_WIN` | INALTERADO | `double = 30.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_SpreadMaxPts_WDO` | INALTERADO | `double = 2.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_EnableBreakEven` | INALTERADO | `bool = true` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_EnableDailyRiskStop` | INALTERADO | `bool = true` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxDailyLossR` | INALTERADO | `double = 3.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_EnableConsecutiveLossStop` | INALTERADO | `bool = true` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxConsecutiveLosses` | INALTERADO | `int = 3` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxTradesDay` | INALTERADO | `int = 10` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_CooldownSec` | INALTERADO | `int = 0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_LossCooldownSec` | INALTERADO | `int = 0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_ArmedTimeoutSec` | INALTERADO | `int = 300` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_ABSTriggerReference` | REMOVIDO | `ABS_TRIGGER_REFERENCE = ABS_TRIGGER_SIGNAL_CLOSE` | Elimina seleção legada de região; ambas as rotas usam fechamento M1. |
| `Inp_Region_Candles` | REMOVIDO | `int = 2` | Deixa de ser pré-condição/gatilho. Dois extremos M1 congelados permanecem exclusivamente FAR. |
| `Inp_BreakoutMargin_WIN` | INALTERADO | `double = 175.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_BreakoutMargin_WDO` | INALTERADO | `double = 3.5` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxOvershoot_WIN` | INALTERADO | `double = 100.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxOvershoot_WDO` | INALTERADO | `double = 2.5` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_ABS_Effort` | INALTERADO | `double = 1.50` | Razão de volume da tentativa original no extremo / média das ondas fechadas anteriores; sem incluir a ativa na referência. |
| `Inp_CONT_Effort` | INALTERADO | `double = 1.50` | Razão de volume da onda direcional / média congelada de ondas anteriores. |
| `Inp_ABS_BreakoutEffort` | REMOVIDO | `double = 1.50` | Onda viva antiga não é a evidência da tentativa ABS; nova revalidação usa a tese causal. |
| `Inp_CONT_BreakoutEffort` | REMOVIDO | `double = 1.50` | Remove veto da onda M1 antiga; revalidação usa os mesmos critérios da nova CONT. |
| `Inp_POC_WindowSec` | REMOVIDO | `int = 300` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_POC_FollowRatio` | REMOVIDO | `double = 0.40` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_RejectPOCTies` | REMOVIDO | `bool = false` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_ABS_MinPriceMovePts_WIN` | INALTERADO | `double = 60.0` | Magnitude mínima da tentativa observada; unidade em pontos do preço, agora sem POC. |
| `Inp_ABS_MaxBodyPts_WIN` | REMOVIDO | `double = 60.0` | Corpo isolado de candle deixa de confirmar absorção. |
| `Inp_ABS_MinPriceMovePts_WDO` | INALTERADO | `double = 2.0` | Magnitude mínima da tentativa observada; unidade em pontos do preço, agora sem POC. |
| `Inp_ABS_MaxBodyPts_WDO` | REMOVIDO | `double = 2.0` | Corpo isolado de candle deixa de confirmar absorção. |
| `Inp_CONT_MinPriceMovePts_WIN` | INALTERADO | `double = 50.0` | Magnitude mínima de progresso da onda; antes medida na janela POC. |
| `Inp_CONT_MinPriceMovePts_WDO` | INALTERADO | `double = 1.5` | Magnitude mínima de progresso da onda; antes medida na janela POC. |
| `Inp_Cont_RequireCandleDirection` | REMOVIDO | `bool = true` | Retira confirmação redundante pela cor da vela. |
| `Inp_BandMultiplier_WIN` | INALTERADO | `double = 0.80` | Escala 0,80σ/1,60σ/2,40σ; bandas uniformes1/2/3. |
| `Inp_BandMultiplier_WDO` | INALTERADO | `double = 1.50` | Escala 1,50σ/3,00σ/4,50σ; não presume visitas frequentes a B3. |
| `Inp_VWAP_Inner_Pct` | REMOVIDO | `double = 0.60` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_VWAP_Outer_Pct` | REMOVIDO | `double = 1.50` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_Rule_40_60` | REMOVIDO | `double = 0.40` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_C2_WIN` | REMOVIDO | `double = 700.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_C3_Min_WIN` | REMOVIDO | `double = 125.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_C3_Max_WIN` | REMOVIDO | `double = 400.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_C2_WDO` | REMOVIDO | `double = 25.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_C3_Min_WDO` | REMOVIDO | `double = 5.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_C3_Max_WDO` | REMOVIDO | `double = 15.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `SigmaLookbackDays` | REMOVIDO | `int = 5` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_SigmaFloor_WIN` | REMOVIDO | `double = 200.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_SigmaFloor_WDO` | REMOVIDO | `double = 7.0` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_MaxDeviationPts_WIN` | INALTERADO | `int = 100` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxDeviationPts_WDO` | INALTERADO | `int = 2` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_EnableMacroDirectionGate` | REMOVIDO | `bool = true` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_EnableLateDirectionBlock` | REMOVIDO | `bool = true` | Exclusivo de POC, D-1, votação ou vetos antigos retirados da nova inteligência. |
| `Inp_EnableAbsorption` | INALTERADO | `bool = true` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_EnableContinuation` | INALTERADO | `bool = true` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_TurboLotsMultiplier` | REMOVIDO | `double = 2.0` | Exceção autorizada: sem multiplicador nas novas entradas; parsers históricos intocados. |
| `Inp_ExitMode` | INALTERADO | `EXIT_MODE = PROGRESSIVE_NO_TP` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_MaxProtectedR` | INALTERADO | `int = 5` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_AggressionFilterMode` | INALTERADO | `FAR_MODE = FAR_APLICAR` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_AggressionThresholdPct` | INALTERADO | `double = 60.0` | Nome, tipo e default preservados; gestão/execução intacta. |
| `Inp_BandsWarmupSec` | NOVO — hipótese | `int = 300` | Aquecimento mínimo desde a abertura regular. 300s não asseguram estabilidade estatística. |
| `Inp_BandsMinTrades` | NOVO — hipótese | `int = 2` | Mínimo algébrico de dois negócios; preços distintos e dispersão também são necessários. Não é amostra estatisticamente suficiente. |
| `Inp_BandsMinSigmaTicks` | NOVO — hipótese | `double = 1.0` | Dispersão mínima relativa à grade, hipótese de engenharia; não piso histórico e não otimizada. |
| `Inp_RegularSessionStartHHMM` | NOVO — hipótese | `int = -1` | -1 exige uma única sessão publicada. Override em horário do servidor, junto com fim, contido na sessão negociável. |
| `Inp_RegularSessionEndHHMM` | NOVO — hipótese | `int = -1` | Delimita sessão regular/exclusão de pós-mercado; intervalos ou sessões ambíguas não recebem fallback. |
| `Inp_FeedMaxGapSec` | NOVO — hipótese | `int = 30` | Tolerância experimental de silêncio. Lacuna longa bloqueia; silêncio não prova ausência de negócios e uma lacuna curta não prova completude. |
| `Inp_WaveBaselineMin` | NOVO — hipótese | `int = 3` | Mínimo experimental de ondas FECHADAS anteriores; máximo10. Não inventa média durante aquecimento. |
| `Inp_WaveReversalPts_WIN` | NOVO — hipótese | `double = 60.0` | 60 pontos: hipótese fornecida, validada na grade; reconhecimento causal, não pivô futuro. |
| `Inp_WaveReversalPts_WDO` | NOVO — hipótese | `double = 2.0` | 2 pontos: hipótese fornecida, validada na grade; reconhecimento causal, não pivô futuro. |
| `Inp_PathEventTicks` | NOVO — hipótese | `int = 2` | 2 ticks: amostragem causal por deslocamento desde último evento; resposta ao contraexemplo do bounce. Não otimizado, não invariância universal. |
| `Inp_CONT_MinPathEfficiency` | NOVO — hipótese | `double = 0.60` | 0,60 aplicado à eficiência dos eventos de preço com numerador/denominador da mesma trajetória; raw mantido observável. |
| `Inp_ABS_MaxPathEfficiency` | NOVO — hipótese | `double = 0.30` | 0,30 aplicado à tentativa original congelada antes da rejeição, pela trajetória de eventos; não à reação desejada. |
| `Inp_ABS_MinRejectionFraction` | NOVO — hipótese | `double = 0.35` | 0,35 da excursão, além de ao menos um tick posterior; hipótese fornecida. |
| `Inp_DataChunkMsc` | NOVO — hipótese | `int = 10000` | Janela máxima por consulta; também dividida no fechamento M1. |
| `Inp_DataMaxChunkTrades` | NOVO — hipótese | `int = 50000` | Orçamento de registros: exceder bloqueia dados, sem truncar ou descartar negócios silenciosamente. |
| `Inp_DataChunksPerTimer` | NOVO — hipótese | `int = 4` | Limita trabalho por callback; orçamento de CPU suave medido não torna API MT5 preemptível. |
| `Inp_SigmaCheckToleranceTicks` | NOVO — hipótese | `double = 0.000001` | Tolerância numérica da comparação independente em unidades do tick; não precisão estatística. |

Os slots históricos `MACRO_GATE_ENABLED`, `LATE_DIRECTION_BLOCK_ENABLED` e `REJECT_POC_TIES` do CSV financeiro permanecem com constantes1/1/0 para preservar o schema original. São campos aposentados de compatibilidade, sem uso em decisões. Os rótulos `BASE`/`BASE_CONT` nas novas ordens são mapeamento de identidade; não representam pontuação da matriz antiga. `TURBO`/`TURBO_CONT` continuam reconhecidos em recuperação, sem multiplicação nas novas entradas.


## Integração posterior

A integração não altera os65 inputs efetivos, seus tipos, defaults ou ordem. `OM_LIVE_MAX_RECORDS=256` e `OM_LIVE_MAX_LAG_MSC=1000` são limites internos de trabalho analítico, documentados como orçamento, não parâmetros otimizados de entrada. Backlog excessivo aguarda timer. O reaproveitamento de `Inp_PathEventTicks` como tolerância de recuo da CONT foi reproduzido e permanece uma ambiguidade estratégica explícita, sem mudança silenciosa.
